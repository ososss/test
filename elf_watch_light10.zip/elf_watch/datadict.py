"""
datadict.py - 전역변수 데이터 사전 내보내기

전역 트리를 평탄화해 변수명·경로·타입·주소·오프셋·크기·비트필드 위치까지
표로 만든다. 인터페이스 문서나 데이터 사전 산출물의 초안으로 쓴다.

  python datadict.py <elf 또는 .ews> <out.xlsx|out.csv> [--depth N] [--max-elem N]

openpyxl 이 있으면 xlsx, 없으면 CSV 로 저장한다.
"""

from __future__ import annotations

import csv
import os
import sys
from typing import List, Optional

COLUMNS = [
    ('variable', 14, '최상위 전역변수 이름'),
    ('path', 38, 'C 표현식 경로'),
    ('depth', 6, '중첩 깊이'),
    ('type', 22, '타입 표기'),
    ('kind', 9, 'base/struct/union/array/enum/pointer'),
    ('address', 12, '절대 주소'),
    ('offset', 9, '최상위 변수 시작부터의 바이트 오프셋'),
    ('size', 7, '바이트 크기'),
    ('bit_pos', 8, '비트필드 위치 (주소.비트)'),
    ('bit_width', 9, '비트필드 폭'),
    ('dims', 10, '배열 차원'),
    ('enum_values', 30, '열거형 값 목록'),
    ('init_value', 24, '초기값 (덤프를 올렸다면 그 값)'),
    ('decl_line', 9, '선언 라인'),
]


def flatten(reader, max_depth: int = 6, max_elem: int = 16,
            leaves_only: bool = False) -> List[dict]:
    """전역 트리를 행 목록으로 편다."""
    rows: List[dict] = []

    def walk(node, root, path, depth):
        t = node.type
        is_leaf = not node.has_children()
        if not (leaves_only and not is_leaf):
            dims = ''
            if t is not None and t.kind == 'array' and node.dims_left:
                dims = ''.join(f'[{d}]' for d in node.dims_left if d is not None)
            enum_vals = ''
            if t is not None and t.enum_map:
                items = sorted(t.enum_map.items(), key=lambda kv: kv[0])[:8]
                enum_vals = ', '.join(f'{v}={k}' for k, v in items)
                if len(t.enum_map) > 8:
                    enum_vals += ', ...'
            bit_pos = ''
            if node.bit_size is not None and node.address is not None:
                bit_pos = f'0x{node.address:08X}.{node.bit_offset}'
            rows.append({
                'variable': root.name,
                'path': path,
                'depth': depth,
                'type': node.type_text,
                'kind': t.kind if t is not None else '',
                'address': f'0x{node.address:08X}' if node.address is not None else '',
                'offset': (node.address - root.address)
                          if (node.address is not None and root.address is not None) else '',
                # 비트필드는 byte_size 가 '담고 있는 타입'의 크기라
                # 합계를 내면 오해를 부른다. bit_width 로만 표기한다.
                'size': ('' if node.bit_size is not None
                         else (node.byte_size if node.byte_size is not None else '')),
                'bit_pos': bit_pos,
                'bit_width': node.bit_size if node.bit_size is not None else '',
                'dims': dims,
                'enum_values': enum_vals,
                'init_value': node.value_text(),
                'decl_line': root.decl_line if depth == 0 and root.decl_line else '',
            })
        if depth >= max_depth or is_leaf:
            return
        if t is not None and t.kind == 'pointer':
            return                                  # 포인터는 따라가지 않는다
        kids = node.children()
        if t is not None and t.kind == 'array' and len(kids) > max_elem:
            kids = kids[:max_elem]
        for k in kids:
            if k.is_placeholder:
                continue
            nm = k.name
            walk(k, root, path + (nm if nm.startswith('[') else '.' + nm), depth + 1)

    for g in reader.globals:
        walk(g, g, g.name, 0)
    return rows


# ---------------------------------------------------------------- 내보내기
def write_csv(rows: List[dict], path: str, meta: Optional[dict] = None):
    keys = [c[0] for c in COLUMNS]
    with open(path, 'w', newline='', encoding='utf-8-sig') as f:
        w = csv.writer(f)
        if meta:
            for k, v in meta.items():
                w.writerow([f'# {k}', v])
            w.writerow([])
        w.writerow(keys)
        for r in rows:
            w.writerow([r.get(k, '') for k in keys])


def write_xlsx(rows: List[dict], path: str, meta: Optional[dict] = None) -> bool:
    """openpyxl 이 있으면 xlsx 로 저장. 없으면 False."""
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Alignment, Font, PatternFill
        from openpyxl.utils import get_column_letter
    except ImportError:
        return False

    wb = Workbook()

    # ---- 정보 시트
    ws0 = wb.active
    ws0.title = 'Info'
    ws0['A1'] = 'ELF Watch - 데이터 사전'
    ws0['A1'].font = Font(name='Arial', size=13, bold=True)
    r = 3
    for k, v in (meta or {}).items():
        ws0.cell(r, 1, k).font = Font(name='Arial', bold=True)
        ws0.cell(r, 2, str(v)).font = Font(name='Arial')
        r += 1
    r += 1
    ws0.cell(r, 1, '칼럼 설명').font = Font(name='Arial', bold=True)
    r += 1
    for name, _, desc in COLUMNS:
        ws0.cell(r, 1, name).font = Font(name='Arial', bold=True)
        ws0.cell(r, 2, desc).font = Font(name='Arial')
        r += 1
    ws0.column_dimensions['A'].width = 18
    ws0.column_dimensions['B'].width = 60

    # ---- 데이터 사전 시트
    ws = wb.create_sheet('Data Dictionary')
    head_font = Font(name='Arial', bold=True, color='FFFFFF')
    head_fill = PatternFill('solid', fgColor='44546A')
    mono = Font(name='Consolas', size=10)
    plain = Font(name='Arial', size=10)

    for c, (name, width, _) in enumerate(COLUMNS, 1):
        cell = ws.cell(1, c, name)
        cell.font = head_font
        cell.fill = head_fill
        cell.alignment = Alignment(horizontal='center')
        ws.column_dimensions[get_column_letter(c)].width = width

    mono_cols = {'path', 'type', 'address', 'bit_pos', 'dims', 'init_value'}
    for i, row in enumerate(rows, 2):
        for c, (name, _, _) in enumerate(COLUMNS, 1):
            cell = ws.cell(i, c, row.get(name, ''))
            cell.font = mono if name in mono_cols else plain
            if name in ('depth', 'offset', 'size', 'bit_width', 'decl_line'):
                cell.alignment = Alignment(horizontal='right')

    ws.freeze_panes = 'C2'
    ws.auto_filter.ref = f'A1:{get_column_letter(len(COLUMNS))}{len(rows) + 1}'

    wb.save(path)
    return True


def export(reader, out_path: str, max_depth: int = 6, max_elem: int = 16,
           leaves_only: bool = False) -> dict:
    rows = flatten(reader, max_depth, max_elem, leaves_only)
    s = reader.summary()
    meta = {
        '원본': s.get('source_elf') or s.get('file'),
        '아키텍처': f"{s.get('class')} / {s.get('machine')} / {s.get('endian')}-endian",
        'DWARF': s.get('dwarf'),
        '전역변수': s.get('globals'),
        '행 수': len(rows),
        '전개 깊이': max_depth,
        '배열 표시 한도': max_elem,
    }
    if s.get('sha256'):
        meta['원본 SHA256'] = s['sha256']

    ext = os.path.splitext(out_path)[1].lower()
    used_xlsx = False
    if ext in ('.xlsx', '.xlsm'):
        used_xlsx = write_xlsx(rows, out_path, meta)
        if not used_xlsx:
            out_path = os.path.splitext(out_path)[0] + '.csv'
            write_csv(rows, out_path, meta)
    else:
        write_csv(rows, out_path, meta)
    return {'rows': len(rows), 'path': out_path, 'xlsx': used_xlsx}


# ---------------------------------------------------------------- CLI
def _open_source(path: str):
    if path.endswith('.ews'):
        import symstore
        return symstore.StoreSource(path)
    from dwarf_reader import DwarfReader
    return DwarfReader(path)


if __name__ == '__main__':
    args = sys.argv[1:]
    if len(args) < 2:
        print('usage: python datadict.py <elf|.ews> <out.xlsx|out.csv> '
              '[--depth N] [--max-elem N] [--leaves]')
        raise SystemExit(1)
    depth, elem, leaves = 6, 16, False
    if '--depth' in args:
        i = args.index('--depth'); depth = int(args[i + 1]); args = args[:i] + args[i + 2:]
    if '--max-elem' in args:
        i = args.index('--max-elem'); elem = int(args[i + 1]); args = args[:i] + args[i + 2:]
    if '--leaves' in args:
        args.remove('--leaves'); leaves = True

    src = _open_source(args[0])
    info = export(src, args[1], depth, elem, leaves)
    kind = 'xlsx' if info['xlsx'] else 'csv'
    print(f"{info['rows']:,}행 -> {info['path']} ({kind})")
    if not info['xlsx'] and args[1].endswith('.xlsx'):
        print('openpyxl 이 없어 CSV 로 저장했습니다. '
              'pip install openpyxl 후 다시 시도하면 xlsx 로 나옵니다.')
