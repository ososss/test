@echo off
setlocal
echo ===== ELF Watch - offline install =====
echo.
python -c "import sys,platform; print('Python', sys.version.split()[0], platform.machine())"
if errorlevel 1 (
    echo [ERROR] python not found in PATH.
    pause
    exit /b 1
)
echo.
python -m pip install --no-index --find-links="%~dp0wheels" pyelftools cryptography openpyxl PyQt6
if errorlevel 1 (
    echo.
    echo [ERROR] install failed - check that Python is 3.12 / AMD64.
    pause
    exit /b 1
)
echo.
python -c "import elftools, cryptography, openpyxl, PyQt6.QtWidgets; print("install ok")"
echo.
echo   run:  python t32_watch.py sample\fcs_sample_dwarf4.elf
echo.
pause
