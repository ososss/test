"""
builddiff.py - 두 빌드의 전역변수 / 타입 레이아웃 비교

ELF 끼리, 저장본(.ews) 끼리, 또는 섞어서 비교한다.
변경영향분석과 형상관리 자료에 쓸 수 있게 무엇이 어떻게 달라졌는지 뽑는다.

  python builddiff.py <old> <new> [-o report.xlsx|report.csv]

탐지 항목
  - 추가 / 삭제된 전역변수
  - 주소 이동, 크기 변경
  - 타입 변경 (이름이 같아도 레이아웃이 다르면 잡는다)
  - 구조체 멤버 단위 변경: 추가·삭제·오프셋 이동·비트 위치/폭 변경·타입 변경
"""

from __future__ import annotations

import csv
import os
import sys
from typing import Dict, List, Optional, Tuple

MAX_SIG_DEPTH = 8


# ---------------------------------------------------------------- 타입 서명
def type_signature(reader, t, depth: int = 0, seen: Optional[set] = None) -> str:
    """레이아웃까지 반영한 타입 지문.

    이름이 같아도 멤버 오프셋이나 비트 폭이 다르면 다른 서명이 된다.
    자기참조 구조체를 위해 방문 집합을 들고 다닌다.
    """
    if t is None:
        return 'void'
    if depth > MAX_SIG_DEPTH:
        return '...'
    seen = seen or set()
    key = id(t)
    if key in seen:
        return f'@{t.name}'
    seen = seen | {key}

    if t.kind == 'base':
        return f'{t.name}:{t.byte_size}:{t.encoding}'
    if t.kind == 'enum':
        vals = ','.join(f'{v}={k}' for k, v in sorted(t.enum_map.items()))
        return f'enum({t.name},{t.byte_size}){{{vals}}}'
    if t.kind == 'pointer':
        return f'ptr->{type_signature(reader, t.elem, depth + 1, seen)}'
    if t.kind == 'array':
        dims = ''.join(f'[{d}]' for d in t.dims)
        return f'{type_signature(reader, t.elem, depth + 1, seen)}{dims}'
    if t.kind in ('struct', 'union'):
        parts = []
        for m in reader.members_of(t):
            bits = ''
            if m.bit_size is not None:
                bits = f':{m.bit_offset}/{m.bit_size}'
            parts.append(f'{m.name or "<anon>"}@{m.offset}{bits}='
                         f'{type_signature(reader, m.type, depth + 1, seen)}')
        return f'{t.kind}({t.name},{t.byte_size}){{{";".join(parts)}}}'
    return f'{t.kind}({t.name},{t.byte_size})'


def member_map(reader, t) -> Dict[str, dict]:
    if t is None or t.kind not in ('struct', 'union'):
        return {}
    out = {}
    for i, m in enumerate(reader.members_of(t)):
        name = m.name or f'<anon{i}>'
        out[name] = {
            'offset': m.offset, 'bit_size': m.bit_size,
            'bit_offset': m.bit_offset,
            'type': (m.type.typedef_name or m.type.name) if m.type else '',
            'sig': type_signature(reader, m.type),
            'size': m.type.byte_size if m.type else None,
        }
    return out


# ---------------------------------------------------------------- 비교
def compare(old_reader, new_reader) -> List[dict]:
    rows: List[dict] = []

    def add(kind, name, detail, old_v='', new_v=''):
        rows.append({'change': kind, 'symbol': name, 'detail': detail,
                     'old': str(old_v), 'new': str(new_v)})

    old = {g.name: g for g in old_reader.globals}
    new = {g.name: g for g in new_reader.globals}

    for n in sorted(set(old) - set(new)):
        g = old[n]
        add('REMOVED', n, '전역변수가 없어짐',
            f'0x{g.address:08X}' if g.address is not None else '<no storage>', '')

    for n in sorted(set(new) - set(old)):
        g = new[n]
        add('ADDED', n, '전역변수가 추가됨', '',
            f'0x{g.address:08X}' if g.address is not None else '<no storage>')

    for n in sorted(set(old) & set(new)):
        a, b = old[n], new[n]

        if a.address != b.address:
            add('ADDR', n, '주소 이동',
                f'0x{a.address:08X}' if a.address is not None else '<no storage>',
                f'0x{b.address:08X}' if b.address is not None else '<no storage>')

        if (a.byte_size or 0) != (b.byte_size or 0):
            add('SIZE', n, '크기 변경', a.byte_size, b.byte_size)

        ta = a.type.typedef_name or a.type.name if a.type else ''
        tb = b.type.typedef_name or b.type.name if b.type else ''
        if ta != tb:
            add('TYPE', n, '타입 이름 변경', ta, tb)

        sa = type_signature(old_reader, a.type)
        sb = type_signature(new_reader, b.type)
        if sa != sb:
            if ta == tb:
                add('LAYOUT', n, f'타입 {ta} 의 레이아웃 변경', '', '')
            _diff_members(old_reader, new_reader, a.type, b.type, n, add)

    return rows


def _diff_members(ro, rn, ta, tb, prefix: str, add, depth: int = 0):
    """구조체 멤버 단위 차이. 배열이면 원소 타입으로 내려간다."""
    if depth > 4 or ta is None or tb is None:
        return
    while ta.kind == 'array' and tb.kind == 'array':
        if ta.dims != tb.dims:
            add('ARRAY', prefix, '배열 차원 변경', ta.dims, tb.dims)
        ta, tb = ta.elem, tb.elem
        if ta is None or tb is None:
            return
    if ta.kind not in ('struct', 'union') or tb.kind not in ('struct', 'union'):
        return

    ma, mb = member_map(ro, ta), member_map(rn, tb)
    for k in ma:
        if k not in mb:
            add('MEMBER-', f'{prefix}.{k}', '멤버 삭제',
                f"@{ma[k]['offset']} {ma[k]['type']}", '')
    for k in mb:
        if k not in ma:
            add('MEMBER+', f'{prefix}.{k}', '멤버 추가', '',
                f"@{mb[k]['offset']} {mb[k]['type']}")
    for k in ma:
        if k not in mb:
            continue
        x, y = ma[k], mb[k]
        if x['offset'] != y['offset']:
            add('OFFSET', f'{prefix}.{k}', '멤버 오프셋 이동',
                f"+{x['offset']}", f"+{y['offset']}")
        if (x['bit_size'], x['bit_offset']) != (y['bit_size'], y['bit_offset']):
            add('BITFIELD', f'{prefix}.{k}', '비트 위치/폭 변경',
                f"{x['bit_offset']}/{x['bit_size']}",
                f"{y['bit_offset']}/{y['bit_size']}")
        if x['type'] != y['type']:
            add('MTYPE', f'{prefix}.{k}', '멤버 타입 변경', x['type'], y['type'])
        elif x['sig'] != y['sig']:
            _diff_members(ro, rn, _member_type(ro, ta, k), _member_type(rn, tb, k),
                          f'{prefix}.{k}', add, depth + 1)


def _member_type(reader, t, name):
    for i, m in enumerate(reader.members_of(t)):
        if (m.name or f'<anon{i}>') == name:
            return m.type
    return None


# ---------------------------------------------------------------- 출력
SEVERITY = {
    'REMOVED': 3, 'MEMBER-': 3, 'SIZE': 3, 'OFFSET': 3, 'BITFIELD': 3,
    'ARRAY': 3, 'TYPE': 2, 'MTYPE': 2, 'LAYOUT': 2, 'MEMBER+': 2,
    'ADDED': 1, 'ADDR': 1,
}


def write_report(rows: List[dict], path: str, meta: dict) -> bool:
    cols = ['change', 'symbol', 'detail', 'old', 'new']
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Alignment, Font, PatternFill
        from openpyxl.utils import get_column_letter
    except ImportError:
        with open(path, 'w', newline='', encoding='utf-8-sig') as f:
            w = csv.writer(f)
            for k, v in meta.items():
                w.writerow([f'# {k}', v])
            w.writerow([])
            w.writerow(cols)
            for r in rows:
                w.writerow([r[c] for c in cols])
        return False

    wb = Workbook()
    ws0 = wb.active
    ws0.title = 'Info'
    ws0['A1'] = 'ELF Watch - 빌드 간 비교'
    ws0['A1'].font = Font(name='Arial', size=13, bold=True)
    r = 3
    for k, v in meta.items():
        ws0.cell(r, 1, k).font = Font(name='Arial', bold=True)
        ws0.cell(r, 2, str(v)).font = Font(name='Arial')
        r += 1
    r += 1
    ws0.cell(r, 1, '변경 종류').font = Font(name='Arial', bold=True)
    r += 1
    for code, desc in (
            ('REMOVED / ADDED', '전역변수 삭제 / 추가'),
            ('ADDR', '주소 이동'),
            ('SIZE', '크기 변경'),
            ('TYPE / MTYPE', '타입 이름 변경 (변수 / 멤버)'),
            ('LAYOUT', '타입 이름은 같은데 레이아웃이 다름'),
            ('MEMBER- / MEMBER+', '구조체 멤버 삭제 / 추가'),
            ('OFFSET', '멤버 오프셋 이동'),
            ('BITFIELD', '비트 위치 또는 폭 변경'),
            ('ARRAY', '배열 차원 변경')):
        ws0.cell(r, 1, code).font = Font(name='Arial', bold=True)
        ws0.cell(r, 2, desc).font = Font(name='Arial')
        r += 1
    ws0.column_dimensions['A'].width = 22
    ws0.column_dimensions['B'].width = 56

    ws = wb.create_sheet('Changes')
    head_font = Font(name='Arial', bold=True, color='FFFFFF')
    head_fill = PatternFill('solid', fgColor='44546A')
    widths = [11, 40, 30, 26, 26]
    for c, (name, wd) in enumerate(zip(cols, widths), 1):
        cell = ws.cell(1, c, name)
        cell.font = head_font
        cell.fill = head_fill
        cell.alignment = Alignment(horizontal='center')
        ws.column_dimensions[get_column_letter(c)].width = wd

    fills = {3: PatternFill('solid', fgColor='FFC9C9'),
             2: PatternFill('solid', fgColor='FFE9C9')}
    mono = Font(name='Consolas', size=10)
    for i, row in enumerate(sorted(
            rows, key=lambda r: (-SEVERITY.get(r['change'], 0), r['symbol'])), 2):
        sev = SEVERITY.get(row['change'], 0)
        for c, name in enumerate(cols, 1):
            cell = ws.cell(i, c, row[name])
            cell.font = mono
            if sev in fills:
                cell.fill = fills[sev]
    ws.freeze_panes = 'A2'
    ws.auto_filter.ref = f'A1:E{len(rows) + 1}'
    wb.save(path)
    return True


def open_source(path: str):
    if path.endswith('.ews'):
        import symstore
        return symstore.StoreSource(path)
    from dwarf_reader import DwarfReader
    return DwarfReader(path)


def summarize(rows: List[dict]) -> Dict[str, int]:
    out: Dict[str, int] = {}
    for r in rows:
        out[r['change']] = out.get(r['change'], 0) + 1
    return out


# ---------------------------------------------------------------- CLI
if __name__ == '__main__':
    args = sys.argv[1:]
    if len(args) < 2:
        print('usage: python builddiff.py <old> <new> [-o report.xlsx]')
        print('  old/new 은 ELF 또는 .ews')
        raise SystemExit(1)
    out = None
    if '-o' in args:
        i = args.index('-o'); out = args[i + 1]; args = args[:i] + args[i + 2:]

    o, n = open_source(args[0]), open_source(args[1])
    rows = compare(o, n)
    counts = summarize(rows)

    print(f'{os.path.basename(args[0])}  ->  {os.path.basename(args[1])}')
    print(f"  전역 {len(o.globals)} -> {len(n.globals)}")
    if not rows:
        print('  차이 없음')
    else:
        print(f'  변경 {len(rows)}건: ' +
              ', '.join(f'{k} {v}' for k, v in sorted(counts.items())))
        for r in sorted(rows, key=lambda r: (-SEVERITY.get(r['change'], 0),
                                             r['symbol']))[:25]:
            arrow = f"  {r['old']} -> {r['new']}" if (r['old'] or r['new']) else ''
            print(f"  [{r['change']:<8}] {r['symbol']:<34} {r['detail']}{arrow}")
        if len(rows) > 25:
            print(f'  ... 외 {len(rows) - 25}건')

    if out:
        meta = {
            'old': args[0], 'new': args[1],
            'old 전역': len(o.globals), 'new 전역': len(n.globals),
            '변경 건수': len(rows),
        }
        xl = write_report(rows, out, meta)
        print(f"\n보고서: {out} ({'xlsx' if xl else 'csv'})")
