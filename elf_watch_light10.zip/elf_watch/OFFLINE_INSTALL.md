# 폐쇄망 오프라인 설치 안내

대상: **Windows x86-64 (Intel PC) / Python 3.12.2**

`wheels/` 안의 4개 휠만으로 인터넷 연결 없이 설치가 끝난다.

## 1. 반입 전 무결성 확인 (인터넷망에서)

```
certutil -hashfile wheels\pyelftools-0.33-py3-none-any.whl SHA256
```

`SHA256SUMS.txt` 의 값과 대조. 전체 목록:

| 파일 | 크기 | 용도 |
|---|---|---|
| `pyelftools-0.33-py3-none-any.whl` | 197 KB | ELF/DWARF 파서 (순수 파이썬, OS 무관) |
| `cryptography-50.0.1-cp311-abi3-win_amd64.whl` | 3.7 MB | AES-256-GCM (OpenSSL) |
| `cffi-2.1.1-cp312-cp312-win_amd64.whl` | 182 KB | cryptography 의존성 |
| `pycparser-3.0-py3-none-any.whl` | 48 KB | cffi 의존성 (OS 무관) |
| `openpyxl-3.1.5-py2.py3-none-any.whl` | 246 KB | xlsx 내보내기 (OS 무관) |
| `et_xmlfile-2.0.0-py3-none-any.whl` | 18 KB | openpyxl 의존성 (OS 무관) |
| `pyqt6-6.11.0-cp310-abi3-win_amd64.whl` | 6.6 MB | PyQt6 바인딩 |
| `pyqt6_qt6-6.11.2-py3-none-win_amd64.whl` | 75 MB | Qt6 런타임 DLL |
| `pyqt6_sip-13.12.0-cp312-cp312-win_amd64.whl` | 53 KB | SIP 런타임 |

`cryptography` 휠에는 OpenSSL 이 정적으로 포함되어 있다. 반입 심사 시
해당 OpenSSL 버전을 함께 기재해야 할 수 있다. 설치 후 확인:

```
python -c "from cryptography.hazmat.backends.openssl.backend import backend; print(backend.openssl_version_text())"
```

## 2. 폐쇄망 PC에서 설치

```
install_offline.bat
```

또는 수동으로:

```
python -m pip install --no-index --find-links=wheels pyelftools cryptography openpyxl PyQt6
```

`--no-index` 가 핵심이다. 이게 없으면 pip 가 PyPI 에 접속을 시도하다 타임아웃 난다.

가상환경을 쓰는 경우:

```
python -m venv .venv
.venv\Scripts\activate
python -m pip install --no-index --find-links=wheels pyelftools cryptography openpyxl PyQt6
```

## 3. 설치 확인

```
python -c "import elftools, cryptography, openpyxl, PyQt6.QtWidgets; print('ok')"
python t32_watch.py sample\fcs_sample_dwarf4.elf
```

## 휠 호환성 메모

- `pyelftools` 는 `py3-none-any` 태그다. **OS·CPU·파이썬 버전 무관**하게
  3.10 이상이면 그대로 쓸 수 있다. 리눅스 서버에도 같은 파일을 쓰면 된다.
- `pyqt6` 는 `cp310-abi3` 태그로 Python 3.10 이상에서 공통 동작한다.
- `cryptography` 는 `cp311-abi3` 이라 Python 3.11 이상에서 공통 동작한다.
- `pyqt6_sip` 과 `cffi` 만 `cp312` 전용이다. 폐쇄망 PC의 파이썬이 3.12가
  아니면 이 두 파일만 해당 버전으로 다시 받아야 한다.

파이썬 버전 확인:

```
python -c "import sys, platform; print(sys.version, platform.machine())"
```

`AMD64` 로 나오면 이 번들이 맞다. `ARM64` 면 다른 휠이 필요하다.

## 다른 환경용 휠을 다시 받을 때 (인터넷망)

```
pip download pyelftools cryptography openpyxl PyQt6 --only-binary=:all: ^
    --python-version 3.12 --platform win_amd64 --implementation cp --abi cp312 ^
    -d wheels
```

리눅스 x86-64 용:

```
pip download pyelftools cryptography openpyxl PyQt6 --only-binary=:all: \
    --python-version 3.12 --platform manylinux_2_28_x86_64 \
    --implementation cp --abi cp312 -d wheels_linux
```

## 최소 구성

GUI 없이 콘솔에서만 쓸 거라면 pyelftools 하나면 충분하다.
PyQt6 75 MB 를 반입 심사에 올릴 필요가 없다.

```
python -m pip install --no-index --find-links=wheels pyelftools
python dwarf_reader.py target.elf 3
python memdump.py dump.csv big
```

심볼 저장소까지 쓰려면 `cryptography` 를 추가한다. 없으면 순수 파이썬
ChaCha20 공급자로 자동 폴백하지만, 그 경우 AES-GCM 으로 만든 기존
저장본은 열지 못한다.

```
python -m pip install --no-index --find-links=wheels pyelftools cryptography
python symstore.py providers
```

데이터 사전을 xlsx 로 내려면 `openpyxl` 을 추가한다. 없으면 CSV 로 나온다.
