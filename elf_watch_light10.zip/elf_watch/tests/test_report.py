"""
test_report.py - 데이터 사전 / 빌드 비교 검증

  1) 데이터 사전: 트리와 행 수·값이 일치하는지, xlsx/CSV 양쪽
  2) 빌드 비교: 의도적으로 넣은 변경을 전부 잡아내는지
                 같은 빌드끼리는 차이 0 인지
                 ELF끼리와 저장본끼리 결과가 같은지

  python3 test_report.py <elf>
"""

import csv
import os
import subprocess
import sys
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))

import builddiff                                   # noqa: E402
import datadict                                    # noqa: E402
import symstore                                    # noqa: E402
from dwarf_reader import DwarfReader               # noqa: E402


# ---------------------------------------------------------------- 데이터 사전
def test_datadict(elf: str) -> int:
    fails = 0
    rd = DwarfReader(elf)
    rows = datadict.flatten(rd, max_depth=6, max_elem=16)

    # 최상위 행은 전역 개수와 같아야 한다
    tops = [r for r in rows if r['depth'] == 0]
    if len(tops) != len(rd.globals):
        print(f'  FAIL 최상위 행 {len(tops)} != 전역 {len(rd.globals)}')
        fails += 1
    else:
        print(f'  OK   최상위 행 = 전역 개수 ({len(tops)})')

    # 오프셋이 주소와 모순되지 않는지
    bad = 0
    by_name = {g.name: g for g in rd.globals}
    for r in rows:
        if r['offset'] == '' or not r['address']:
            continue
        root = by_name.get(r['variable'])
        if root is None or root.address is None:
            continue
        if int(r['address'], 16) - root.address != r['offset']:
            bad += 1
    print(f'  {"OK  " if not bad else "FAIL"} 주소 - 오프셋 정합성 ({len(rows)}행 중 불일치 {bad})')
    fails += bad

    # 비트필드 행은 size 를 비우고 bit_width 를 채운다
    bf = [r for r in rows if r['bit_width'] != '']
    bad = [r for r in bf if r['size'] != '' or not r['bit_pos']]
    print(f'  {"OK  " if not bad else "FAIL"} 비트필드 행 표기 ({len(bf)}건)')
    fails += len(bad)

    # CSV / xlsx 저장 후 행 수 확인
    tmp = tempfile.mkdtemp()
    csv_path = os.path.join(tmp, 'dd.csv')
    info = datadict.export(rd, csv_path)
    with open(csv_path, encoding='utf-8-sig') as f:
        n = sum(1 for _ in csv.reader(f))
    body = n - len([l for l in open(csv_path, encoding='utf-8-sig')
                    if l.startswith('#')]) - 2      # 주석 + 빈 줄 + 헤더
    ok = body == len(rows)
    print(f'  {"OK  " if ok else "FAIL"} CSV 저장 ({body}행)')
    fails += 0 if ok else 1

    xlsx_path = os.path.join(tmp, 'dd.xlsx')
    info = datadict.export(rd, xlsx_path)
    if info['xlsx']:
        from openpyxl import load_workbook
        ws = load_workbook(xlsx_path)['Data Dictionary']
        ok = ws.max_row - 1 == len(rows) and ws.freeze_panes == 'C2'
        print(f'  {"OK  " if ok else "FAIL"} xlsx 저장 ({ws.max_row - 1}행, '
              f'시트 {load_workbook(xlsx_path).sheetnames})')
        fails += 0 if ok else 1
    else:
        print('  --   xlsx 건너뜀 (openpyxl 미설치)')

    # 저장본 소스에서도 같은 결과가 나오는지
    ews = os.path.join(tmp, 's.ews')
    symstore.export_store(elf, ews)
    src = symstore.StoreSource(ews)
    rows2 = datadict.flatten(src, max_depth=6, max_elem=16)
    ok = len(rows) == len(rows2) and all(
        a['path'] == b['path'] and a['type'] == b['type'] and
        a['address'] == b['address'] and a['init_value'] == b['init_value']
        for a, b in zip(rows, rows2))
    print(f'  {"OK  " if ok else "FAIL"} 저장본 소스에서 동일 결과')
    fails += 0 if ok else 1

    rd.close()
    for f in os.listdir(tmp):
        os.unlink(os.path.join(tmp, f))
    os.rmdir(tmp)
    return fails


# ---------------------------------------------------------------- 빌드 비교
V1_SRC = r'''
#include <stdint.h>
typedef struct { uint32_t a:3; uint32_t b:5; uint32_t c:24; } Bits_t;
typedef struct { uint16_t x; uint32_t y; } Pair_t;
typedef enum { E_A = 0, E_B = 1 } Mode_t;
typedef struct { Pair_t p; Bits_t f; uint8_t tail; } Big_t;
int32_t  g_scalar = 1;
uint32_t g_arr[4] = {1, 2, 3, 4};
Bits_t   g_bits   = {1, 2, 3};
Big_t    g_big;
Mode_t   g_mode   = E_B;
uint32_t g_gone   = 7;
void _start(void) { g_gone++; for (;;) { } }
'''

V2_SRC = r'''
#include <stdint.h>
typedef struct { uint32_t a:3; uint32_t b:7; uint32_t c:22; } Bits_t;
typedef struct { uint16_t x; uint32_t y; uint16_t z; } Pair_t;
typedef enum { E_A = 0, E_B = 1, E_C = 2 } Mode_t;
typedef struct { Pair_t p; Bits_t f; uint8_t tail; } Big_t;
int16_t  g_scalar = 1;
uint32_t g_arr[8] = {1, 2, 3, 4, 5, 6, 7, 8};
Bits_t   g_bits   = {1, 2, 3};
Big_t    g_big;
Mode_t   g_mode   = E_B;
uint32_t g_added  = 9;
void _start(void) { g_added++; for (;;) { } }
'''

# (변경 종류, 심볼) - 반드시 잡혀야 하는 항목
EXPECTED = [
    ('REMOVED', 'g_gone'),
    ('ADDED', 'g_added'),
    ('SIZE', 'g_scalar'),
    ('TYPE', 'g_scalar'),
    ('SIZE', 'g_arr'),
    ('ARRAY', 'g_arr'),
    ('BITFIELD', 'g_bits.b'),
    ('BITFIELD', 'g_bits.c'),
    ('MEMBER+', 'g_big.p.z'),
    ('LAYOUT', 'g_mode'),
]


def _build(src: str, out: str, ld: str) -> bool:
    c = out + '.c'
    with open(c, 'w') as f:
        f.write(src)
    r = subprocess.run(
        ['powerpc-linux-gnu-gcc', '-mbig-endian', '-m32', '-O0', '-gdwarf-4',
         '-ffreestanding', '-nostdlib', '-nostartfiles', '-T', ld, '-o', out, c],
        capture_output=True)
    return r.returncode == 0


def test_builddiff(ld: str) -> int:
    tmp = tempfile.mkdtemp()
    v1 = os.path.join(tmp, 'v1.elf')
    v2 = os.path.join(tmp, 'v2.elf')
    if not (_build(V1_SRC, v1, ld) and _build(V2_SRC, v2, ld)):
        print('  --   powerpc-linux-gnu-gcc 없음, 건너뜀')
        return 0

    fails = 0
    o, n = DwarfReader(v1), DwarfReader(v2)
    rows = builddiff.compare(o, n)
    found = {(r['change'], r['symbol']) for r in rows}

    missing = [e for e in EXPECTED if e not in found]
    print(f'  {"OK  " if not missing else "FAIL"} 의도한 변경 탐지 '
          f'({len(EXPECTED) - len(missing)}/{len(EXPECTED)})  전체 {len(rows)}건')
    for m in missing:
        print(f'       놓침: {m[0]} {m[1]}')
    fails += len(missing)

    # 같은 빌드끼리는 차이 0
    same = builddiff.compare(DwarfReader(v1), DwarfReader(v1))
    ok = not same
    print(f'  {"OK  " if ok else "FAIL"} 동일 빌드 비교 = 차이 0 ({len(same)}건)')
    fails += 0 if ok else 1

    # 저장본끼리 비교해도 같은 결과
    s1, s2 = os.path.join(tmp, 'v1.ews'), os.path.join(tmp, 'v2.ews')
    symstore.export_store(v1, s1)
    symstore.export_store(v2, s2)
    rows_s = builddiff.compare(symstore.StoreSource(s1), symstore.StoreSource(s2))
    ok = ({(r['change'], r['symbol']) for r in rows_s} == found
          and len(rows_s) == len(rows))
    print(f'  {"OK  " if ok else "FAIL"} 저장본끼리 비교 = ELF끼리와 동일 '
          f'({len(rows_s)}건)')
    fails += 0 if ok else 1

    # 저장본 vs 자기 ELF = 차이 0
    cross = builddiff.compare(symstore.StoreSource(s1), DwarfReader(v1))
    ok = not cross
    print(f'  {"OK  " if ok else "FAIL"} 저장본 vs 원본 ELF = 차이 0 ({len(cross)}건)')
    fails += 0 if ok else 1

    # 보고서 저장
    rp = os.path.join(tmp, 'diff.xlsx')
    xl = builddiff.write_report(rows, rp, {'old': v1, 'new': v2,
                                           '변경 건수': len(rows)})
    ok = os.path.getsize(rp) > 0
    print(f'  {"OK  " if ok else "FAIL"} 보고서 저장 ({"xlsx" if xl else "csv"})')
    fails += 0 if ok else 1

    o.close(); n.close()
    for f in os.listdir(tmp):
        os.unlink(os.path.join(tmp, f))
    os.rmdir(tmp)
    return fails


def main():
    if len(sys.argv) < 2:
        print('usage: python3 test_report.py <elf>')
        return 1
    fails = 0
    print('=== 데이터 사전 ===')
    fails += test_datadict(sys.argv[1])
    print('=== 빌드 비교 ===')
    ld = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                      '..', 'sample', 'mpc5674f_like.ld')
    fails += test_builddiff(ld)
    print('  ALL PASS' if not fails else f'  실패 {fails}건')
    return 1 if fails else 0


if __name__ == '__main__':
    sys.exit(main())
