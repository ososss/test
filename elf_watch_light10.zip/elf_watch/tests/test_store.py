"""
test_store.py - 암호화 심볼 저장소 검증

  1) ChaCha20 을 RFC 8439 테스트 벡터로 확인
  2) 암복호 왕복 / 키 불일치 / 변조 탐지
  3) ELF 로 직접 만든 트리와 저장본에서 복원한 트리가 완전히 같은지 대조

  python3 test_store.py <elf> [elf ...]
"""

import binascii
import os
import sys
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))

import crypto                                     # noqa: E402
import symstore as S                              # noqa: E402
from dwarf_reader import DwarfReader              # noqa: E402


def test_vectors() -> int:
    """두 공급자를 공개 테스트 벡터로 확인."""
    fails = 0

    # ChaCha20 - RFC 8439 §2.3.2
    key = bytes(range(32))
    nonce = bytes.fromhex('000000090000004a00000000')
    got = binascii.hexlify(crypto._chacha20_block(key, 1, nonce)[:16]).decode()
    want = '10f1e7e4d13b5915500fdd1fa32071c4'
    ok = got == want
    print(f'  {"OK  " if ok else "FAIL"} ChaCha20 RFC 8439 §2.3.2 벡터')
    if not ok:
        print(f'       got  {got}\n       want {want}')
        fails += 1

    # AES-256-GCM - NIST GCM 테스트 벡터 (Case 14, 256bit key, 빈 평문)
    aes = crypto.get_provider('aesgcm256')
    if not aes.available:
        print('  --   AES-256-GCM 벡터 (cryptography 미설치, 건너뜀)')
    else:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        k = bytes(32)
        iv = bytes(12)
        ct = AESGCM(k).encrypt(iv, b'', None)
        want_tag = '530f8afbc74536b9a963b4f1c4cb738b'
        ok = binascii.hexlify(ct).decode() == want_tag
        print(f'  {"OK  " if ok else "FAIL"} AES-256-GCM NIST 벡터')
        if not ok:
            fails += 1
    return fails


def test_providers() -> int:
    """공급자별 왕복, 교차 호환, 키 지문 검사."""
    fails = 0
    key = os.urandom(32)
    for name in ('aesgcm256', 'chacha20'):
        p = crypto.get_provider(name)
        if not p.available:
            print(f'  --   {name} 사용 불가, 건너뜀')
            continue
        bad = 0
        for size in (0, 1, 63, 64, 65, 100000):
            data = os.urandom(size)
            if crypto.unseal(crypto.seal(data, key, name), key) != data:
                bad += 1
        print(f'  {"OK  " if not bad else "FAIL"} {name} 왕복 (0~100KB)  '
              f'{p.describe()}')
        fails += bad

        # 공급자 이름이 파일에 기록되는지
        blob = crypto.seal(b'x', key, name)
        pn, kid, _ = crypto.peek(blob)
        if pn != name or kid != crypto.key_id(key):
            print(f'  FAIL {name} 헤더 기록 오류 ({pn}, {kid})')
            fails += 1

    # 다른 키로 만든 파일은 키 지문 단계에서 명확히 거부
    blob = crypto.seal(b'payload', key)
    try:
        crypto.unseal(blob, os.urandom(32))
        print('  FAIL 다른 키가 통과됨')
        fails += 1
    except RuntimeError as e:
        ok = '다른 키' in str(e)
        print(f'  {"OK  " if ok else "FAIL"} 다른 키 거부 (키 지문으로 즉시 판별)')
        if not ok:
            fails += 1

    # 변조 탐지
    bad = bytearray(blob)
    bad[-1] ^= 0x01
    try:
        crypto.unseal(bytes(bad), key)
        print('  FAIL 변조가 통과됨')
        fails += 1
    except RuntimeError:
        print('  OK   변조 탐지 (GCM 인증 태그)')

    # 내장 키로 만든 파일을 내장 키로 열기
    blob = crypto.seal(b'embedded test', S.embedded_key())
    if crypto.unseal(blob, S.embedded_key()) != b'embedded test':
        print('  FAIL 내장 키 왕복 실패')
        fails += 1
    else:
        print(f'  OK   내장 키 왕복 (지문 {crypto.key_id(S.embedded_key())})')
    return fails


def test_format() -> int:
    fails = 0
    try:
        crypto.unseal(b'not a store file', os.urandom(32))
        print('  FAIL 잘못된 형식이 통과됨')
        fails += 1
    except RuntimeError:
        print('  OK   형식 오류 거부')
    return fails


def walk(rd, max_nodes=40000):
    """path -> (값, 타입, 주소, 크기) 전체 트리를 평탄화."""
    out = {}
    stack = [(g, 0, g.name) for g in rd.globals]
    n = 0
    while stack and n < max_nodes:
        node, depth, path = stack.pop()
        n += 1
        out[path] = (node.value_text(), node.value_text(True),
                     node.type_text, node.address_text, node.size_text)
        if depth < 8 and node.has_children():
            kids = node.children()
            if node.type and node.type.kind == 'array':
                kids = kids[:8]
            if node.type and node.type.kind == 'pointer':
                continue
            for k in kids:
                nm = k.name
                stack.append((k, depth + 1,
                              path + (nm if nm.startswith('[') else '.' + nm)))
    return out


def test_roundtrip(elf: str, provider=None) -> int:
    tmp = tempfile.mkdtemp()
    keyf = os.path.join(tmp, 'test.key')
    store = os.path.join(tmp, 'test' + S.STORE_EXT)
    S.generate_key_file(keyf)
    key = S.load_key_file(keyf)

    info = S.export_store(elf, store, key, provider=provider)
    rd = DwarfReader(elf)
    src = S.StoreSource(store, key)

    a = walk(rd)
    b = walk(src)

    only_a = set(a) - set(b)
    only_b = set(b) - set(a)
    diff = [k for k in set(a) & set(b) if a[k] != b[k]]

    ok = not (only_a or only_b or diff)
    print(f'  {"OK  " if ok else "FAIL"} {os.path.basename(elf):<24} '
          f'[{info["provider"]:<9}] 노드 {len(a)}개  전역 {info["globals"]}  '
          f'파일 {info["file"]:,}B')
    for k in list(only_a)[:3]:
        print(f'       ELF 에만 있음: {k}')
    for k in list(only_b)[:3]:
        print(f'       저장본에만 있음: {k}')
    for k in diff[:3]:
        print(f'       불일치 {k}:\n         ELF   {a[k]}\n         STORE {b[k]}')

    # 메타데이터 확인
    meta = src.summary()
    if meta['endian'] != ('big' if rd.big_endian else 'little'):
        print('       FAIL 엔디안 불일치')
        ok = False
    if meta['sha256'] != info['sha256']:
        print('       FAIL SHA256 불일치')
        ok = False

    rd.close()
    for f in (keyf, store):
        os.unlink(f)
    os.rmdir(tmp)
    return 0 if ok else 1


def main():
    elfs = sys.argv[1:]
    if not elfs:
        print('usage: python3 test_store.py <elf> [elf ...]')
        return 1
    fails = 0
    print('=== 암호 테스트 벡터 ===')
    fails += test_vectors()
    print('=== 공급자 ===')
    fails += test_providers()
    fails += test_format()
    print('=== ELF vs 저장본 트리 대조 ===')
    for e in elfs:
        for prov in ('aesgcm256', 'chacha20'):
            if crypto.get_provider(prov).available:
                fails += test_roundtrip(e, prov)
    print('  ALL PASS' if not fails else f'  실패 {fails}건')
    return 1 if fails else 0


if __name__ == '__main__':
    sys.exit(main())
