"""
crypto.py - 암호 공급자(provider) 계층

심볼 저장소가 쓰는 암호를 교체 가능하게 분리한다.

  AesGcmProvider   AES-256-GCM  (cryptography / OpenSSL)   - 기본값
  StdlibProvider   ChaCha20 + HMAC-SHA256 (순수 파이썬)     - 폴백
  KcmvpProvider    사내 검증필 모듈 연동 지점               - 미구현 훅

파일 헤더에 어느 공급자로 암호화했는지와 키 식별자를 남긴다.
나중에 다른 공급자로 바꿔도 옛 파일을 계속 읽을 수 있고,
감사 시 어떤 암호가 쓰였는지 확인할 수 있다.

── 인증에 관한 사실 ─────────────────────────────────────────
암호 인증(KCMVP 검증필, FIPS 140-3)은 라이브러리가 아니라
'특정 모듈 빌드 + 버전 + 운용환경' 조합에 부여된다.
AES-256-GCM 은 표준 알고리즘이고 OpenSSL 구현은 널리 검토되었지만,
이 코드를 쓴다고 해서 시스템이 검증필이 되지는 않는다.
기관의 비밀자료 취급 규정이 있다면 그쪽이 우선한다.
"""

from __future__ import annotations

import hashlib
import hmac
import os
import secrets
import struct
from typing import Dict, Optional

MAGIC = b'EWSYM2\n'          # 공급자 식별자를 담는 2차 포맷


# ==================================================================== 공통
def key_id(key: bytes) -> str:
    """키 자체를 노출하지 않고 키를 식별하는 8자리 지문."""
    return hashlib.sha256(b'elfwatch-keyid\x00' + key).hexdigest()[:8]


class CryptoProvider:
    name = 'none'
    label = '없음'

    @property
    def available(self) -> bool:
        return True

    def encrypt(self, payload: bytes, key: bytes) -> bytes:
        raise NotImplementedError

    def decrypt(self, body: bytes, key: bytes) -> bytes:
        raise NotImplementedError

    def describe(self) -> str:
        return self.label


# ==================================================================== AES-GCM
class AesGcmProvider(CryptoProvider):
    """AES-256-GCM. cryptography(OpenSSL) 사용."""

    name = 'aesgcm256'
    label = 'AES-256-GCM (OpenSSL)'

    def __init__(self):
        try:
            from cryptography.hazmat.primitives.ciphers.aead import AESGCM
            self._AESGCM = AESGCM
            self._ok = True
        except Exception:
            self._AESGCM = None
            self._ok = False

    @property
    def available(self) -> bool:
        return self._ok

    def _derive(self, key: bytes) -> bytes:
        # 저장소 전용 키로 분리 (키 파일을 다른 용도와 공유해도 섞이지 않게)
        return hmac.new(key, b'elfwatch-aesgcm-v1', hashlib.sha256).digest()

    def encrypt(self, payload: bytes, key: bytes) -> bytes:
        if not self._ok:
            raise RuntimeError(
                'cryptography 패키지가 없어 AES-GCM 을 쓸 수 없습니다. '
                'wheels/ 에서 설치하거나 stdlib 공급자를 지정하세요.')
        nonce = secrets.token_bytes(12)
        ct = self._AESGCM(self._derive(key)).encrypt(nonce, payload, MAGIC)
        return nonce + ct

    def decrypt(self, body: bytes, key: bytes) -> bytes:
        if not self._ok:
            raise RuntimeError(
                '이 파일은 AES-256-GCM 으로 암호화되었습니다. '
                'cryptography 패키지를 설치해야 열 수 있습니다.')
        if len(body) < 12 + 16:
            raise RuntimeError('파일이 손상되었습니다(길이 부족).')
        nonce, ct = body[:12], body[12:]
        try:
            return self._AESGCM(self._derive(key)).decrypt(nonce, ct, MAGIC)
        except Exception:
            raise RuntimeError('키가 맞지 않거나 파일이 변조되었습니다.')

    def describe(self) -> str:
        if not self._ok:
            return self.label + ' [사용 불가 - cryptography 미설치]'
        try:
            from cryptography.hazmat.backends.openssl.backend import backend
            return f'{self.label} / {backend.openssl_version_text()}'
        except Exception:
            return self.label


# ==================================================================== stdlib
def _chacha20_block(key: bytes, counter: int, nonce: bytes) -> bytes:
    def rotl(x, n):
        return ((x << n) | (x >> (32 - n))) & 0xFFFFFFFF

    st = list(struct.unpack('<4I', b'expand 32-byte k'))
    st += list(struct.unpack('<8I', key))
    st.append(counter & 0xFFFFFFFF)
    st += list(struct.unpack('<3I', nonce))
    w = st[:]

    def qr(a, b, c, d):
        w[a] = (w[a] + w[b]) & 0xFFFFFFFF
        w[d] = rotl(w[d] ^ w[a], 16)
        w[c] = (w[c] + w[d]) & 0xFFFFFFFF
        w[b] = rotl(w[b] ^ w[c], 12)
        w[a] = (w[a] + w[b]) & 0xFFFFFFFF
        w[d] = rotl(w[d] ^ w[a], 8)
        w[c] = (w[c] + w[d]) & 0xFFFFFFFF
        w[b] = rotl(w[b] ^ w[c], 7)

    for _ in range(10):
        qr(0, 4, 8, 12); qr(1, 5, 9, 13); qr(2, 6, 10, 14); qr(3, 7, 11, 15)
        qr(0, 5, 10, 15); qr(1, 6, 11, 12); qr(2, 7, 8, 13); qr(3, 4, 9, 14)
    return struct.pack('<16I', *[(w[i] + st[i]) & 0xFFFFFFFF for i in range(16)])


def _chacha20(key: bytes, nonce: bytes, data: bytes, counter: int = 1) -> bytes:
    out = bytearray(len(data))
    for i in range(0, len(data), 64):
        ks = _chacha20_block(key, counter + i // 64, nonce)
        chunk = data[i:i + 64]
        out[i:i + len(chunk)] = bytes(a ^ b for a, b in zip(chunk, ks))
    return bytes(out)


class StdlibProvider(CryptoProvider):
    """ChaCha20 + HMAC-SHA256. 표준 라이브러리만 사용(추가 반입 없음)."""

    name = 'chacha20'
    label = 'ChaCha20 + HMAC-SHA256 (순수 파이썬)'

    def _subkeys(self, key: bytes):
        return (hmac.new(key, b'elfwatch-enc-v1', hashlib.sha256).digest(),
                hmac.new(key, b'elfwatch-mac-v1', hashlib.sha256).digest())

    def encrypt(self, payload: bytes, key: bytes) -> bytes:
        enc, mac = self._subkeys(key)
        nonce = secrets.token_bytes(12)
        ct = _chacha20(enc, nonce, payload)
        tag = hmac.new(mac, MAGIC + nonce + ct, hashlib.sha256).digest()
        return nonce + ct + tag

    def decrypt(self, body: bytes, key: bytes) -> bytes:
        if len(body) < 12 + 32:
            raise RuntimeError('파일이 손상되었습니다(길이 부족).')
        nonce, ct, tag = body[:12], body[12:-32], body[-32:]
        enc, mac = self._subkeys(key)
        want = hmac.new(mac, MAGIC + nonce + ct, hashlib.sha256).digest()
        if not hmac.compare_digest(tag, want):
            raise RuntimeError('키가 맞지 않거나 파일이 변조되었습니다.')
        return _chacha20(enc, nonce, ct)


# ==================================================================== KCMVP 훅
class KcmvpProvider(CryptoProvider):
    """사내 KCMVP 검증필 모듈 연동 지점.

    검증필 모듈을 받으면 아래 두 메서드만 그 모듈의 API 로 채우면 된다.
    파일 포맷과 나머지 코드는 손댈 필요가 없다.

    확인할 것:
      - 검증필 모듈의 알고리즘(ARIA-256 / SEED / LEA)과 운용 모드
      - 모듈이 요구하는 키 길이와 IV/nonce 생성 규칙
      - 무결성 태그를 모듈이 제공하는지, 아니면 별도 MAC 이 필요한지
      - 모듈 초기화(자가시험) 호출 시점
    """

    name = 'kcmvp'
    label = 'KCMVP 검증필 모듈 (미구현)'

    @property
    def available(self) -> bool:
        return False

    def encrypt(self, payload: bytes, key: bytes) -> bytes:
        raise NotImplementedError(
            'KCMVP 공급자가 아직 연결되지 않았습니다. '
            'crypto.py 의 KcmvpProvider 를 사내 검증필 모듈로 채우세요.')

    def decrypt(self, body: bytes, key: bytes) -> bytes:
        raise NotImplementedError(
            'KCMVP 공급자가 아직 연결되지 않았습니다. '
            'crypto.py 의 KcmvpProvider 를 사내 검증필 모듈로 채우세요.')


# ==================================================================== 레지스트리
_PROVIDERS: Dict[str, CryptoProvider] = {}
for _p in (AesGcmProvider(), StdlibProvider(), KcmvpProvider()):
    _PROVIDERS[_p.name] = _p


def get_provider(name: Optional[str] = None) -> CryptoProvider:
    """이름으로 공급자를 얻는다. 이름이 없으면 기본값(AES-GCM, 없으면 stdlib)."""
    if name:
        p = _PROVIDERS.get(name)
        if p is None:
            raise RuntimeError(f'알 수 없는 암호 공급자입니다: {name}')
        return p
    aes = _PROVIDERS['aesgcm256']
    return aes if aes.available else _PROVIDERS['chacha20']


def available_providers():
    return [(n, p.describe(), p.available) for n, p in _PROVIDERS.items()]


# ==================================================================== 봉투
def seal(payload: bytes, key: bytes, provider: Optional[str] = None) -> bytes:
    """헤더(공급자·키 지문) + 암호문."""
    p = get_provider(provider)
    header = f'{p.name}:{key_id(key)}'.encode('ascii')
    body = p.encrypt(payload, key)
    return MAGIC + bytes([len(header)]) + header + body


def peek(blob: bytes):
    """복호화하지 않고 공급자 이름과 키 지문만 읽는다."""
    if not blob.startswith(MAGIC):
        raise RuntimeError('심볼 저장 파일 형식이 아닙니다.')
    n = blob[len(MAGIC)]
    header = blob[len(MAGIC) + 1:len(MAGIC) + 1 + n].decode('ascii')
    pname, _, kid = header.partition(':')
    return pname, kid, len(MAGIC) + 1 + n


def unseal(blob: bytes, key: bytes) -> bytes:
    pname, kid, off = peek(blob)
    if kid != key_id(key):
        raise RuntimeError(
            f'다른 키로 암호화된 파일입니다 (파일 키 {kid}, 현재 키 {key_id(key)}).')
    return get_provider(pname).decrypt(blob[off:], key)


# ==================================================================== CLI
if __name__ == '__main__':
    print('사용 가능한 암호 공급자:')
    for n, desc, ok in available_providers():
        print(f"  {'O' if ok else 'X'} {n:<11} {desc}")
    print(f'\n기본값: {get_provider().name}')
