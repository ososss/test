# ELF Watch — TRACE32 Watch View 스타일 전역변수 뷰어

ELF 안의 DWARF 디버깅 정보만으로 전역변수 목록과 타입 트리를 뽑아
TRACE32 `Var.Watch` 와 유사한 형태로 보여주는 PyQt6 도구. **소스코드는 필요 없다.**

```
symbol                     value                    type                address        size
─────────────────────────────────────────────────────────────────────────────────────────────
▼ g_bus1_status            {...}                    BusStatusBits_t     0x400000B4        4
    valid                  1                        u32 : 1             0x400000B4.0    1 bit
    stale                  0                        u32 : 1             0x400000B4.1    1 bit
    channel_id             5                        u32 : 3             0x400000B4.2    3 bit
    subaddress             17                       u32 : 5             0x400000B4.5    5 bit
▼ g_gain_table             (3)                      f32[3][4]           0x40000060       48
  ▼ [0]                    (4) {1, 2, 3, 4}         f32[4]              0x40000060       16
      [0]                  1                        f32                 0x40000060        4
▼ g_fault_head             0x40000248 <g_fault_pool> FaultNode_t *      0x400000C4        4
  ▼ *g_fault_head          {...}                    FaultNode_t         0x40000248       12
```

## 실행

```bash
pip install pyelftools cryptography PyQt6
python t32_watch.py sample/fcs_sample_dwarf4.elf
```

덤프까지 얹어 보려면 실행 후 **Load Dump** (Ctrl+D) 로
`sample/fcs_dump_3ch.log` 를 여세요. 채널 C 에 불일치 두 곳이 들어 있습니다.

GUI 없이 콘솔에서 확인:

```bash
python dwarf_reader.py sample/fcs_sample_dwarf4.elf 3     # 마지막 인자 = 전개 깊이
```

## 파일 구성

| 파일 | 내용 |
|---|---|
| `dwarf_reader.py` | DWARF 파싱 · 타입 해석 · 값 디코딩 (GUI 비의존, 단독 사용 가능) |
| `memdump.py` | 메모리 덤프(.csv/.log) 파서 (GUI 비의존, 단독 사용 가능) |
| `crypto.py` | 암호 공급자 계층 (AES-256-GCM / ChaCha20 / KCMVP 훅) |
| `symstore.py` | 심볼 정보 암호화 보관 / ELF 없이 복원 |
| `t32_watch.py` | PyQt6 GUI (`QAbstractItemModel` + `QTreeView`) |
| `sample/fcs_sample.c` | 검증용 샘플 소스 |
| `sample/mpc5674f_like.ld` | MPC5674F 유사 메모리 맵 (Flash 0x0000_0000 / SRAM 0x4000_0000) |
| `sample/fcs_sample_dwarf{2,4,5}.elf` | **32bit 빅엔디안 PowerPC** ELF (DWARF 2 / 4 / 5) |
| `sample/fcs_dump_3ch.log` | 위 ELF 에 맞는 3채널 덤프 (채널 C 에 불일치 2곳) |
| `sample/dump_example{1,2}.{log,csv}` | 두 가지 덤프 형식 최소 예제 |

샘플 ELF 생성 명령:

```bash
powerpc-linux-gnu-gcc -mbig-endian -m32 -O0 -gdwarf-4 -g3 \
    -ffreestanding -nostdlib -nostartfiles \
    -T mpc5674f_like.ld -o fcs_sample_dwarf4.elf fcs_sample.c
```

## 메모리 덤프 (.csv / .log) 연동

실제 타깃에서 뽑은 덤프를 얹어 **삼중화 채널 3개의 값을 나란히** 볼 수 있다.

```
symbol            Channel A    Channel B    Channel C    type            address
▼ ⚠ g_bus1_status  {...}        {...}        {...}       BusStatusBits_t 0x400000B4
    valid          1            1            1           u32 : 1         0x400000B4.0
    channel_id     5            5            5           u32 : 3         0x400000B4.2
  ⚠ word_count     32           32           36          u32 : 6         0x400000B5.2
```

- **채널 불일치 자동 강조** — 리프 단위로 비교하고 상위 노드까지 전파한다.
  비트필드는 추출값으로, 나머지는 원시 바이트로 비교하므로
  구조체·배열도 한 번에 걸린다.
- **덤프 변수만 보기** 토글 — 덤프에 주소가 들어있는 전역만 남긴다.
- 불일치는 아이콘 없이 **색으로만** 표시한다(행 배경 + 값 글자).
- 덤프에 없는 주소는 `<no data>` 로 표시된다.

### 지원 형식

`Address` 가 나오는 헤더 줄을 찾고 그 다음 줄부터 hex 토큰만 뽑는다.
구분자를 신뢰하지 않으므로 아래 두 가지가 같은 방식으로 처리된다.

```
 Address    Channel A     Channel B     Channel C
0x40000000     0xaaaaaaaa  0xaaaaaaaa 0xaaaaaaaa
```

```
Address, Ch_A, ,Ch_B, ,Ch_C
="40000000" ,="aaaa",="aaaa" ,="aaaa",="aaaa" ,"aaaa",="aaaa" ,
```

`0x` 유무, `="..."` 포장, 따옴표, 쉼표, 다중 공백, 탭, CRLF, BOM 을 흡수한다.
채널당 값이 2칸인 경우(16비트 상/하위 분할)는 **상위+하위 순서로 32비트 한 값**
으로 합친다. 채널 수와 워드 폭은 헤더와 데이터에서 추론하며, 추론에 의존한
경우 상태바에 알린다.

콘솔에서 덤프만 확인하려면:

```bash
python memdump.py dump.csv big     # big | little
```

## 심볼 정보 암호화 보관

ELF 원본을 들고 다니지 않기 위한 기능이다. 전역 목록과 타입 그래프(멤버
오프셋, 비트필드 위치, 배열 차원, enum)를 뽑아 암호화해 두고, 나중에
**ELF 없이** 같은 트리를 연다. 초기값(섹션 이미지)도 함께 담기므로
저장본 하나로 덤프 대조까지 된다.

툴바 오른쪽 `symbols:` 콤보박스에서 고른다. 초기값은 `(none)`.
보관 위치는 `~/.elfwatch/symbols/`, 확장자는 `.ews`.

```bash
python symstore.py export fcs.elf fcs_v1.4.2.ews     # 내장 키 사용
python symstore.py info   fcs_v1.4.2.ews
python symstore.py providers                          # 사용 가능한 암호 확인
```

원본 ELF 의 SHA256 이 함께 저장되어, 덤프와 짝이 맞는 빌드인지 확인할 수 있다.

### 암호 공급자

`crypto.py` 가 암호를 교체 가능하게 분리한다. 파일 헤더에 어느 공급자로
암호화했는지와 키 지문이 기록되므로, 나중에 공급자를 바꿔도 옛 파일을
계속 읽을 수 있고 감사 시 확인이 된다.

| 공급자 | 내용 |
|---|---|
| `aesgcm256` | **AES-256-GCM** (cryptography / OpenSSL) — 기본값 |
| `chacha20` | ChaCha20 + HMAC-SHA256 (순수 파이썬) — cryptography 없을 때 폴백 |
| `kcmvp` | 사내 KCMVP 검증필 모듈 연동 지점 (미구현 훅) |

검증필 모듈을 받으면 `crypto.py` 의 `KcmvpProvider` 의 `encrypt` / `decrypt`
두 메서드만 채우면 된다. 파일 포맷과 나머지 코드는 손댈 필요가 없다.
클래스 주석에 확인할 항목(알고리즘·모드, 키 길이, IV 규칙, 자가시험 호출
시점)을 적어 두었다.

### 키

기본적으로 **도구에 내장된 키**를 쓴다. 키 파일을 따로 들고 다니지 않아도
되지만, 그 성질을 분명히 알고 써야 한다.

> **내장 키는 비밀이 아니다.** 도구 배포본을 가진 사람은 누구나 읽을 수 있다.
> 따라서 내장 키로 만든 저장본은 `.ews` 파일만 유출된 경우에는 보호되지만,
> 도구까지 함께 나가면 보호되지 않는다.
> **도구 배포본을 키와 같은 등급으로 관리할 것.**

더 조이려면 키 파일을 만들어 쓴다. 키 파일이 있으면 그쪽이 우선한다.
GUI 에서는 툴바의 `Key...` 로 지정한다.

```bash
python symstore.py genkey team.key
python symstore.py export fcs.elf fcs_v1.4.2.ews team.key
```

### 인증에 관한 사실

AES-256-GCM 은 표준 알고리즘이고 OpenSSL 구현은 널리 검토되었지만,
**이 도구를 쓴다고 시스템이 검증필이 되지는 않는다.** 암호 인증(KCMVP,
FIPS 140-3)은 라이브러리가 아니라 '특정 모듈 빌드 + 버전 + 운용환경'
조합에 부여된다. 기관의 비밀자료 취급 규정이 있다면 그쪽이 우선하며,
이 기능은 ELF 원본을 들고 다니지 않기 위한 수단이지 등급 하향 근거가 아니다.

또 하나 — **"이 도구에서만 복호화되게" 는 구현할 수 없다.** 표시하려면
도구가 복호화해야 하고, 그 순간 키와 평문이 프로세스 메모리에 존재한다.
통제 가능한 것은 '누가, 어디서 복호화할 수 있는가'(키 관리, 머신 고정,
감사 로그)이지 '어떤 프로그램이 복호화하는가'가 아니다.

## 기능

- 전역변수 자동 수집 (`DW_TAG_variable` + `DW_OP_addr` / `DW_OP_addrx`)
- 구조체 · 공용체 · 익명 union · 다차원 배열 · enum · typedef · 포인터 전개
- **비트필드**: DWARF 2/3 의 `DW_AT_bit_offset` 과 DWARF 4/5 의 `DW_AT_data_bit_offset`
  양쪽 인코딩 지원, 엔디안별 시프트 방향 처리
- 값 표시: ELF 섹션 이미지에서 읽은 **정적 초기값** (`.bss` 는 0)
- Hex / Dec 토글 (`Ctrl+H`) — float/double 도 **원시 비트 패턴**으로 표시
- 베이스 주소 지정 (`Ctrl+B`) — 지정한 행 이후는 `+0x0004` 형태의 오프셋으로 표시
- 심볼 필터, CSV 내보내기
- 자식 노드 지연 생성 → 512 요소 배열도 즉시 로드

## 설계 메모

**엔디안** — MPC5674F 는 빅엔디안이라 비트필드 시프트가 리틀엔디안과 반대다.

- DWARF 2/3, BE: `DW_AT_bit_offset` 이 이미 컨테이너 MSB 기준 → 그대로 사용
- DWARF 2/3, LE: `container_bits - bit_offset - bit_size` 로 LSB 기준 변환
- DWARF 4/5: `DW_AT_data_bit_offset` 은 구조체 시작부터 메모리 증가 방향 기준.
  저장 단위 경계로 재정렬한 뒤 위와 동일하게 처리

GCC 13 기준 `-gdwarf-4` 는 여전히 `DW_AT_bit_offset` 을, `-gdwarf-5` 는
`DW_AT_data_bit_offset` 을 낸다. 세 버전 모두 동일 결과를 내는 것으로 검증했다.

**자기참조 방어** — `TypeInfo` 를 DIE offset 캐시에 *먼저 등록한 뒤* 채운다.
포인터 전개는 `MAX_POINTER_DEPTH = 3` 으로 제한.

## CodeWarrior ELF 적용 시 확인할 것

0. **다른 컴파일러의 DWARF 방언**. clang 검증에서 GCC 와 다른 인코딩
   (부호 없는 form 에 담긴 음수 비트 오프셋)이 드러났다. CodeWarrior 도
   자체 방언이 있을 수 있으므로, 실물 ELF 로 한 번은 대조 검증하는 것이 좋다.

1. **DWARF 버전**. CodeWarrior PowerPC 구버전은 DWARF 1.x 를 내는 경우가 있고
   pyelftools 는 이를 지원하지 않는다. 먼저 확인:
   ```bash
   readelf --debug-dump=info target.elf | grep -m1 Version
   ```
   버전 2 이상이면 그대로 동작한다.

2. **`DW_AT_data_member_location` 형식**. 컴파일러에 따라 상수 대신
   `DW_OP_plus_uconst` 표현식으로 나온다. 두 경우 모두 처리해 두었다.

3. **최적화 레벨**. `-O2` 이상에서는 전역이 제거되거나 주소가 합쳐질 수 있다.
   DAL A/B 빌드는 보통 최적화가 제한적이라 문제되지 않는다.

4. **`--strip-debug` 여부**. 링커 맵과 별개로 디버그 섹션이 남아 있어야 한다.

5. **섹션 배치**. 값 표시는 `SHF_ALLOC` 섹션의 주소 범위를 그대로 쓴다.
   ROM 이미지와 RAM 실행 주소가 다른 경우(`AT>` 사용)도 검증했다.
   `sh_addr` 가 VMA 이고 섹션 내용이 초기값이므로 그대로 동작한다.

6. **분리된 디버그 정보**. `.gnu_debuglink` 는 자동으로 찾아 읽는다.
   `-gsplit-dwarf` 의 `.dwo` 는 지원하지 않으며, 그 경우 안내 메시지를 표시한다.

## 검증

검증은 대상 바이너리를 **실제로 실행해** 얻은 출력과 파서 결과를
리프 단위로 대조하는 방식이다. 빅엔디안 정답지는 qemu-ppc 로 얻는다.

- 경계 케이스 18개 빌드 구성 (DWARF 2/3/4/5 × LE/BE × -O0~-O3/-Os)
- 타입 조합 생성 (`gen_types.py`): typedef 140여 개 / 전역 160여 개
- 컴파일러 gcc·clang, 아키텍처 x86-64 / PowerPC(BE32) / ARM(LE32) / s390x(BE64)
- 디버그 형식 `-gz` 압축 / 타입유닛 / LTO / DWARF64 / `.gnu_debuglink` / PIE
- **베어메탈 ROM 이미지 (LMA ≠ VMA)** — MPC5674F 배치 그대로 검증

**누적 40만 건 이상 비교, 실패 0건.**

```bash
apt-get install clang qemu-user gcc-powerpc-linux-gnu \
                gcc-arm-linux-gnueabihf gcc-s390x-linux-gnu
cd tests
./run_all_tests.sh       # 경계 케이스 + 덤프 + 암호화 저장소
./run_combo_tests.sh     # 타입 조합 대량 검증
./run_matrix_tests.sh    # 컴파일러 / 아키텍처 / 디버그 형식
```

자세한 내용과 이 과정에서 찾은 결함 10건은 `tests/TEST_REPORT.md` 참고.

## 한계

- 덤프 없이 ELF 만 열면 값은 **정적 초기값**이다. 런타임 값을 보려면 TRACE32 API(`t32api.dll` /
  `libt32api.so`)의 `T32_ReadMemory()` 로 `MemoryImage.read()` 를 갈아끼우면
  동일한 트리에 실시간 값을 채울 수 있다.
- `#define` 상수, 물리 단위, 스케일 팩터는 DWARF 에 없다.
- 지역변수 · static 함수 지역변수는 대상 외 (location 이 `DW_OP_fbreg`).
