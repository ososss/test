"""
test_dump.py - 덤프 파서 왕복 검증

알려진 ELF 의 섹션 내용에서 덤프 파일을 만들고, 다시 읽어
ELF 초기값과 리프 단위로 대조한다. 서식을 흔들어 파서의 견고성도 본다.

  python3 test_dump.py <elf>
"""

import os
import random
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))

from dwarf_reader import DwarfReader          # noqa: E402
from memdump import MemoryDump                # noqa: E402

rnd = random.Random(4242)


# ---------------------------------------------------------------- 덤프 생성
def collect_words(rd, limit_bytes=4096):
    """ELF 에서 4바이트 단위로 (주소, 값) 목록을 만든다."""
    words = []
    seen = set()
    for g in rd.globals:
        if g.address is None or not g.byte_size:
            continue
        base = g.address & ~3
        end = (g.address + g.byte_size + 3) & ~3
        for a in range(base, end, 4):
            if a in seen:
                continue
            raw = rd.mem.read(a, 4)
            if raw is None:
                continue
            seen.add(a)
            words.append((a, int.from_bytes(raw, 'big' if rd.big_endian else 'little')))
        if len(words) * 4 > limit_bytes:
            break
    words.sort()
    return words


def write_style1(path, words, corrupt_ch3=()):
    """예시1: 공백 구분, 0x 접두, 헤더 앞 잡다한 줄."""
    with open(path, 'w') as f:
        f.write('Memory Dump Utility v2.1\n')
        f.write('Target: MPC5674F\n')
        f.write('\n')
        f.write(' Address    Channel A     Channel B     Channel C \n')
        for a, v in words:
            v3 = v ^ 0xFF if a in corrupt_ch3 else v
            pad = ' ' * rnd.randint(1, 5)
            f.write(f'0x{a:08x}{pad}0x{v:08x}{pad}  0x{v:08x} {pad}0x{v3:08x}\n')


def write_style2(path, words, corrupt_ch3=()):
    """예시2: ="..." 포장, 채널당 16비트 상/하위 2칸, 빈 칼럼."""
    with open(path, 'w', newline='\r\n') as f:
        f.write('Dump Report\n')
        f.write('Session,17,,,\n')
        f.write(',,,,\n')
        f.write('Address, Ch_A, ,Ch_B, ,Ch_C\n')
        for a, v in words:
            v3 = v ^ 0xFF if a in corrupt_ch3 else v
            def halves(x):
                return f'{(x >> 16) & 0xFFFF:04x}', f'{x & 0xFFFF:04x}'
            cells = []
            for val in (v, v, v3):
                hi, lo = halves(val)
                q = '=' if rnd.random() < 0.8 else ''      # ="..." / "..." 혼재
                cells += [f'{q}"{hi}"', f'{q}"{lo}"']
            sp = ' ' if rnd.random() < 0.5 else ''
            f.write(f'="{a:08x}" ,' + ','.join(c + sp for c in cells) + ' ,\n')


def write_style3(path, words):
    """서식 흔들기: 탭 구분, 0x 유무 혼재, BOM, 빈 줄, 주석."""
    with open(path, 'w', encoding='utf-8-sig') as f:
        f.write('# generated\n\n')
        f.write('ADDRESS\tCH-A\tCH-B\tCH-C\n')
        for a, v in words:
            px = '0x' if rnd.random() < 0.5 else ''
            f.write(f'{px}{a:08X}\t{px}{v:08X}\t{v:08x}\t0X{v:08X}\n')
            if rnd.random() < 0.05:
                f.write('\n')


# ---------------------------------------------------------------- 검증
def leaf_values(rd, mem, max_nodes=20000, want_addrs=False):
    """주어진 메모리 소스로 전역 트리를 걸어 path -> 값 문자열.
    want_addrs 면 (값사전, 리프주소집합) 을 돌려준다."""
    saved = rd.mem
    rd.mem = mem
    try:
        out = {}
        addrs = set()
        stack = [(g, 0, g.name) for g in rd.globals]
        n = 0
        while stack and n < max_nodes:
            node, depth, path = stack.pop()
            n += 1
            t = node.type
            if t is not None and t.kind in ('base', 'enum') or node.bit_size is not None:
                out[path] = node.value_text()
                if node.address is not None:
                    addrs.add(node.address & ~3)
            if depth < 8 and node.has_children():
                kids = node.children()
                if t and t.kind == 'array':
                    kids = kids[:8]
                if t and t.kind == 'pointer':
                    continue
                for k in kids:
                    nm = k.name
                    p = path + (nm if nm.startswith('[') else '.' + nm)
                    stack.append((k, depth + 1, p))
        return (out, addrs) if want_addrs else out
    finally:
        rd.mem = saved


def main():
    elf = sys.argv[1]
    rd = DwarfReader(elf)
    words = collect_words(rd)
    print(f'[ELF ] {elf}  전역 {len(rd.globals)}개  덤프 대상 {len(words)}워드')

    expect, leaf_addrs = leaf_values(rd, rd.mem, want_addrs=True)

    # 채널 C 에만 일부러 값을 틀어 불일치 탐지를 확인한다.
    # 트리에서 실제로 읽히는 리프 주소에서만 고른다.
    pool = sorted(leaf_addrs & {a for a, _ in words})
    corrupt = set(rnd.sample(pool, min(5, len(pool))))

    fails = 0
    cases = [('예시1 (공백/0x)', write_style1, True),
             ('예시2 (="" /16비트 2칸)', write_style2, True),
             ('서식 흔들기 (탭/BOM/혼재)', write_style3, False)]

    for name, writer, use_corrupt in cases:
        path = f'/tmp/dumptest_{abs(hash(name))}.csv'
        if use_corrupt:
            writer(path, words, corrupt)
        else:
            writer(path, words)
        dump = MemoryDump(path, big_endian=rd.big_endian)

        ok = bad = skip = 0
        got_a = leaf_values(rd, dump.channels[0])
        for k, v in expect.items():
            g = got_a.get(k)
            if g is None or g == '<no data>':
                skip += 1
            elif g == v:
                ok += 1
            else:
                bad += 1
                if bad <= 3:
                    print(f'    MISMATCH {k}: ELF={v} DUMP={g}')
        status = 'OK  ' if bad == 0 else 'FAIL'
        print(f'  {status} {name:<26} {dump.summary()}')
        print(f'       채널={",".join(dump.channel_names)} 쌍결합={"예" if dump.paired else "아니오"}'
              f'  일치 {ok} / 불일치 {bad} / 범위밖 {skip}')
        for n in dump.notes:
            print(f'       [!] {n}')
        fails += bad

        # 불일치 탐지 확인 (스타일3 은 세 채널이 동일하므로 제외)
        if use_corrupt:
            mems = list(dump.channels)
            found = set()
            for g in rd.globals:
                stack = [g]
                while stack:
                    nd = stack.pop()
                    is_leaf = (nd.bit_size is not None or
                               (nd.type and nd.type.kind in ('base', 'enum')))
                    if is_leaf and nd.address is not None and \
                            rd.mismatch_across(nd, mems):
                        found.add(nd.address & ~3)
                    if nd.has_children() and (nd.type and nd.type.kind != 'pointer'):
                        stack.extend(nd.children()[:8])
            hit = len(found & corrupt)
            false_pos = len(found - corrupt)
            print(f'       불일치 탐지: 주입 {len(corrupt)}워드 중 {hit}워드 검출'
                  f'  (리프 기준 오탐 {false_pos})')
            if hit != len(corrupt):
                fails += 1
        else:
            mems = list(dump.channels)
            any_mm = any(rd.mismatch_across(g, mems) for g in rd.globals)
            print(f'       채널 동일 케이스 오탐 없음: {"예" if not any_mm else "아니오"}')
            if any_mm:
                fails += 1
        os.unlink(path)

    print('  ALL PASS' if fails == 0 else f'  실패 {fails}건')
    return 1 if fails else 0


if __name__ == '__main__':
    sys.exit(main())
