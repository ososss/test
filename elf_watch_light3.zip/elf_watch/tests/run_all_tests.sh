#!/bin/bash
# run_all_tests.sh - 전체 검증 매트릭스 실행
#
# 필요: gcc, powerpc-linux-gnu-gcc, qemu-ppc, python3 + pyelftools
#   apt-get install gcc-powerpc-linux-gnu qemu-user
#
# 원리: edge_cases.c 를 -DORACLE 로 빌드해 '실제로 실행'한 출력을 정답지로 삼고,
#       같은 바이너리를 파서로 읽은 값과 대조한다.
#       빅엔디안 바이너리는 qemu-ppc 로 실행한다.

set -u
cd "$(dirname "$0")"
PASS=0; FAIL=0

hdr() { echo; echo "=============== $1 ==============="; }

build() {  # $1=cc $2=dwarf $3=opt $4=extra $5=out
    $1 -DORACLE -g$2 -g3 -O$3 $4 -o "$5" edge_cases.c aux_cu.c 2>/dev/null
}

check() {  # $1=binary $2=runner
    if [ "$2" = "qemu" ]; then qemu-ppc "./$1" > /tmp/oracle_$$.txt 2>/dev/null
    else "./$1" > /tmp/oracle_$$.txt 2>/dev/null; fi
    OUT=$(python3 test_parser.py "$1" /tmp/oracle_$$.txt 2>&1)
    RES=$(echo "$OUT" | grep -E '^\[TEST\]')
    printf '  %-22s %s\n' "$1" "$RES"
    echo "$OUT" | grep -E '^  (MISMATCH|MISSING)' | sed 's/^/      /'
    if echo "$RES" | grep -q 'fail=0'; then PASS=$((PASS+1)); else FAIL=$((FAIL+1)); fi
    rm -f /tmp/oracle_$$.txt
}

hdr "1. DWARF 버전별 (little endian / x86-64)"
for D in dwarf-2 dwarf-3 dwarf-4 dwarf-5; do
    build gcc $D 0 "-no-pie" "x86_${D}_O0" && check "x86_${D}_O0" native
done

hdr "2. DWARF 버전별 (big endian / PowerPC)"
for D in dwarf-2 dwarf-3 dwarf-4 dwarf-5; do
    build powerpc-linux-gnu-gcc $D 0 "-static" "ppc_${D}_O0" && check "ppc_${D}_O0" qemu
done

hdr "3. 최적화 레벨별"
for O in 0 1 2 3 s; do
    build gcc dwarf-4 $O "-no-pie" "x86_O${O}"          && check "x86_O${O}" native
    build powerpc-linux-gnu-gcc dwarf-4 $O "-static" "ppc_O${O}" && check "ppc_O${O}" qemu
done

hdr "4. 비정상 입력 처리"
cp x86_dwarf-4_O0 stripped_elf 2>/dev/null && strip --strip-debug stripped_elf
gcc -c -gdwarf-4 -O0 -o relocatable.o edge_cases.c 2>/dev/null
head -c 3000 x86_dwarf-4_O0 > truncated.elf 2>/dev/null
echo "not an elf" > notanelf.bin
printf "\\x7fELF\\x02\\x01\\x01\\x00" > fakehdr.elf
python3 test_robust.py

hdr "5. MPC5674F 유사 베어메탈 이미지"
for V in 2 4 5; do
    powerpc-linux-gnu-gcc -mbig-endian -m32 -O0 -gdwarf-$V -g3 -ffreestanding \
        -nostdlib -nostartfiles -T ../sample/mpc5674f_like.ld \
        -o ../sample/fcs_sample_dwarf$V.elf ../sample/fcs_sample.c 2>/dev/null
    printf '  fcs_sample_dwarf%-12s ' "$V.elf"
    python3 -c "
import sys; sys.path.insert(0,'..')
from dwarf_reader import DwarfReader
rd = DwarfReader('../sample/fcs_sample_dwarf$V.elf')
b = [g for g in rd.globals if g.name=='g_bus1_status'][0]
vals = [c.value_text() for c in b.children()]
exp  = ['1','0','5','17','32','0','0']
print('비트필드', 'OK' if vals==exp else 'FAIL %s' % vals, '| globals=%d' % len(rd.globals))
"
done

hdr "6. 메모리 덤프 파서 (왕복 검증)"
for V in 4 5; do
    python3 test_dump.py ../sample/fcs_sample_dwarf$V.elf 2>&1 \
        | grep -E '^\s+(OK|FAIL)|ALL PASS|실패|불일치 탐지|오탐 없음' | sed 's/^/  /'
    python3 test_dump.py ../sample/fcs_sample_dwarf$V.elf > /dev/null 2>&1 \
        && PASS=$((PASS+1)) || FAIL=$((FAIL+1))
done

hdr "결과"
echo "  통과한 구성: $PASS / $((PASS+FAIL))"
[ "$FAIL" -eq 0 ] && echo "  ALL PASS" || echo "  실패 $FAIL 건"
exit $FAIL
