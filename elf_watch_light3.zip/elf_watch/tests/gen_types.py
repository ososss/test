#!/usr/bin/env python3
"""
gen_types.py - DWARF 파서 검증용 C 타입 조합 생성기

구조체 / 공용체 / 배열 / 비트필드 / 포인터 / enum / 한정자를
조합해 헤더와 전역변수를 만들고, 모든 스칼라 리프에 대해
printf 정답지 출력 코드까지 함께 생성한다.

  python3 gen_types.py            -> gen_types.h, gen_types.c 생성

생성물은 -DORACLE 로 빌드해 실행하면 "경로=값" 을 출력한다.
"""

import sys
import random

SEED = int(sys.argv[2]) if len(sys.argv) > 2 else 20260909
rnd = random.Random(SEED)

# ---------------------------------------------------------------- 기본 타입
# (C 타입명, printf 매크로, 값 생성기, 비트필드 사용 가능 여부)
def _u(bits):
    return lambda: rnd.randrange(0, 1 << bits)

def _s(bits):
    return lambda: rnd.randrange(-(1 << (bits - 1)), 1 << (bits - 1))

BASES = [
    ('char',               'P_I', lambda: rnd.randrange(0, 128),  True),
    ('signed char',        'P_I', _s(8),   True),
    ('unsigned char',      'P_U', _u(8),   True),
    ('short',              'P_I', _s(16),  True),
    ('unsigned short',     'P_U', _u(16),  True),
    ('int',                'P_I', _s(32),  True),
    ('unsigned int',       'P_U', _u(32),  True),
    ('long',               'P_I', _s(31),  True),   # 32/64bit 이식성 위해 31bit
    ('unsigned long',      'P_U', _u(31),  True),
    ('long long',          'P_I', _s(64),  True),
    ('unsigned long long', 'P_U', _u(64),  True),
    ('int8_t',             'P_I', _s(8),   True),
    ('uint8_t',            'P_U', _u(8),   True),
    ('int16_t',            'P_I', _s(16),  True),
    ('uint16_t',           'P_U', _u(16),  True),
    ('int32_t',            'P_I', _s(32),  True),
    ('uint32_t',           'P_U', _u(32),  True),
    ('int64_t',            'P_I', _s(64),  True),
    ('uint64_t',           'P_U', _u(64),  True),
    ('float',              'P_F', lambda: rnd.uniform(-1e6, 1e6), False),
    ('double',             'P_F', lambda: rnd.uniform(-1e12, 1e12), False),
    ('_Bool',              'P_U', lambda: rnd.randrange(0, 2), False),
]

BITFIELD_BASES = [b for b in BASES if b[3]]

BASE_BITS = {
    'char': 8, 'signed char': 8, 'unsigned char': 8,
    'short': 16, 'unsigned short': 16, 'int': 32, 'unsigned int': 32,
    'long': 32, 'unsigned long': 32,          # 32bit 타깃 기준으로 보수적으로
    'long long': 64, 'unsigned long long': 64,
    'int8_t': 8, 'uint8_t': 8, 'int16_t': 16, 'uint16_t': 16,
    'int32_t': 32, 'uint32_t': 32, 'int64_t': 64, 'uint64_t': 64,
}
SIGNED_BASES = {'char', 'signed char', 'short', 'int', 'long', 'long long',
                'int8_t', 'int16_t', 'int32_t', 'int64_t'}


def fmt_float(v):
    return repr(float(v))


# ---------------------------------------------------------------- 타입 노드
class Node:
    """멤버/변수 하나. decl() 은 선언문, leaves() 는 (경로, 매크로) 열거."""
    def decl(self, name):
        raise NotImplementedError

    def init(self):
        raise NotImplementedError

    def leaves(self, path):
        return
        yield


class Scalar(Node):
    def __init__(self, ctype, macro, gen):
        self.ctype, self.macro, self.gen = ctype, macro, gen
        self.value = gen()

    def decl(self, name):
        return f'{self.ctype} {name}'

    def init(self):
        if self.macro == 'P_F':
            return fmt_float(self.value) + ('f' if self.ctype == 'float' else '')
        if self.ctype in ('long long', 'unsigned long long',
                          'int64_t', 'uint64_t'):
            return f'{self.value}LL' if self.value >= 0 else f'({self.value}LL)'
        return str(self.value) if self.value >= 0 else f'({self.value})'

    def leaves(self, path):
        yield path, self.macro


class BitField(Node):
    def __init__(self, ctype, macro, width, named=True):
        self.ctype, self.macro, self.width, self.named = ctype, macro, width, named
        if width == 0:
            self.value = 0
        elif ctype in SIGNED_BASES:
            self.value = rnd.randrange(-(1 << (width - 1)), 1 << (width - 1))
        else:
            self.value = rnd.randrange(0, 1 << width)

    def decl(self, name):
        if not self.named:
            return f'{self.ctype} : {self.width}'
        return f'{self.ctype} {name} : {self.width}'

    def init(self):
        return str(self.value) if self.value >= 0 else f'({self.value})'

    def leaves(self, path):
        if self.named and self.width > 0:
            yield path, self.macro


class Enum(Node):
    def __init__(self, tname, values):
        self.tname, self.values = tname, values
        self.value = rnd.choice(values)[1]

    def decl(self, name):
        return f'{self.tname} {name}'

    def init(self):
        for n, v in self.values:
            if v == self.value:
                return n
        return str(self.value)

    def leaves(self, path):
        yield path, 'P_I'


class Ptr(Node):
    """포인터. 값 비교는 하지 않지만 타입 표시/전개 경로를 검증한다."""
    def __init__(self, target_decl):
        self.target_decl = target_decl

    def decl(self, name):
        return self.target_decl.replace('@', name)

    def init(self):
        return '0'


class Arr(Node):
    def __init__(self, elem_factory, dims):
        self.dims = dims
        n = 1
        for d in dims:
            n *= d
        self.elems = [elem_factory() for _ in range(n)]

    def decl(self, name):
        suffix = ''.join(f'[{d}]' for d in self.dims)
        return self.elems[0].decl(name) + suffix

    def _nested_init(self, dims, idx):
        if len(dims) == 1:
            items = [self.elems[idx + i].init() for i in range(dims[0])]
            return '{ ' + ', '.join(items) + ' }'
        stride = 1
        for d in dims[1:]:
            stride *= d
        return '{ ' + ', '.join(
            self._nested_init(dims[1:], idx + i * stride)
            for i in range(dims[0])) + ' }'

    def init(self):
        return self._nested_init(self.dims, 0)

    def leaves(self, path):
        def walk(dims, prefix, idx):
            if len(dims) == 1:
                for i in range(dims[0]):
                    yield from self.elems[idx + i].leaves(f'{prefix}[{i}]')
                return
            stride = 1
            for d in dims[1:]:
                stride *= d
            for i in range(dims[0]):
                yield from walk(dims[1:], f'{prefix}[{i}]', idx + i * stride)
        yield from walk(self.dims, path, 0)


class Named(Node):
    """이미 정의된 struct/union typedef 의 인스턴스."""
    def __init__(self, agg):
        self.agg = agg
        self.inst = agg.make_instance()

    def decl(self, name):
        return f'{self.agg.tname} {name}'

    def init(self):
        return self.inst.init()

    def leaves(self, path):
        yield from self.inst.leaves(path)


class AggInstance(Node):
    def __init__(self, agg, members):
        self.agg, self.members = agg, members

    def decl(self, name):
        return f'{self.agg.tname} {name}'

    def init(self):
        if self.agg.is_union:
            for mname, node in self.members:
                if isinstance(node, Ptr) or mname is None:
                    continue
                return '{ .' + mname + ' = ' + node.init() + ' }'
            return '{ 0 }'
        parts = []
        for mname, node in self.members:
            if isinstance(node, BitField) and not node.named:
                continue                       # 무명 비트필드는 초기화 불가
            parts.append(node.init())
        return '{ ' + ', '.join(parts) + ' }' if parts else '{ 0 }'

    def leaves(self, path):
        for mname, node in self.members:
            if mname is None:                  # 익명 struct/union: 경로 생략
                yield from node.leaves(path)
            else:
                yield from node.leaves(f'{path}.{mname}')


UNION_SAFE_BASES = [b for b in BASES if b[0] != '_Bool']


class Agg:
    """struct 또는 union 타입 정의."""
    def __init__(self, tname, is_union, packing=None, aligned=None):
        self.tname = tname
        self.is_union = is_union
        self.packing = packing      # None | 'packed' | pragma pack 값
        self.aligned = aligned
        self.member_specs = []      # (name, factory)  factory() -> Node

    def add(self, name, factory):
        self.member_specs.append((name, factory))

    def make_instance(self):
        return AggInstance(self, [(n, f()) for n, f in self.member_specs])

    def definition(self, proto_instance):
        kw = 'union' if self.is_union else 'struct'
        lines = []
        if isinstance(self.packing, int):
            lines.append(f'#pragma pack({self.packing})')
        attrs = []
        if self.packing == 'packed':
            attrs.append('__attribute__((packed))')
        if self.aligned:
            attrs.append(f'__attribute__((aligned({self.aligned})))')
        attr = (' ' + ' '.join(attrs)) if attrs else ''
        lines.append(f'typedef {kw}{attr} {{')
        for (mname, _), (_, node) in zip(self.member_specs,
                                         proto_instance.members):
            if isinstance(node, AnonAgg):      # 익명 struct/union
                lines.append('    ' + node.agg_anon_decl())
            elif mname is None:                # 무명 비트필드 / 패딩
                lines.append('    ' + node.decl('') + ';')
            else:
                lines.append('    ' + node.decl(mname) + ';')
        lines.append(f'}} {self.tname};')
        if isinstance(self.packing, int):
            lines.append('#pragma pack()')
        return '\n'.join(lines)


class AnonAgg(Node):
    """익명 struct / union 멤버."""
    def __init__(self, is_union, members):
        self.is_union, self.members = is_union, members

    def agg_anon_decl(self):
        kw = 'union' if self.is_union else 'struct'
        inner = ' '.join(
            (n.decl(mn) + ';') if mn else
            (n.agg_anon_decl() if isinstance(n, AnonAgg) else n.decl('') + ';')
            for mn, n in self.members)
        return f'{kw} {{ {inner} }};'

    def decl(self, name):
        return self.agg_anon_decl()

    def init(self):
        if self.is_union:
            for mn, n in self.members:
                if isinstance(n, Ptr) or mn is None:
                    continue
                return '{ .' + mn + ' = ' + n.init() + ' }'
            return '{ 0 }'
        return '{ ' + ', '.join(
            n.init() for mn, n in self.members
            if not (isinstance(n, BitField) and not n.named)) + ' }'

    def leaves(self, path):
        for mn, n in self.members:
            if mn is None:
                yield from n.leaves(path)
            else:
                yield from n.leaves(f'{path}.{mn}')


# ---------------------------------------------------------------- 생성 로직
enum_defs = []
aggs = []          # (Agg, proto_instance)
agg_pool = []      # 중첩에 재사용할 Agg 목록


def make_enum(idx):
    style = idx % 4
    if style == 0:
        vals = [(f'E{idx}_A', 0), (f'E{idx}_B', 1), (f'E{idx}_C', 2)]
    elif style == 1:
        vals = [(f'E{idx}_NEG', -128), (f'E{idx}_ZERO', 0), (f'E{idx}_POS', 127)]
    elif style == 2:
        vals = [(f'E{idx}_LO', 0), (f'E{idx}_HI', 0x7FFFFFFF)]
    else:
        vals = [(f'E{idx}_X', 100), (f'E{idx}_Y', 200), (f'E{idx}_Z', 300)]
    tname = f'Enum{idx}_t'
    enum_defs.append('typedef enum { ' +
                     ', '.join(f'{n} = {v}' for n, v in vals) +
                     f' }} {tname};')
    return tname, vals


ENUMS = [make_enum(i) for i in range(8)]


def scalar_factory(pool=None):
    ctype, macro, gen, _ = rnd.choice(pool or BASES)
    return lambda: Scalar(ctype, macro, gen)


def bitfield_run_specs(count, allow_zero_width=True, allow_unnamed=True):
    """하나의 기반 타입으로 이어지는 비트필드 묶음 스펙을 만든다."""
    ctype, macro, _, _ = rnd.choice(BITFIELD_BASES)
    bits = BASE_BITS[ctype]
    specs = []
    used = 0
    for i in range(count):
        remaining = max(1, bits - 1)
        w = rnd.randint(1, min(remaining, bits - 1) or 1)
        kind = rnd.random()
        if allow_zero_width and kind < 0.08 and i > 0:
            specs.append((None, ctype, macro, 0, False))       # : 0
        elif allow_unnamed and kind < 0.20:
            specs.append((None, ctype, macro, w, False))       # 무명 패딩
        else:
            specs.append((f'bf{i}', ctype, macro, w, True))
        used += w
    return specs


LEAF_BUDGET = 400          # 타입 하나가 만들 수 있는 리프 상한
_leaf_est = {}             # Agg -> 추정 리프 수


def est_leaves(agg, proto):
    n = 0
    for _, node in proto.members:
        n += sum(1 for _ in node.leaves('x'))
    _leaf_est[agg.tname] = max(n, 1)
    return _leaf_est[agg.tname]


def small_aggs(limit):
    return [a for a in agg_pool if _leaf_est.get(a.tname, 1) <= limit]


def build_agg(idx, depth):
    """구조체/공용체 하나를 조합해 만든다."""
    is_union = (idx % 7 == 6)
    packing = None
    aligned = None
    r = idx % 9
    if r == 1:
        packing = 'packed'
    elif r == 2:
        packing = 1
    elif r == 3:
        packing = 2
    elif r == 4:
        packing = 4
    elif r == 5:
        aligned = rnd.choice([8, 16])

    tname = f'{"U" if is_union else "S"}{idx}_t'
    agg = Agg(tname, is_union, packing, aligned)

    nmem = rnd.randint(2, 5)
    for m in range(nmem):
        pick = rnd.random()

        if pick < 0.30:                                   # 스칼라
            agg.add(f'm{m}', scalar_factory(
                UNION_SAFE_BASES if is_union else None))

        elif pick < 0.50 and not is_union:                # 비트필드 묶음
            specs = bitfield_run_specs(rnd.randint(2, 6),
                                       allow_unnamed=(packing != 1))
            for k, (nm, ct, mc, w, named) in enumerate(specs):
                nm2 = f'm{m}_{nm}' if nm else None
                agg.add(nm2 if named else None,
                        (lambda ct=ct, mc=mc, w=w, named=named:
                         (lambda: BitField(ct, mc, w, named))())
                        if False else
                        (lambda ct=ct, mc=mc, w=w, named=named:
                         BitField(ct, mc, w, named)))

        elif pick < 0.68:                                 # 배열
            ndim = rnd.choice([1, 1, 2, 2, 3, 4])
            dims = [rnd.choice([1, 2, 3, 4]) for _ in range(ndim)]
            nelem = 1
            for d in dims:
                nelem *= d
            pool = small_aggs(max(1, LEAF_BUDGET // max(nelem, 1)))
            if pool and rnd.random() < 0.35 and depth < 3:
                inner = rnd.choice(pool)
                agg.add(f'm{m}',
                        lambda inner=inner, dims=dims:
                        Arr(lambda: Named(inner), dims))
            else:
                sf = scalar_factory(UNION_SAFE_BASES if is_union else None)
                agg.add(f'm{m}', lambda sf=sf, dims=dims: Arr(sf, dims))

        elif pick < 0.80 and small_aggs(LEAF_BUDGET) and depth < 3:
            inner = rnd.choice(small_aggs(LEAF_BUDGET))     # 중첩 struct/union
            agg.add(f'm{m}', lambda inner=inner: Named(inner))

        elif pick < 0.88 and not is_union:                # 익명 struct/union
            anon_union = rnd.random() < 0.5
            sub = []
            pool_b = UNION_SAFE_BASES if anon_union else BASES
            for k in range(rnd.randint(2, 3)):
                ctype, macro, gen, _ = rnd.choice(pool_b)
                sub.append((f'a{m}_{k}', (ctype, macro, gen)))
            agg.add(None, lambda sub=sub, au=anon_union: AnonAgg(
                au, [(n, Scalar(c, mc, g)) for n, (c, mc, g) in sub]))

        elif pick < 0.94:                                 # enum
            tn, vals = rnd.choice(ENUMS)
            agg.add(f'm{m}', lambda tn=tn, vals=vals: Enum(tn, vals))

        else:                                             # 포인터
            kind = rnd.random()
            if kind < 0.3:
                d = 'void *@'
            elif kind < 0.5:
                d = 'const char *@'
            elif kind < 0.7:
                d = 'int (*@)[4]'
            elif kind < 0.85:
                d = 'void (*@)(void)'
            else:
                d = 'struct FwdRef *@'
            agg.add(f'm{m}', lambda d=d: Ptr(d))

    return agg


# ---------------------------------------------------------------- 손으로 쓴 케이스
HANDWRITTEN = r'''
/* ---------- 손으로 지정한 까다로운 케이스 ---------- */

/* 저장 단위를 정확히 채우는 / 넘치는 비트필드 */
typedef struct { uint32_t a:32; }                                 HB_Full32_t;
typedef struct { uint32_t a:31; uint32_t b:1; }                   HB_Split31_t;
typedef struct { uint32_t a:17; uint32_t b:17; uint32_t c:17; }   HB_Straddle_t;
typedef struct { uint64_t a:40; uint64_t b:24; }                  HB_Wide64_t;
typedef struct { uint64_t a:33; uint64_t b:33; }                  HB_Cross64_t;
typedef struct { uint8_t a:1; uint8_t b:1; uint8_t c:1; uint8_t d:1;
                 uint8_t e:1; uint8_t f:1; uint8_t g:1; uint8_t h:1; } HB_Eight1_t;
typedef struct { int32_t  a:2; int32_t  b:3; int32_t  c:11; }     HB_Signed_t;
typedef struct { uint16_t a:4; uint16_t :0; uint16_t b:4; }       HB_ZeroW_t;
typedef struct __attribute__((packed))
       { uint8_t h; uint32_t f:24; uint8_t t; }                   HB_Packed24_t;
typedef struct __attribute__((packed))
       { uint8_t h; uint64_t f:57; uint8_t t; }                   HB_Packed57_t;
typedef struct { uint8_t pad; uint32_t a:5; uint32_t b:5;
                 uint8_t pad2; uint32_t c:5; }                    HB_Interleave_t;

/* 배열 조합 */
typedef struct { HB_Eight1_t bits[2][3]; }                        HA_BitArr_t;
typedef struct { char s[4][8]; }                                  HA_StrArr_t;
typedef struct { uint16_t deep[2][2][2][2]; }                     HA_Deep4_t;
typedef struct { uint8_t one[1]; uint8_t many[17]; }              HA_Odd_t;

/* 공용체 오버레이 */
typedef union { uint64_t u; double d; uint8_t b[8];
                struct { uint32_t lo, hi; } h;
                struct { uint16_t w0, w1, w2, w3; } w; }          HU_Overlay_t;
typedef union { HB_Eight1_t bits; uint8_t raw; }                  HU_BitOverlay_t;

/* 한정자 조합 */
typedef const volatile uint32_t                                   HQ_CV_t;
typedef struct { const uint32_t c; volatile uint32_t v;
                 const volatile uint32_t cv; }                    HQ_Mixed_t;

/* 깊은 중첩 (6단) */
typedef struct { uint8_t  v; }                                    HN_L6_t;
typedef struct { HN_L6_t l; uint16_t v; }                         HN_L5_t;
typedef struct { HN_L5_t l; uint32_t v; }                         HN_L4_t;
typedef struct { HN_L4_t l; int8_t   v; }                         HN_L3_t;
typedef struct { HN_L3_t l; int16_t  v; }                         HN_L2_t;
typedef struct { HN_L2_t l; int32_t  v; }                         HN_L1_t;

/* 자기참조 / 상호참조 */
typedef struct SelfRef  { int32_t v; struct SelfRef *next;
                          struct SelfRef **pp; }                  HR_Self_t;
struct MutB;
typedef struct MutA { int16_t a; struct MutB *b; }                HR_MutA_t;
typedef struct MutB { int16_t b; struct MutA *a; }                HR_MutB_t;
typedef struct { HR_Self_t nodes[3]; HR_Self_t *head; }           HR_Pool_t;

/* typedef 체인 */
typedef uint32_t  TD1_t;
typedef TD1_t     TD2_t;
typedef TD2_t     TD3_t;
typedef TD3_t     TD4_t;
typedef struct { TD4_t chained; }                                 HT_Chain_t;
'''

HANDWRITTEN_GLOBALS = [
    ('HB_Full32_t',   'hb_full32',   '{ 0xDEADBEEFu }',            ['a']),
    ('HB_Split31_t',  'hb_split31',  '{ 0x7EDCBA98u, 1 }',         ['a', 'b']),
    ('HB_Straddle_t', 'hb_straddle', '{ 0x1FFFF, 0x0AAAA, 0x15555 }', ['a','b','c']),
    ('HB_Wide64_t',   'hb_wide64',   '{ 0xFEDCBA9876ULL, 0xABCDEFu }', ['a','b']),
    ('HB_Cross64_t',  'hb_cross64',  '{ 0x1FEDCBA98ULL, 0x123456789ULL }', ['a','b']),
    ('HB_Eight1_t',   'hb_eight1',   '{ 1,0,1,1,0,0,1,0 }',
     ['a','b','c','d','e','f','g','h']),
    ('HB_Signed_t',   'hb_signed',   '{ -2, -4, -1000 }',          ['a','b','c']),
    ('HB_ZeroW_t',    'hb_zerow',    '{ 9, 6 }',                   ['a','b']),
    ('HB_Packed24_t', 'hb_packed24', '{ 0xA5, 0xC0FFEEu, 0x5A }',  ['h','f','t']),
    ('HB_Packed57_t', 'hb_packed57', '{ 0x11, 0x1FEDCBA987654321ULL, 0x22 }',
     ['h','f','t']),
    ('HB_Interleave_t','hb_inter',   '{ 0x77, 21, 10, 0x88, 31 }',
     ['pad','a','b','pad2','c']),
    ('HQ_Mixed_t',    'hq_mixed',    '{ 111, 222, 333 }',          ['c','v','cv']),
    ('HT_Chain_t',    'ht_chain',    '{ 0x12345678u }',            ['chained']),
]


def main():
    global agg_pool
    n_types = int(sys.argv[1]) if len(sys.argv) > 1 else 110

    protos = []
    for i in range(n_types):
        agg = build_agg(i, depth=0)
        proto = agg.make_instance()
        aggs.append((agg, proto))
        protos.append(proto)
        est_leaves(agg, proto)
        if len(agg_pool) < 40:
            agg_pool.append(agg)

    # ---- 헤더
    h = ['/* 자동 생성됨 - gen_types.py (seed=%d) */' % SEED,
         '#ifndef GEN_TYPES_H', '#define GEN_TYPES_H',
         '#include <stdint.h>', '#include <stdbool.h>', '',
         'struct FwdRef;                 /* 전방 선언 포인터용 */', '']
    h += enum_defs + ['']
    h.append(HANDWRITTEN)
    for agg, proto in aggs:
        h.append(agg.definition(proto))
        h.append('')
    h += ['#endif']
    open('gen_types.h', 'w').write('\n'.join(h))

    # ---- 전역변수 + 오라클
    c = ['/* 자동 생성됨 - gen_types.py */',
         '#include "gen_types.h"',
         '#ifdef ORACLE',
         '#include <stdio.h>',
         '#define P_I(e) printf("%s=%lld\\n",   #e, (long long)(e))',
         '#define P_U(e) printf("%s=%llu\\n",   #e, (unsigned long long)(e))',
         '#define P_F(e) printf("%s=%.9g\\n",   #e, (double)(e))',
         '#endif', '']

    printfs = []
    nvars = 0
    for gtype, gname, ginit, members in HANDWRITTEN_GLOBALS:
        c.append(f'{gtype} {gname} = {ginit};')
        nvars += 1
        for m in members:
            printfs.append(f'    P_I({gname}.{m});')

    c.append('')
    c.append('HA_BitArr_t  ha_bitarr = { { { {1,0,1,0,1,0,1,0}, {0,1,0,1,0,1,0,1},'
             ' {1,1,0,0,1,1,0,0} },'
             ' { {0,0,1,1,0,0,1,1}, {1,0,0,1,1,0,0,1}, {0,1,1,0,0,1,1,0} } } };')
    c.append('HA_StrArr_t  ha_strarr = { { "abc", "de", "fghijk", "" } };')
    c.append('HA_Deep4_t   ha_deep4  = { { { { {1,2},{3,4} }, { {5,6},{7,8} } },'
             ' { { {9,10},{11,12} }, { {13,14},{15,16} } } } };')
    c.append('HA_Odd_t     ha_odd    = { {7}, {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17} };')
    c.append('HU_Overlay_t hu_ovl    = { .u = 0x0123456789ABCDEFULL };')
    c.append('HU_BitOverlay_t hu_bovl = { .raw = 0xB6 };')
    c.append('HN_L1_t      hn_deep   = { { { { { { 0xAB }, 0x1234 }, 0x89ABCDEFu },'
             ' -100 }, -20000 }, -123456 };')
    c.append('HQ_CV_t      hq_cv     = 0xFEEDFACEu;')
    nvars += 8

    for i in range(2):
        for j in range(3):
            for k in range(8):
                printfs.append(f'    P_U(ha_bitarr.bits[{i}][{j}].'
                               f'{"abcdefgh"[k]});')
    for i in range(4):
        for j in range(8):
            printfs.append(f'    P_I(ha_strarr.s[{i}][{j}]);')
    for a in range(2):
        for b in range(2):
            for cc in range(2):
                for d in range(2):
                    printfs.append(f'    P_U(ha_deep4.deep[{a}][{b}][{cc}][{d}]);')
    printfs.append('    P_U(ha_odd.one[0]);')
    for i in range(17):
        printfs.append(f'    P_U(ha_odd.many[{i}]);')
    printfs.append('    P_U(hu_ovl.u);')
    printfs.append('    P_F(hu_ovl.d);')
    for i in range(8):
        printfs.append(f'    P_U(hu_ovl.b[{i}]);')
    printfs.append('    P_U(hu_ovl.h.lo);')
    printfs.append('    P_U(hu_ovl.h.hi);')
    for i in range(4):
        printfs.append(f'    P_U(hu_ovl.w.w{i});')
    for k in 'abcdefgh':
        printfs.append(f'    P_U(hu_bovl.bits.{k});')
    printfs.append('    P_U(hu_bovl.raw);')
    printfs.append('    P_U(hn_deep.l.l.l.l.l.v);')
    printfs.append('    P_U(hn_deep.l.l.l.l.v);')
    printfs.append('    P_U(hn_deep.l.l.l.v);')
    printfs.append('    P_I(hn_deep.l.l.v);')
    printfs.append('    P_I(hn_deep.l.v);')
    printfs.append('    P_I(hn_deep.v);')
    printfs.append('    P_U(hq_cv);')

    c.append('')
    # ---- 생성된 타입의 전역변수
    for i, (agg, proto) in enumerate(aggs):
        gname = f'g_{agg.tname.lower()}'
        c.append(f'{agg.tname} {gname} = {proto.init()};')
        nvars += 1
        for pathexpr, macro in proto.leaves(gname):
            printfs.append(f'    {macro}({pathexpr});')

        # 같은 타입의 배열 변수도 하나씩
        if i % 3 == 0 and _leaf_est.get(agg.tname, 1) <= LEAF_BUDGET:
            arr = Arr(lambda agg=agg: Named(agg), [2])
            aname = f'ga_{agg.tname.lower()}'
            c.append(f'{agg.tname} {aname}[2] = {arr.init()};')
            nvars += 1
            for pathexpr, macro in arr.leaves(aname):
                printfs.append(f'    {macro}({pathexpr});')

    c.append('')
    c.append('#ifdef ORACLE')
    c.append('int main(void) {')
    c += printfs
    c.append('    return 0;')
    c.append('}')
    c.append('#else')
    c.append('void _start(void) { for (;;) { } }')
    c.append('#endif')
    open('gen_types.c', 'w').write('\n'.join(c) + '\n')

    print(f'생성 완료: 타입 {len(aggs) + 30}개, 전역변수 {nvars}개, '
          f'비교 항목 {len(printfs)}개')


if __name__ == '__main__':
    main()
