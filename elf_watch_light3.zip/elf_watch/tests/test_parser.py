"""
test_parser.py - 파서 결과를 '실제 실행한 프로그램의 출력'과 자동 비교

  python test_parser.py <elf> <oracle.txt>

오라클은 edge_cases.c 를 -DORACLE 로 빌드해 실행한 결과다.
파서가 ELF 초기값에서 읽어낸 값과 런타임 값이 일치해야 한다.
"""

import os
import sys
import struct

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from dwarf_reader import DwarfReader, VarNode


def canon(rd: DwarfReader, node: VarNode):
    """오라클 printf 와 맞물리는 정규화 값. 비교 불가면 None."""
    t = node.type
    if t is None:
        return None

    # --- 비트필드
    if node.bit_size is not None:
        v = rd._read_bitfield(node)
        if v is None:
            return None
        enc = t.encoding or ''
        if enc.startswith('signed') and (v >> (node.bit_size - 1)) & 1:
            v -= (1 << node.bit_size)          # 부호 확장
        return str(v)

    if node.address is None or not t.byte_size:
        return None

    raw = rd.mem.read(node.address, t.byte_size)
    if raw is None:
        return None
    endian = 'big' if rd.big_endian else 'little'

    if t.kind == 'base':
        enc = t.encoding
        if enc == 'float':
            fmt = ('>' if rd.big_endian else '<') + ('f' if t.byte_size == 4 else 'd')
            if t.byte_size not in (4, 8):
                return None
            return '%.9g' % struct.unpack(fmt, raw)[0]
        if enc == 'boolean':
            return str(int.from_bytes(raw, endian))
        signed = enc in ('signed', 'signed_char')
        return str(int.from_bytes(raw, endian, signed=signed))

    if t.kind == 'enum':
        signed = any(v < 0 for v in t.enum_map) if t.enum_map else False
        return str(int.from_bytes(raw, endian, signed=signed))

    return None                                 # 집합체/포인터는 비교 대상 아님


def path_of(node: VarNode) -> str:
    """C 표현식과 동일한 경로. 익명 멤버는 C 문법대로 건너뛴다."""
    parts = []
    n = node
    while n is not None:
        nm = n.name
        if n.parent is None:
            parts.append(nm)
            break
        if '..' in nm:                          # [0..255] 청크 그룹은 경로에서 생략
            pass
        elif not nm.startswith('<'):            # <anonymous ...> 는 생략
            parts.append(nm if nm.startswith('[') else '.' + nm)
        n = n.parent
    return ''.join(reversed(parts))


def collect(rd: DwarfReader, max_depth=30, max_elems=64):
    """전역 트리를 걸어 path -> canon 값 사전을 만든다."""
    out = {}
    stack = [(g, 0) for g in rd.globals]
    visited = 0
    while stack:
        node, depth = stack.pop()
        visited += 1
        if visited > 3000000:
            break
        v = canon(rd, node)
        if v is not None:
            out[path_of(node)] = v
        if depth < max_depth and node.has_children():
            kids = node.children()
            if node.type and node.type.kind == 'array':
                kids = kids[:max_elems] + kids[-1:]      # 앞부분 + 마지막 원소
                max_depth = max(max_depth, depth + 3)    # 청크 그룹 깊이 보정
            if node.type and node.type.kind == 'pointer':
                continue                                  # 포인터 전개 제외
            for k in kids:
                stack.append((k, depth + 1))
    return out


def main():
    elf, oracle_path = sys.argv[1], sys.argv[2]
    rd = DwarfReader(elf)
    s = rd.summary()
    print(f"[ELF ] {elf}")
    print(f"       {s['class']} {s['machine']} {s['endian']}-endian  "
          f"DWARF v{s['dwarf']}  globals={s['globals']}")

    got = collect(rd)
    print(f"[TREE] 비교 가능한 리프 노드 {len(got)} 개 수집")

    expected = {}
    for line in open(oracle_path):
        line = line.strip()
        if '=' in line:
            k, v = line.split('=', 1)
            expected[k] = v

    ok = fail = missing = 0
    fails = []
    for k, exp in expected.items():
        if k not in got:
            missing += 1
            fails.append(f'  MISSING  {k:<34} expected={exp}')
            continue
        act = got[k]
        # 부동소수 비교는 오차 허용
        if _num_equal(exp, act):
            ok += 1
        else:
            fail += 1
            fails.append(f'  MISMATCH {k:<34} expected={exp:<22} got={act}')

    print(f"[TEST] pass={ok}  fail={fail}  missing={missing}  (총 {len(expected)})")
    for f in fails:
        print(f)
    return 0 if (fail == 0 and missing == 0) else 1


def _num_equal(a: str, b: str) -> bool:
    if a == b:
        return True
    # C 의 printf 는 부호 있는 NaN 을 '-nan' 으로 찍지만 파이썬은 'nan' 으로 찍는다.
    # 공용체 오버레이에서 나오는 표기 차이일 뿐이므로 같게 본다.
    if a.lstrip('-') == 'nan' and b.lstrip('-') == 'nan':
        return True
    try:
        fa, fb = float(a), float(b)
    except ValueError:
        return False
    if fa == fb:
        return True
    scale = max(abs(fa), abs(fb), 1e-300)
    return abs(fa - fb) / scale < 1e-9


if __name__ == '__main__':
    sys.exit(main())
