/*
 * edge_cases.c - DWARF 파서 스트레스 테스트 + 자체 정답지 출력
 *
 *   gcc -DORACLE -O0 -g -no-pie -o oracle edge_cases.c aux_cu.c && ./oracle
 *   -> "path=value" 형식으로 기대값 출력
 *
 * 같은 소스를 PowerPC 빅엔디안으로 빌드해 파서에 물리면
 * 엔디안과 무관하게 동일한 논리값이 나와야 한다.
 */

#include <stdint.h>
#include <stdbool.h>

#ifdef ORACLE
#include <stdio.h>
#endif

typedef uint8_t  u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
typedef int8_t   s8;
typedef int16_t  s16;
typedef int32_t  s32;
typedef int64_t  s64;
typedef float    f32;
typedef double   f64;

/* ---- 1. 익명 struct / union 중첩 ---- */
typedef struct {
    u32 id;
    struct { u16 major; u16 minor; };
    union {
        u32 word;
        struct { u8 b0, b1, b2, b3; };
    };
} AnonNest_t;

/* ---- 2. 저장단위를 넘나드는 비트필드 ---- */
typedef struct {
    u32 a : 20;
    u32 b : 20;
    u32 c : 20;
    u32 d : 4;
} WideBits_t;

/* ---- 3. packed + 비트필드 ---- */
typedef struct __attribute__((packed)) {
    u8  head;
    u32 field : 24;
    u8  tail;
} PackedBits_t;

/* ---- 4. 폭 0 비트필드 / 무명 패딩 ---- */
typedef struct {
    u32 x : 3;
    u32   : 0;
    u32 y : 5;
    u32   : 7;
    u32 z : 4;
} ZeroWidth_t;

/* ---- 5. 부호 있는 비트필드 ---- */
typedef struct {
    s32 trim   : 12;
    s32 offset : 10;
    u32 flag   : 1;
} SignedBits_t;

/* ---- 6. 깊은 중첩 (5단) ---- */
typedef struct { s32 leaf; u8 pad; }        L5_t;
typedef struct { L5_t l5; u16 tag; }        L4_t;
typedef struct { L4_t l4; u8  tag; }        L3_t;
typedef struct { L3_t l3; s16 tag; }        L2_t;
typedef struct { L2_t l2; u32 tag; }        L1_t;

/* ---- 7. 열거형: 음수 / 대형 / 무명 ---- */
typedef enum { NEG_LOW = -128, NEG_MID = -1, NEG_ZERO = 0, NEG_HIGH = 127 } SignedEnum_t;
typedef enum { BIG_A = 0, BIG_C = 0x40000000, BIG_B = 0x7FFFFFFF } BigEnum_t;
enum { ANON_ENUM_VAL = 42 };

/* ---- 8. 함수 포인터 / 포인터 배열 / 배열 포인터 ---- */
typedef void (*Handler_t)(void);
typedef s32  (*Compute_t)(s32, f32);

/* ---- 9. 공용체 안의 구조체 배열 ---- */
typedef struct { u16 lo; u16 hi; } Halves_t;
typedef union {
    u32      raw[2];
    Halves_t pair[2];
    u64      full;
    f64      dbl;
} BigUnion_t;

/* ---- 10. 가변 길이 배열 멤버 ---- */
typedef struct { u16 count; u16 items[]; } FlexArray_t;

/* ---- 11. 구조체 배열 2차원 + 내부 비트필드 ---- */
typedef struct { u8 valid : 1; u8 chan : 3; u8 spare : 4; s16 value; } Cell_t;

/* ---- 12. 빈 구조체 / 1바이트 구조체 ---- */
typedef struct { u8 only; } Tiny_t;

/* ======================= 전역 변수 ======================= */

AnonNest_t   g_anon      = { 0x11223344, { 7, 9 }, { .word = 0xA1B2C3D4u } };
WideBits_t   g_wide      = { 0xFFFFF, 0x12345, 0xABCDE, 0xF };
PackedBits_t g_packed    = { 0xAA, 0x123456, 0x55 };
ZeroWidth_t  g_zerow     = { 5, 21, 11 };
SignedBits_t g_sbits     = { -1000, -300, 1 };
L1_t         g_deep      = { { { { { -42, 0xEE }, 1000 }, 20 }, -300 }, 4000 };

SignedEnum_t g_senum     = NEG_MID;
BigEnum_t    g_benum     = BIG_B;
int          g_anon_enum = ANON_ENUM_VAL;

bool         g_bool_t    = true;
bool         g_bool_f    = false;

s8           g_s8        = -128;
s16          g_s16       = -32768;
s32          g_s32       = -2147483647;
s64          g_s64       = -9007199254740993LL;
u64          g_u64       = 0xFEDCBA9876543210ULL;
f32          g_f32_neg   = -1.5e-8f;
f64          g_f64_big   = 6.02214076e23;
f32          g_f32_zero  = 0.0f;

BigUnion_t   g_union     = { .full = 0x0102030405060708ULL };
Halves_t     g_halves[3] = { {1,2}, {3,4}, {5,6} };
Cell_t       g_cells[2][3] = {
    { {1,2,0,-1}, {0,5,0,100},  {1,7,0,-32768} },
    { {1,1,0,32767}, {0,0,0,0}, {1,3,0,-1} }
};

Tiny_t       g_tiny      = { 0x5A };
char         g_names[3][8] = { "alpha", "beta", "gamma" };
const char  *g_msg       = "hello";
char        *g_strs[2]   = { 0, 0 };

u32          g_matrix[2][3][2] = { { {1,2},{3,4},{5,6} },
                                   { {7,8},{9,10},{11,12} } };

u32         *g_ptr_arr[3];
u32        (*g_arr_ptr)[3];
Handler_t    g_handler;
Compute_t    g_compute;
void        *g_void_ptr  = (void *)0;

volatile const u32 g_vc  = 0xDEADC0DE;
u32 * const  g_const_ptr = &g_matrix[0][0][0];

FlexArray_t  g_flex      = { 0 };

static u32   gs_dup      = 111;      /* aux_cu.c 에도 같은 이름의 static 존재 */

/* 자기참조 이중 포인터 */
typedef struct Chain { s32 v; struct Chain *next; struct Chain **pp; } Chain_t;
Chain_t      g_chain[2];

/* 큰 배열 (지연 로딩 확인) */
u16          g_huge[2048];

extern u32   g_from_other_cu;        /* aux_cu.c 정의 */

/* ======================= 오라클 ======================= */
#ifdef ORACLE
#define P_I(e) printf("%s=%lld\n",  #e, (long long)(e))
#define P_U(e) printf("%s=%llu\n",  #e, (unsigned long long)(e))
#define P_F(e) printf("%s=%.9g\n",  #e, (double)(e))
#define P_P(e) printf("%s=0x%llX\n",#e, (unsigned long long)(uintptr_t)(e))

int main(void)
{
    g_arr_ptr = &g_matrix[0][0];
    g_ptr_arr[0] = &g_matrix[0][0][0];
    g_chain[0].v = 7; g_chain[0].next = &g_chain[1];

    P_U(g_anon.id); P_U(g_anon.major); P_U(g_anon.minor); P_U(g_anon.word);
    P_U(g_anon.b0); P_U(g_anon.b1); P_U(g_anon.b2); P_U(g_anon.b3);

    P_U(g_wide.a); P_U(g_wide.b); P_U(g_wide.c); P_U(g_wide.d);
    P_U(g_packed.head); P_U(g_packed.field); P_U(g_packed.tail);
    P_U(g_zerow.x); P_U(g_zerow.y); P_U(g_zerow.z);
    P_I(g_sbits.trim); P_I(g_sbits.offset); P_U(g_sbits.flag);

    P_I(g_deep.l2.l3.l4.l5.leaf); P_U(g_deep.l2.l3.l4.l5.pad);
    P_U(g_deep.l2.l3.l4.tag); P_U(g_deep.l2.l3.tag);
    P_I(g_deep.l2.tag); P_U(g_deep.tag);

    P_I(g_senum); P_U(g_benum); P_I(g_anon_enum);
    P_U(g_bool_t); P_U(g_bool_f);

    P_I(g_s8); P_I(g_s16); P_I(g_s32); P_I(g_s64); P_U(g_u64);
    P_F(g_f32_neg); P_F(g_f64_big); P_F(g_f32_zero);

    P_U(g_union.raw[0]); P_U(g_union.raw[1]); P_U(g_union.full);
    P_U(g_union.pair[0].lo); P_U(g_union.pair[0].hi);
    P_U(g_union.pair[1].lo); P_U(g_union.pair[1].hi);
    P_F(g_union.dbl);

    P_U(g_halves[0].lo); P_U(g_halves[2].hi);

    P_U(g_cells[0][0].valid); P_U(g_cells[0][0].chan); P_I(g_cells[0][0].value);
    P_U(g_cells[0][2].chan);  P_I(g_cells[0][2].value);
    P_U(g_cells[1][0].valid); P_I(g_cells[1][0].value);
    P_I(g_cells[1][2].value);

    P_U(g_tiny.only);
    P_U(g_matrix[0][0][0]); P_U(g_matrix[0][2][1]);
    P_U(g_matrix[1][0][0]); P_U(g_matrix[1][2][1]);

    P_U(g_vc);
    P_U(gs_dup);
    P_U(g_from_other_cu);
    P_U(g_huge[0]); P_U(g_huge[2047]);
    P_U(g_flex.count);
    return 0;
}
#else
void _start(void)
{
    g_arr_ptr = &g_matrix[0][0];
    g_ptr_arr[0] = &g_matrix[0][0][0];
    g_chain[0].v = 7;
    for (;;) { }
}
#endif
