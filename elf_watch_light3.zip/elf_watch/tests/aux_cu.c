/* aux_cu.c - 두 번째 컴파일 유닛 (동일 이름 static 변수 중복 확인용) */
#include <stdint.h>

static uint32_t gs_dup = 222;      /* edge_cases.c 에도 gs_dup 존재 */
uint32_t g_from_other_cu = 0xCAFEBABEu;

typedef struct { uint16_t a; uint16_t b; } AuxPair_t;
AuxPair_t g_aux_pair = { 0x1234, 0x5678 };

uint32_t aux_touch(void) { return gs_dup + g_from_other_cu + g_aux_pair.a; }
