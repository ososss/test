#!/bin/bash
# run_matrix_tests.sh - 컴파일러 / 아키텍처 / 디버그 형식 매트릭스
#
# 필요:
#   apt-get install gcc clang qemu-user \
#       gcc-powerpc-linux-gnu gcc-arm-linux-gnueabihf gcc-s390x-linux-gnu
#
# 각 바이너리를 실제로 실행한 출력을 정답지로 삼아 파서 결과와 대조한다.

set -u
cd "$(dirname "$0")"

SEED=${1:-20260909}
NTYPES=${2:-90}
PASS=0; FAIL=0; SKIP=0; TOTAL=0

python3 gen_types.py $NTYPES $SEED > /dev/null || exit 1

# $1=라벨 $2=컴파일명령 $3=실행기(빈값=네이티브)
check() {
    local label="$1" cmd="$2" runner="${3:-}"
    local bin=/tmp/mx_$$ out=/tmp/mx_o_$$.txt
    if ! eval "$cmd -o $bin gen_types.c" 2>/dev/null; then
        printf '  %-38s 빌드 불가 (건너뜀)\n' "$label"; SKIP=$((SKIP+1)); return
    fi
    if [ -n "$runner" ]; then
        command -v "$runner" >/dev/null || { printf '  %-38s %s 없음\n' "$label" "$runner"
                                             SKIP=$((SKIP+1)); rm -f $bin; return; }
        $runner $bin > $out 2>/dev/null
    else
        $bin > $out 2>/dev/null
    fi
    local n r
    n=$(wc -l < $out)
    r=$(python3 test_parser.py $bin $out 2>&1 | grep -E '^\[TEST\]')
    printf '  %-38s %s\n' "$label" "${r:-<파싱 예외>}"
    python3 test_parser.py $bin $out 2>&1 | grep -E '^  (MISMATCH|MISSING)' | head -3 | sed 's/^/      /'
    if echo "$r" | grep -q 'fail=0  missing=0'; then PASS=$((PASS+1)); else FAIL=$((FAIL+1)); fi
    TOTAL=$((TOTAL+n))
    rm -f $bin $out
}

echo "=============== 컴파일러 (x86-64) ==============="
for D in 2 3 4 5; do
    check "gcc   -gdwarf-$D"   "gcc   -DORACLE -gdwarf-$D -O0 -no-pie"
    check "clang -gdwarf-$D"   "clang -DORACLE -gdwarf-$D -O0 -no-pie"
done

echo
echo "=============== 아키텍처 / 엔디안 / 워드크기 ==============="
check "PowerPC 32bit BE  dwarf-4" "powerpc-linux-gnu-gcc -DORACLE -gdwarf-4 -O0 -static" qemu-ppc
check "PowerPC 32bit BE  dwarf-2" "powerpc-linux-gnu-gcc -DORACLE -gdwarf-2 -O0 -static" qemu-ppc
check "ARM     32bit LE  dwarf-4" "arm-linux-gnueabihf-gcc -DORACLE -gdwarf-4 -O0 -static" qemu-arm
check "s390x   64bit BE  dwarf-4" "s390x-linux-gnu-gcc -DORACLE -gdwarf-4 -O0 -static" qemu-s390x
check "s390x   64bit BE  dwarf-5" "s390x-linux-gnu-gcc -DORACLE -gdwarf-5 -O0 -static" qemu-s390x

echo
echo "=============== 디버그 섹션 형식 ==============="
check "압축 (-gz)"                "gcc -DORACLE -gdwarf-4 -gz -O0 -no-pie"
check "압축 (-gz=zlib-gnu)"       "gcc -DORACLE -gdwarf-4 -gz=zlib-gnu -O0 -no-pie"
check "타입유닛 dwarf-4"          "gcc -DORACLE -gdwarf-4 -fdebug-types-section -O0 -no-pie"
check "타입유닛 dwarf-5"          "gcc -DORACLE -gdwarf-5 -fdebug-types-section -O0 -no-pie"
check "LTO dwarf-4"               "gcc -DORACLE -gdwarf-4 -flto -O0 -no-pie"
check "LTO dwarf-5"               "gcc -DORACLE -gdwarf-5 -flto -O0 -no-pie"
check "엄격 (-gstrict-dwarf)"     "gcc -DORACLE -gdwarf-4 -gstrict-dwarf -O0 -no-pie"
check "섹션분리 + gc-sections"    "gcc -DORACLE -gdwarf-4 -ffunction-sections -fdata-sections -O0 -no-pie -Wl,--gc-sections"
check "매크로 포함 (-g3)"         "gcc -DORACLE -gdwarf-4 -g3 -O0 -no-pie"
check "PIE"                       "gcc -DORACLE -gdwarf-4 -O0 -fPIE -pie"
check "DWARF64 형식 (-gdwarf64)"  "gcc -DORACLE -gdwarf-4 -gdwarf64 -O0 -no-pie"
check "DWARF64 + DWARF5"          "gcc -DORACLE -gdwarf-5 -gdwarf64 -O0 -no-pie"
check "DWARF64 + 타입유닛"        "gcc -DORACLE -gdwarf-4 -gdwarf64 -fdebug-types-section -O0 -no-pie"

echo
echo "=============== 분리 디버그 정보 ==============="
DB=/tmp/mx_dbg_$$
mkdir -p $DB && cp gen_types.c gen_types.h $DB/ 2>/dev/null
if (cd $DB && gcc -DORACLE -gdwarf-4 -O0 -no-pie -o app gen_types.c 2>/dev/null \
    && objcopy --only-keep-debug app app.debug \
    && objcopy --strip-debug app \
    && objcopy --add-gnu-debuglink=app.debug app && ./app > o.txt); then
    R=$(python3 test_parser.py $DB/app $DB/o.txt 2>&1 | grep -E '^\[TEST\]')
    printf '  %-38s %s\n' ".gnu_debuglink 분리 디버그 파일" "$R"
    echo "$R" | grep -q 'fail=0  missing=0' && PASS=$((PASS+1)) || FAIL=$((FAIL+1))
    N=$(wc -l < $DB/o.txt); TOTAL=$((TOTAL+N))
else
    printf '  %-38s 건너뜀\n' ".gnu_debuglink"; SKIP=$((SKIP+1))
fi
rm -rf $DB

echo
echo "=============== 베어메탈 ROM 이미지 (LMA != VMA) ==============="
# MPC5674F 처럼 초기화 데이터를 flash 에 두고 RAM 에서 실행하는 배치.
# 실행할 수 없으므로, 같은 소스를 호스트용으로 빌드해 실행한 값을 정답지로 쓴다.
if powerpc-linux-gnu-gcc -mbig-endian -m32 -O0 -gdwarf-4 -ffreestanding \
        -nostdlib -nostartfiles -T rom_image.ld -o /tmp/mx_rom_$$ gen_types.c 2>/dev/null \
   && powerpc-linux-gnu-gcc -DORACLE -gdwarf-4 -O0 -static -o /tmp/mx_romhost_$$ gen_types.c 2>/dev/null \
   && command -v qemu-ppc > /dev/null; then
    qemu-ppc /tmp/mx_romhost_$$ > /tmp/mx_romo_$$.txt 2>/dev/null
    R=$(python3 test_parser.py /tmp/mx_rom_$$ /tmp/mx_romo_$$.txt 2>&1 | grep -E '^\[TEST\]')
    printf '  %-38s %s\n' "ROM 이미지 (flash LMA / SRAM VMA)" "$R"
    echo "$R" | grep -q 'fail=0  missing=0' && PASS=$((PASS+1)) || FAIL=$((FAIL+1))
    N=$(wc -l < /tmp/mx_romo_$$.txt); TOTAL=$((TOTAL+N))
    rm -f /tmp/mx_rom_$$ /tmp/mx_romhost_$$ /tmp/mx_romo_$$.txt
else
    printf '  %-38s 건너뜀\n' "ROM 이미지"; SKIP=$((SKIP+1))
fi

echo
echo "=============== 결과 ==============="
echo "  통과 $PASS / 실패 $FAIL / 건너뜀 $SKIP"
echo "  누적 비교 항목: $TOTAL"
exit $FAIL
