#!/bin/bash
# run_combo_tests.sh - 타입 조합 대량 검증
#
#   ./run_combo_tests.sh [시드목록...]
#
# gen_types.py 로 구조체/공용체/배열/비트필드/포인터/enum 조합을 생성하고,
# 각 바이너리를 실제로 실행한 출력과 파서 결과를 리프 단위로 대조한다.
# 빅엔디안 바이너리는 qemu-ppc 로 실행한다.

set -u
cd "$(dirname "$0")"

SEEDS=${@:-"20260909 1 7 42 555 8888 31337"}
NTYPES=90
TOTAL=0
FAILCFG=0
PASSCFG=0

echo "시드: $SEEDS"
echo

for S in $SEEDS; do
    python3 gen_types.py $NTYPES $S > /dev/null || continue

    for D in dwarf-2 dwarf-4 dwarf-5; do
        # --- little endian (네이티브 실행)
        if gcc -DORACLE -g$D -O0 -no-pie -o /tmp/ct_le_$$ gen_types.c 2>/dev/null; then
            /tmp/ct_le_$$ > /tmp/ct_o_$$.txt
            N=$(wc -l < /tmp/ct_o_$$.txt)
            R=$(python3 test_parser.py /tmp/ct_le_$$ /tmp/ct_o_$$.txt 2>/dev/null | grep '^\[TEST\]')
            printf '  seed %-9s %-8s LE  항목 %6d  %s\n' "$S" "$D" "$N" "$R"
            python3 test_parser.py /tmp/ct_le_$$ /tmp/ct_o_$$.txt 2>/dev/null \
                | grep -E '^  (MISMATCH|MISSING)' | head -5 | sed 's/^/      /'
            echo "$R" | grep -q 'fail=0  missing=0' && PASSCFG=$((PASSCFG+1)) || FAILCFG=$((FAILCFG+1))
            TOTAL=$((TOTAL+N))
        fi

        # --- big endian (qemu 실행)
        if command -v qemu-ppc > /dev/null && \
           powerpc-linux-gnu-gcc -DORACLE -g$D -O0 -static -o /tmp/ct_be_$$ gen_types.c 2>/dev/null; then
            qemu-ppc /tmp/ct_be_$$ > /tmp/ct_o_$$.txt
            N=$(wc -l < /tmp/ct_o_$$.txt)
            R=$(python3 test_parser.py /tmp/ct_be_$$ /tmp/ct_o_$$.txt 2>/dev/null | grep '^\[TEST\]')
            printf '  seed %-9s %-8s BE  항목 %6d  %s\n' "$S" "$D" "$N" "$R"
            python3 test_parser.py /tmp/ct_be_$$ /tmp/ct_o_$$.txt 2>/dev/null \
                | grep -E '^  (MISMATCH|MISSING)' | head -5 | sed 's/^/      /'
            echo "$R" | grep -q 'fail=0  missing=0' && PASSCFG=$((PASSCFG+1)) || FAILCFG=$((FAILCFG+1))
            TOTAL=$((TOTAL+N))
        fi
    done
    rm -f /tmp/ct_le_$$ /tmp/ct_be_$$ /tmp/ct_o_$$.txt
done

echo
echo "구성 $((PASSCFG+FAILCFG))개 중 $PASSCFG 통과 / $FAILCFG 실패"
echo "누적 비교 항목: $TOTAL"
exit $FAILCFG
