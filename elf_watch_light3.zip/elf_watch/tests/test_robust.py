import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from dwarf_reader import DwarfReader

cases = ['stripped_elf', 'relocatable.o', 'truncated.elf',
         'notanelf.bin', 'fakehdr.elf', '/dev/null', 'no_such_file']

for f in cases:
    try:
        rd = DwarfReader(f)
        s = rd.summary()
        print('%-16s OK   globals=%-4d %s %s DWARF v%s' %
              (f, len(rd.globals), s['class'], s['endian'], s['dwarf']))
        # 트리를 실제로 걸어본다 (지연 생성 중 예외 확인)
        n = 0
        stack = list(rd.globals)
        while stack and n < 3000:
            node = stack.pop()
            node.value_text()
            node.type_text
            n += 1
            if node.has_children():
                stack.extend(node.children()[:20])
        print('%-16s      트리 %d 노드 순회 정상' % ('', n))
        rd.close()
    except Exception as e:
        print('%-16s %s: %s' % (f, type(e).__name__, str(e)[:70]))
