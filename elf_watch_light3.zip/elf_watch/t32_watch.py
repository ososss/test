"""
t32_watch.py  -  TRACE32 Watch View 스타일 ELF 전역변수 뷰어

  python t32_watch.py [file.elf]

좌측  : 전역변수 심볼 브라우저 (필터 지원, 더블클릭 = Watch 추가)
우측  : Watch 트리 - Symbol / Value / Type / Address / Size
        구조체 · 공용체 · 배열(다차원) · 비트필드를 단계별로 전개

값은 ELF 섹션 이미지에서 읽은 '초기값'이다. 타깃에 연결된 상태가 아니므로
런타임 값이 아니라는 점에 유의. (.bss 는 0 으로 표시)
"""

from __future__ import annotations

import sys
import csv

from PyQt6.QtCore import (Qt, QAbstractItemModel, QModelIndex, QSize,
                          QSortFilterProxyModel, QStringListModel)
from PyQt6.QtGui import QAction, QColor, QFont, QKeySequence, QPalette
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QTreeView, QListView, QWidget, QVBoxLayout,
    QHBoxLayout, QLineEdit, QLabel, QSplitter, QToolBar, QFileDialog,
    QMessageBox, QStatusBar, QHeaderView, QAbstractItemView, QMenu,
    QStyleFactory, QComboBox, QPushButton,
)
from dwarf_reader import DwarfReader, VarNode
from memdump import MemoryDump


MONO = 'Consolas' if sys.platform.startswith('win') else 'DejaVu Sans Mono'

# TRACE32 PowerView 색감 근사치
COL_BG        = '#F2F2F0'
COL_GRID      = '#D0D0CC'
COL_HEADER_BG = '#DCDCD8'
COL_VALUE     = '#0000C0'      # 값 = 파랑
COL_TYPE      = '#606060'
COL_ADDR      = '#008000'      # 주소 = 녹색
COL_BITFIELD  = '#A00060'
COL_SELECT    = '#B4C8E6'
COL_MISMATCH  = '#FFD6D6'      # 채널 불일치 행
COL_MISMATCH_FG = '#B00000'


# ==================================================================== 모델
class WatchModel(QAbstractItemModel):
    """덤프를 붙이면 값 칼럼이 채널 수만큼 늘어난다."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._roots: list[VarNode] = []
        self._all_roots: list[VarNode] = []
        self.hex_mode = False
        self.dump: MemoryDump | None = None
        self.channel_mems: list = []
        self.dump_only = False
        self.reader: DwarfReader | None = None
        self._rebuild_headers()

    # ---------- 칼럼 구성
    def _rebuild_headers(self):
        if self.dump:
            names = [c.name for c in self.dump.channels]
        else:
            names = ['value']
        self.value_cols = len(names)
        self.HEADERS = ['symbol'] + names + ['type', 'address', 'size']
        self.COL_NAME = 0
        self.COL_TYPE = 1 + self.value_cols
        self.COL_ADDR = self.COL_TYPE + 1
        self.COL_SIZE = self.COL_ADDR + 1

    def set_dump(self, dump: MemoryDump | None, reader: DwarfReader | None):
        self.beginResetModel()
        self.dump = dump
        self.reader = reader
        self.channel_mems = list(dump.channels) if dump else []
        self._rebuild_headers()
        self._apply_filter()
        self.endResetModel()

    def set_dump_only(self, on: bool):
        self.beginResetModel()
        self.dump_only = on
        self._apply_filter()
        self.endResetModel()

    def _apply_filter(self):
        if self.dump_only and self.dump:
            self._roots = [n for n in self._all_roots
                           if n.address is not None
                           and self.dump.covers(n.address, n.byte_size or 1)]
        else:
            self._roots = list(self._all_roots)
        for r, n in enumerate(self._roots):
            n.row = r
            n.parent = None

    # ---------- 데이터 설정 ----------
    def set_roots(self, nodes: list[VarNode]):
        self.beginResetModel()
        self._all_roots = list(nodes)
        self._apply_filter()
        self.endResetModel()

    def add_root(self, node: VarNode):
        self.beginResetModel()
        self._all_roots.append(node)
        self._apply_filter()
        self.endResetModel()

    def remove_root(self, row: int):
        if not (0 <= row < len(self._roots)):
            return
        node = self._roots[row]
        self.beginResetModel()
        if node in self._all_roots:
            self._all_roots.remove(node)
        self._apply_filter()
        self.endResetModel()

    def clear(self):
        self.set_roots([])

    # ---------- 채널 값 / 불일치
    def _channel_values(self, node: VarNode) -> list:
        if not self.channel_mems or self.reader is None:
            return [node.value_text(self.hex_mode)]
        return self.reader.values_across(node, self.channel_mems, self.hex_mode)

    def _is_mismatch(self, node: VarNode) -> bool:
        if len(self.channel_mems) < 2 or self.reader is None:
            return False
        return self.reader.mismatch_across(node, self.channel_mems)

    def roots(self):
        return self._roots

    def set_hex_mode(self, on: bool):
        self.hex_mode = on
        self.layoutChanged.emit()

    # ---------- QAbstractItemModel ----------
    def node(self, index: QModelIndex) -> VarNode | None:
        return index.internalPointer() if index.isValid() else None

    def index(self, row, column, parent=QModelIndex()):
        if not self.hasIndex(row, column, parent):
            return QModelIndex()
        if not parent.isValid():
            if row >= len(self._roots):
                return QModelIndex()
            return self.createIndex(row, column, self._roots[row])
        pnode: VarNode = parent.internalPointer()
        kids = pnode.children()
        if row >= len(kids):
            return QModelIndex()
        return self.createIndex(row, column, kids[row])

    def parent(self, index):
        if not index.isValid():
            return QModelIndex()
        node: VarNode = index.internalPointer()
        p = node.parent
        if p is None:
            return QModelIndex()
        return self.createIndex(p.row, 0, p)

    def rowCount(self, parent=QModelIndex()):
        if not parent.isValid():
            return len(self._roots)
        if parent.column() > 0:
            return 0
        node: VarNode = parent.internalPointer()
        if not node.has_children():
            return 0
        return len(node.children())

    def hasChildren(self, parent=QModelIndex()):
        if not parent.isValid():
            return bool(self._roots)
        node: VarNode = parent.internalPointer()
        return node.has_children()

    def columnCount(self, parent=QModelIndex()):
        return len(self.HEADERS)

    def _is_value_col(self, col: int) -> bool:
        return 1 <= col <= self.value_cols

    def headerData(self, section, orientation, role=Qt.ItemDataRole.DisplayRole):
        if orientation != Qt.Orientation.Horizontal:
            return None
        if role == Qt.ItemDataRole.DisplayRole:
            return self.HEADERS[section]
        if role == Qt.ItemDataRole.FontRole:
            f = QFont(MONO, 9)
            f.setBold(True)
            return f
        return None

    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid():
            return None
        node: VarNode = index.internalPointer()
        col = index.column()

        if role == Qt.ItemDataRole.DisplayRole:
            if col == self.COL_NAME:
                if self._is_mismatch(node):
                    return '\u26a0 ' + node.name
                return node.name
            if self._is_value_col(col):
                vals = self._channel_values(node)
                i = col - 1
                return vals[i] if i < len(vals) else ''
            if col == self.COL_TYPE:
                return node.type_text
            if col == self.COL_ADDR:
                return node.address_text
            if col == self.COL_SIZE:
                return node.size_text

        if role == Qt.ItemDataRole.FontRole:
            f = QFont(MONO, 9)
            if col == self.COL_NAME and node.parent is None:
                f.setBold(True)
            return f

        if role == Qt.ItemDataRole.BackgroundRole:
            if self._is_mismatch(node):
                return QColor(COL_MISMATCH)

        if role == Qt.ItemDataRole.ForegroundRole:
            if self._is_value_col(col) or col == self.COL_NAME:
                if self._is_mismatch(node):
                    return QColor(COL_MISMATCH_FG)
            if self._is_value_col(col):
                return QColor(COL_BITFIELD if node.bit_size is not None else COL_VALUE)
            if col == self.COL_TYPE:
                return QColor(COL_TYPE)
            if col == self.COL_ADDR:
                return QColor(COL_ADDR)

        if role == Qt.ItemDataRole.TextAlignmentRole and col == self.COL_SIZE:
            return Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter

        if role == Qt.ItemDataRole.ToolTipRole:
            t = node.type
            if t is None:
                return None
            lines = [f'{node.name}',
                     f'type   : {node.type_text}',
                     f'kind   : {t.kind}',
                     f'addr   : {node.address_text or "-"}',
                     f'size   : {node.size_text or "-"}']
            if t.typedef_name:
                lines.append(f'typedef: {t.typedef_name}')
            return '\n'.join(lines)
        return None


# ==================================================================== 메인 윈도우
class WatchWindow(QMainWindow):

    def __init__(self, elf_path: str | None = None):
        super().__init__()
        self.reader: DwarfReader | None = None
        self.dump: MemoryDump | None = None
        self._elf_status = ''
        self.setWindowTitle('ELF Watch  -  TRACE32 style variable browser')
        self.resize(1280, 760)

        self._build_ui()
        self._build_toolbar()

        if elf_path:
            self.load_elf(elf_path)

    # ---------------------------------------------------------- UI
    def _build_ui(self):
        splitter = QSplitter(Qt.Orientation.Horizontal)

        # ---- 좌측: 심볼 브라우저
        left = QWidget()
        lv = QVBoxLayout(left)
        lv.setContentsMargins(4, 4, 4, 4)
        lv.setSpacing(3)

        hdr = QLabel('  symbols')
        hdr.setStyleSheet(
            f'background:{COL_HEADER_BG}; border:1px solid {COL_GRID}; padding:3px;'
            f'font-family:"{MONO}"; font-weight:bold;')
        lv.addWidget(hdr)

        self.sym_filter = QLineEdit()
        self.sym_filter.setPlaceholderText('filter (예: g_fcs, *rate*)')
        self.sym_filter.setFont(QFont(MONO, 9))
        self.sym_filter.textChanged.connect(self._on_filter)
        lv.addWidget(self.sym_filter)

        self.sym_view = QListView()
        self.sym_view.setFont(QFont(MONO, 9))
        self.sym_model = QStringListModel()
        self.sym_proxy = QSortFilterProxyModel()
        self.sym_proxy.setSourceModel(self.sym_model)
        self.sym_proxy.setFilterCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
        self.sym_view.setModel(self.sym_proxy)
        self.sym_view.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.sym_view.setSelectionMode(
            QAbstractItemView.SelectionMode.ExtendedSelection)
        self.sym_view.doubleClicked.connect(self._on_symbol_activated)
        lv.addWidget(self.sym_view, 1)

        btn = QPushButton('add to watch  (더블클릭)')
        btn.setFont(QFont(MONO, 9))
        btn.clicked.connect(self._add_selected_symbols)
        lv.addWidget(btn)

        splitter.addWidget(left)

        # ---- 우측: Watch 트리
        right = QWidget()
        rv = QVBoxLayout(right)
        rv.setContentsMargins(4, 4, 4, 4)
        rv.setSpacing(3)

        self.watch_hdr = QLabel('  B::Var.Watch')
        self.watch_hdr.setStyleSheet(
            f'background:{COL_HEADER_BG}; border:1px solid {COL_GRID}; padding:3px;'
            f'font-family:"{MONO}"; font-weight:bold;')
        rv.addWidget(self.watch_hdr)

        self.tree = QTreeView()
        self.tree.setFont(QFont(MONO, 9))
        self.tree.setAlternatingRowColors(True)
        self.tree.setUniformRowHeights(True)
        self.tree.setAnimated(False)
        self.tree.setIndentation(16)
        self.tree.setExpandsOnDoubleClick(True)
        self.tree.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.tree.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.tree.customContextMenuRequested.connect(self._on_tree_menu)
        self.tree.setStyleSheet(f"""
            QTreeView {{
                background: {COL_BG};
                alternate-background-color: #E9E9E6;
                selection-background-color: {COL_SELECT};
                selection-color: black;
                border: 1px solid {COL_GRID};
            }}
            QTreeView::item {{ border-right: 1px solid {COL_GRID}; padding: 1px; }}
            QHeaderView::section {{
                background: {COL_HEADER_BG};
                border: 1px solid {COL_GRID};
                padding: 3px;
                font-weight: bold;
            }}
        """)

        self.model = WatchModel(self)
        self.tree.setModel(self.model)
        rv.addWidget(self.tree, 1)

        splitter.addWidget(right)
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 4)
        splitter.setSizes([300, 980])
        self.setCentralWidget(splitter)

        self.setStatusBar(QStatusBar())
        self.statusBar().setFont(QFont(MONO, 9))
        self.statusBar().showMessage('ELF 파일을 열어 주세요  (Ctrl+O)')

    def _build_toolbar(self):
        tb = QToolBar('main')
        tb.setIconSize(QSize(16, 16))
        tb.setFont(QFont(MONO, 9))
        self.addToolBar(tb)

        act_open = QAction('Open ELF', self)
        act_open.setShortcut(QKeySequence.StandardKey.Open)
        act_open.triggered.connect(self._on_open)
        tb.addAction(act_open)

        tb.addSeparator()

        act_all = QAction('Watch All Globals', self)
        act_all.triggered.connect(self._watch_all)
        tb.addAction(act_all)

        act_clear = QAction('Clear', self)
        act_clear.triggered.connect(self.model.clear)
        tb.addAction(act_clear)

        tb.addSeparator()

        self.act_hex = QAction('Hex', self)
        self.act_hex.setCheckable(True)
        self.act_hex.setShortcut('Ctrl+H')
        self.act_hex.toggled.connect(self._on_hex)
        tb.addAction(self.act_hex)

        act_exp = QAction('Expand +2', self)
        act_exp.triggered.connect(lambda: self.tree.expandToDepth(1))
        tb.addAction(act_exp)

        act_col = QAction('Collapse', self)
        act_col.triggered.connect(self.tree.collapseAll)
        tb.addAction(act_col)

        tb.addSeparator()

        act_dump = QAction('Load Dump', self)
        act_dump.setShortcut('Ctrl+D')
        act_dump.triggered.connect(self._on_load_dump)
        tb.addAction(act_dump)

        self.act_dump_only = QAction('덤프 변수만', self)
        self.act_dump_only.setCheckable(True)
        self.act_dump_only.setEnabled(False)
        self.act_dump_only.toggled.connect(self.model.set_dump_only)
        tb.addAction(self.act_dump_only)

        act_unload = QAction('Unload Dump', self)
        act_unload.triggered.connect(self._on_unload_dump)
        tb.addAction(act_unload)

        tb.addSeparator()

        act_csv = QAction('Export CSV', self)
        act_csv.triggered.connect(self._export_csv)
        tb.addAction(act_csv)

    # ---------------------------------------------------------- 동작
    def _on_open(self):
        path, _ = QFileDialog.getOpenFileName(
            self, 'ELF 파일 선택', '', 'ELF files (*.elf *.out *.axf *.o);;All files (*)')
        if path:
            self.load_elf(path)

    def load_elf(self, path: str):
        try:
            if self.reader:
                self.reader.close()
            self.reader = DwarfReader(path)
        except Exception as e:
            QMessageBox.critical(self, 'ELF 로드 실패', str(e))
            return

        self.model.clear()
        from collections import Counter
        cnt = Counter(g.name for g in self.reader.globals)
        names = [f'{g.name}   (line {g.decl_line})' if cnt[g.name] > 1 else g.name
                 for g in self.reader.globals]
        self.sym_model.setStringList(names)

        s = self.reader.summary()
        self.setWindowTitle(f'ELF Watch  -  {path}')
        msg = (f"  {s['class']} / {s['machine']} / {s['endian']}-endian   "
               f"DWARF v{s['dwarf']}   globals: {s['globals']}")
        if s.get('optimized_out'):
            msg += f"   (저장공간 없음 {s['optimized_out']})"
        for w in s.get('warnings', []):
            msg += f"   [!] {w}"
        self._elf_status = msg
        self.statusBar().showMessage(msg)
        self._watch_all()

    def load_elf_status(self):
        self.statusBar().showMessage(getattr(self, '_elf_status', ''))

    def _on_filter(self, text: str):
        pat = text.strip().replace('*', '')
        self.sym_proxy.setFilterFixedString(pat)

    def _node_at_row(self, source_row: int) -> VarNode | None:
        """심볼 목록의 행 번호로 전역변수를 집는다.
        같은 이름의 static 변수가 여러 CU 에 있을 수 있으므로
        이름이 아니라 행 인덱스로 매칭해야 한다."""
        if not self.reader or not (0 <= source_row < len(self.reader.globals)):
            return None
        g = self.reader.globals[source_row]
        node = VarNode(g.name, g.type, g.address, self.reader)
        node.no_storage = g.no_storage
        node.const_value = g.const_value
        return node

    def _on_symbol_activated(self, proxy_index):
        row = self.sym_proxy.mapToSource(proxy_index).row()
        node = self._node_at_row(row)
        if node:
            self.model.add_root(node)

    def _add_selected_symbols(self):
        rows = {self.sym_proxy.mapToSource(i).row()
                for i in self.sym_view.selectionModel().selectedIndexes()}
        for r in sorted(rows):
            node = self._node_at_row(r)
            if node:
                self.model.add_root(node)

    def _watch_all(self):
        if not self.reader:
            return
        nodes = []
        for g in self.reader.globals:
            n = VarNode(g.name, g.type, g.address, self.reader)
            n.no_storage = g.no_storage
            n.const_value = g.const_value
            nodes.append(n)
        self.model.set_roots(nodes)
        self._resize_columns()

    def _on_load_dump(self):
        if not self.reader:
            QMessageBox.information(self, '덤프 로드',
                                    '먼저 ELF 파일을 열어 주세요.')
            return
        path, _ = QFileDialog.getOpenFileName(
            self, '메모리 덤프 선택', '',
            'Dump files (*.csv *.log *.txt);;All files (*)')
        if not path:
            return
        try:
            dump = MemoryDump(path, big_endian=self.reader.big_endian)
        except Exception as e:
            QMessageBox.critical(self, '덤프 로드 실패', str(e))
            return

        self.dump = dump
        self.model.set_dump(dump, self.reader)
        self.act_dump_only.setEnabled(True)
        self._resize_columns()

        covered = sum(1 for g in self.model._all_roots
                      if g.address is not None
                      and dump.covers(g.address, g.byte_size or 1))
        msg = (f'  덤프: {dump.summary()}   '
               f'채널 {", ".join(dump.channel_names)}   '
               f'덤프에 포함된 전역 {covered}/{len(self.model._all_roots)}')
        for n in dump.notes:
            msg += f'   [!] {n}'
        self.statusBar().showMessage(msg)
        self.watch_hdr.setText(f'  B::Var.Watch   [{path.split("/")[-1]}]')

    def _on_unload_dump(self):
        self.dump = None
        self.act_dump_only.setChecked(False)
        self.act_dump_only.setEnabled(False)
        self.model.set_dump(None, self.reader)
        self._resize_columns()
        self.watch_hdr.setText('  B::Var.Watch')
        if self.reader:
            self.load_elf_status()

    def _resize_columns(self):
        m = self.model
        self.tree.setColumnWidth(m.COL_NAME, 260)
        w = 220 if m.value_cols == 1 else 150
        for c in range(1, 1 + m.value_cols):
            self.tree.setColumnWidth(c, w)
        self.tree.setColumnWidth(m.COL_TYPE, 190)
        self.tree.setColumnWidth(m.COL_ADDR, 120)
        self.tree.setColumnWidth(m.COL_SIZE, 60)
        self.tree.header().setStretchLastSection(False)

    def _on_hex(self, on: bool):
        self.model.set_hex_mode(on)

    def _on_tree_menu(self, pos):
        index = self.tree.indexAt(pos)
        menu = QMenu(self)
        if index.isValid():
            node = self.model.node(index)
            act_exp = menu.addAction('expand subtree')
            act_copy = menu.addAction('copy address')
            menu.addSeparator()
            act_del = menu.addAction('remove from watch')
            chosen = menu.exec(self.tree.viewport().mapToGlobal(pos))
            if chosen == act_exp:
                self._expand_recursive(index, 4)
            elif chosen == act_copy:
                QApplication.clipboard().setText(node.address_text)
            elif chosen == act_del:
                root = index
                while root.parent().isValid():
                    root = root.parent()
                self.model.remove_root(root.row())
        else:
            act_all = menu.addAction('watch all globals')
            if menu.exec(self.tree.viewport().mapToGlobal(pos)) == act_all:
                self._watch_all()

    def _expand_recursive(self, index, depth):
        if depth <= 0 or not index.isValid():
            return
        self.tree.expand(index)
        for r in range(self.model.rowCount(index)):
            self._expand_recursive(self.model.index(r, 0, index), depth - 1)

    def _export_csv(self):
        if not self.model.roots():
            return
        path, _ = QFileDialog.getSaveFileName(self, 'CSV 저장', 'watch.csv',
                                              'CSV (*.csv)')
        if not path:
            return
        rows = []

        def walk(node, depth):
            vals = self.model._channel_values(node)
            flag = ['MISMATCH'] if self.model._is_mismatch(node) else ['']
            rows.append(['  ' * depth + node.name] + vals +
                        [node.type_text, node.address_text, node.size_text] + flag)
            if depth < 8 and node.has_children():
                for c in node.children():
                    walk(c, depth + 1)

        for r in self.model.roots():
            walk(r, 0)
        with open(path, 'w', newline='', encoding='utf-8-sig') as f:
            w = csv.writer(f)
            w.writerow(self.model.HEADERS + ['flag'])
            w.writerows(rows)
        self.statusBar().showMessage(f'  CSV 저장 완료: {path}  ({len(rows)} rows)')


def main():
    app = QApplication(sys.argv)
    app.setStyle(QStyleFactory.create('Fusion'))
    pal = app.palette()
    pal.setColor(QPalette.ColorRole.Window, QColor('#ECECE8'))
    app.setPalette(pal)

    path = sys.argv[1] if len(sys.argv) > 1 else None
    win = WatchWindow(path)
    win.show()
    sys.exit(app.exec())


if __name__ == '__main__':
    main()
