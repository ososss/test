# ELF Watch — TRACE32 Watch View 스타일 전역변수 뷰어

ELF 안의 DWARF 디버깅 정보만으로 전역변수 목록과 타입 트리를 뽑아
TRACE32 `Var.Watch` 와 유사한 형태로 보여주는 PyQt6 도구. **소스코드는 필요 없다.**

```
symbol                     value                    type                address        size
─────────────────────────────────────────────────────────────────────────────────────────────
▼ g_bus1_status            {...}                    BusStatusBits_t     0x400000B4        4
    valid                  1                        u32 : 1             0x400000B4.0    1 bit
    stale                  0                        u32 : 1             0x400000B4.1    1 bit
    channel_id             5                        u32 : 3             0x400000B4.2    3 bit
    subaddress             17                       u32 : 5             0x400000B4.5    5 bit
▼ g_gain_table             (3)                      f32[3][4]           0x40000060       48
  ▼ [0]                    (4) {1, 2, 3, 4}         f32[4]              0x40000060       16
      [0]                  1                        f32                 0x40000060        4
▼ g_fault_head             0x40000248 <g_fault_pool> FaultNode_t *      0x400000C4        4
  ▼ *g_fault_head          {...}                    FaultNode_t         0x40000248       12
```

## 실행

```bash
pip install pyelftools PyQt6
python t32_watch.py sample/fcs_sample_dwarf4.elf
```

덤프까지 얹어 보려면 실행 후 **Load Dump** (Ctrl+D) 로
`sample/fcs_dump_3ch.log` 를 여세요. 채널 C 에 불일치 두 곳이 들어 있습니다.

GUI 없이 콘솔에서 확인:

```bash
python dwarf_reader.py sample/fcs_sample_dwarf4.elf 3     # 마지막 인자 = 전개 깊이
```

## 파일 구성

| 파일 | 내용 |
|---|---|
| `dwarf_reader.py` | DWARF 파싱 · 타입 해석 · 값 디코딩 (GUI 비의존, 단독 사용 가능) |
| `memdump.py` | 메모리 덤프(.csv/.log) 파서 (GUI 비의존, 단독 사용 가능) |
| `t32_watch.py` | PyQt6 GUI (`QAbstractItemModel` + `QTreeView`) |
| `sample/fcs_sample.c` | 검증용 샘플 소스 |
| `sample/mpc5674f_like.ld` | MPC5674F 유사 메모리 맵 (Flash 0x0000_0000 / SRAM 0x4000_0000) |
| `sample/fcs_sample_dwarf{2,4,5}.elf` | **32bit 빅엔디안 PowerPC** ELF (DWARF 2 / 4 / 5) |
| `sample/fcs_dump_3ch.log` | 위 ELF 에 맞는 3채널 덤프 (채널 C 에 불일치 2곳) |
| `sample/dump_example{1,2}.{log,csv}` | 두 가지 덤프 형식 최소 예제 |

샘플 ELF 생성 명령:

```bash
powerpc-linux-gnu-gcc -mbig-endian -m32 -O0 -gdwarf-4 -g3 \
    -ffreestanding -nostdlib -nostartfiles \
    -T mpc5674f_like.ld -o fcs_sample_dwarf4.elf fcs_sample.c
```

## 메모리 덤프 (.csv / .log) 연동

실제 타깃에서 뽑은 덤프를 얹어 **삼중화 채널 3개의 값을 나란히** 볼 수 있다.

```
symbol            Channel A    Channel B    Channel C    type            address
▼ ⚠ g_bus1_status  {...}        {...}        {...}       BusStatusBits_t 0x400000B4
    valid          1            1            1           u32 : 1         0x400000B4.0
    channel_id     5            5            5           u32 : 3         0x400000B4.2
  ⚠ word_count     32           32           36          u32 : 6         0x400000B5.2
```

- **채널 불일치 자동 강조** — 리프 단위로 비교하고 상위 노드까지 전파한다.
  비트필드는 추출값으로, 나머지는 원시 바이트로 비교하므로
  구조체·배열도 한 번에 걸린다.
- **덤프 변수만 보기** 토글 — 덤프에 주소가 들어있는 전역만 남긴다.
- 덤프에 없는 주소는 `<no data>` 로 표시된다.

### 지원 형식

`Address` 가 나오는 헤더 줄을 찾고 그 다음 줄부터 hex 토큰만 뽑는다.
구분자를 신뢰하지 않으므로 아래 두 가지가 같은 방식으로 처리된다.

```
 Address    Channel A     Channel B     Channel C
0x40000000     0xaaaaaaaa  0xaaaaaaaa 0xaaaaaaaa
```

```
Address, Ch_A, ,Ch_B, ,Ch_C
="40000000" ,="aaaa",="aaaa" ,="aaaa",="aaaa" ,"aaaa",="aaaa" ,
```

`0x` 유무, `="..."` 포장, 따옴표, 쉼표, 다중 공백, 탭, CRLF, BOM 을 흡수한다.
채널당 값이 2칸인 경우(16비트 상/하위 분할)는 **상위+하위 순서로 32비트 한 값**
으로 합친다. 채널 수와 워드 폭은 헤더와 데이터에서 추론하며, 추론에 의존한
경우 상태바에 알린다.

콘솔에서 덤프만 확인하려면:

```bash
python memdump.py dump.csv big     # big | little
```

## 기능

- 전역변수 자동 수집 (`DW_TAG_variable` + `DW_OP_addr` / `DW_OP_addrx`)
- 구조체 · 공용체 · 익명 union · 다차원 배열 · enum · typedef · 포인터 전개
- **비트필드**: DWARF 2/3 의 `DW_AT_bit_offset` 과 DWARF 4/5 의 `DW_AT_data_bit_offset`
  양쪽 인코딩 지원, 엔디안별 시프트 방향 처리
- 값 표시: ELF 섹션 이미지에서 읽은 **정적 초기값** (`.bss` 는 0)
- Hex / Dec 토글 (`Ctrl+H`), 심볼 필터, CSV 내보내기
- 자식 노드 지연 생성 → 512 요소 배열도 즉시 로드

## 설계 메모

**엔디안** — MPC5674F 는 빅엔디안이라 비트필드 시프트가 리틀엔디안과 반대다.

- DWARF 2/3, BE: `DW_AT_bit_offset` 이 이미 컨테이너 MSB 기준 → 그대로 사용
- DWARF 2/3, LE: `container_bits - bit_offset - bit_size` 로 LSB 기준 변환
- DWARF 4/5: `DW_AT_data_bit_offset` 은 구조체 시작부터 메모리 증가 방향 기준.
  저장 단위 경계로 재정렬한 뒤 위와 동일하게 처리

GCC 13 기준 `-gdwarf-4` 는 여전히 `DW_AT_bit_offset` 을, `-gdwarf-5` 는
`DW_AT_data_bit_offset` 을 낸다. 세 버전 모두 동일 결과를 내는 것으로 검증했다.

**자기참조 방어** — `TypeInfo` 를 DIE offset 캐시에 *먼저 등록한 뒤* 채운다.
포인터 전개는 `MAX_POINTER_DEPTH = 3` 으로 제한.

## CodeWarrior ELF 적용 시 확인할 것

0. **다른 컴파일러의 DWARF 방언**. clang 검증에서 GCC 와 다른 인코딩
   (부호 없는 form 에 담긴 음수 비트 오프셋)이 드러났다. CodeWarrior 도
   자체 방언이 있을 수 있으므로, 실물 ELF 로 한 번은 대조 검증하는 것이 좋다.

1. **DWARF 버전**. CodeWarrior PowerPC 구버전은 DWARF 1.x 를 내는 경우가 있고
   pyelftools 는 이를 지원하지 않는다. 먼저 확인:
   ```bash
   readelf --debug-dump=info target.elf | grep -m1 Version
   ```
   버전 2 이상이면 그대로 동작한다.

2. **`DW_AT_data_member_location` 형식**. 컴파일러에 따라 상수 대신
   `DW_OP_plus_uconst` 표현식으로 나온다. 두 경우 모두 처리해 두었다.

3. **최적화 레벨**. `-O2` 이상에서는 전역이 제거되거나 주소가 합쳐질 수 있다.
   DAL A/B 빌드는 보통 최적화가 제한적이라 문제되지 않는다.

4. **`--strip-debug` 여부**. 링커 맵과 별개로 디버그 섹션이 남아 있어야 한다.

5. **섹션 배치**. 값 표시는 `SHF_ALLOC` 섹션의 주소 범위를 그대로 쓴다.
   ROM 이미지와 RAM 실행 주소가 다른 경우(`AT>` 사용)도 검증했다.
   `sh_addr` 가 VMA 이고 섹션 내용이 초기값이므로 그대로 동작한다.

6. **분리된 디버그 정보**. `.gnu_debuglink` 는 자동으로 찾아 읽는다.
   `-gsplit-dwarf` 의 `.dwo` 는 지원하지 않으며, 그 경우 안내 메시지를 표시한다.

## 검증

검증은 대상 바이너리를 **실제로 실행해** 얻은 출력과 파서 결과를
리프 단위로 대조하는 방식이다. 빅엔디안 정답지는 qemu-ppc 로 얻는다.

- 경계 케이스 18개 빌드 구성 (DWARF 2/3/4/5 × LE/BE × -O0~-O3/-Os)
- 타입 조합 생성 (`gen_types.py`): typedef 140여 개 / 전역 160여 개
- 컴파일러 gcc·clang, 아키텍처 x86-64 / PowerPC(BE32) / ARM(LE32) / s390x(BE64)
- 디버그 형식 `-gz` 압축 / 타입유닛 / LTO / DWARF64 / `.gnu_debuglink` / PIE
- **베어메탈 ROM 이미지 (LMA ≠ VMA)** — MPC5674F 배치 그대로 검증

**누적 40만 건 이상 비교, 실패 0건.**

```bash
apt-get install clang qemu-user gcc-powerpc-linux-gnu \
                gcc-arm-linux-gnueabihf gcc-s390x-linux-gnu
cd tests
./run_all_tests.sh       # 경계 케이스
./run_combo_tests.sh     # 타입 조합 대량 검증
./run_matrix_tests.sh    # 컴파일러 / 아키텍처 / 디버그 형식
```

자세한 내용과 이 과정에서 찾은 결함 10건은 `tests/TEST_REPORT.md` 참고.

## 한계

- 덤프 없이 ELF 만 열면 값은 **정적 초기값**이다. 런타임 값을 보려면 TRACE32 API(`t32api.dll` /
  `libt32api.so`)의 `T32_ReadMemory()` 로 `MemoryImage.read()` 를 갈아끼우면
  동일한 트리에 실시간 값을 채울 수 있다.
- `#define` 상수, 물리 단위, 스케일 팩터는 DWARF 에 없다.
- 지역변수 · static 함수 지역변수는 대상 외 (location 이 `DW_OP_fbreg`).
