"""
memdump.py - 메모리 덤프(.csv/.log) 파서

파일 형식은 현장마다 제각각이므로 구분자를 신뢰하지 않는다.
'Address' 가 나오는 헤더 줄을 찾고, 그 다음 줄부터 hex 토큰만 뽑아낸다.

  0x00000000     0xaaaaaaaa  0xaaaaaaaa 0xaaaaaaaa
  ="00000000" ,="aaaa",="aaaa" ,="aaaa",="aaaa" ,"aaaa",="aaaa" ,

위 두 줄은 같은 방식으로 처리된다. 0x 유무, ="..." 포장, 따옴표,
쉼표, 다중 공백, 탭, CRLF, BOM 을 모두 흡수한다.

채널당 값이 2개인 경우(16비트 상/하위로 쪼갠 형태)는 상위+하위 순서로
합쳐 32비트 한 값으로 만든다.
"""

from __future__ import annotations

import re
from bisect import bisect_right
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple


# ---------------------------------------------------------------- 토큰화
_HEX_RE = re.compile(r'^[0-9a-fA-F]+$')
_SPLIT_RE = re.compile(r'[,\s;|]+')
_STRIP_RE = re.compile(r'^[=\'"\s]+|[\'"\s]+$')


def _clean_token(tok: str) -> Optional[str]:
    """="0x00ff" 같은 포장을 벗겨 순수 hex 문자열만 남긴다."""
    t = _STRIP_RE.sub('', tok)
    if not t:
        return None
    if t[:2] in ('0x', '0X'):
        t = t[2:]
    if not t or not _HEX_RE.match(t):
        return None
    return t.lower()


def _tokens(line: str) -> List[str]:
    return [t for t in (_clean_token(p) for p in _SPLIT_RE.split(line)) if t]


# ---------------------------------------------------------------- 헤더
_ADDR_HDR_RE = re.compile(r'(^|[,\s;|"\'=])addr(ess)?([,\s;|"\'=]|$)', re.I)


def _parse_header(line: str) -> List[str]:
    """헤더 줄에서 Address 뒤의 채널 이름을 뽑는다. 빈 칼럼은 버린다."""
    cleaned = line.replace('="', ' ').replace('"', ' ')
    parts = [p.strip(' \t\r\n=,;|') for p in re.split(r'[,;|\t]|\s{2,}', cleaned)]
    parts = [p for p in parts if p]
    if not parts:
        return []
    # Address 칼럼 이후만 채널로 본다
    for i, p in enumerate(parts):
        if re.match(r'addr(ess)?$', p, re.I):
            return parts[i + 1:]
    # 'Address' 가 다른 토큰과 붙어있는 경우: 첫 칼럼을 주소로 간주
    return parts[1:]


# ---------------------------------------------------------------- 결과
@dataclass
class DumpChannel:
    name: str
    endian: str = 'big'
    # 병합된 연속 구간: (시작주소, bytes)
    runs: List[Tuple[int, bytearray]] = field(default_factory=list)
    _starts: List[int] = field(default_factory=list)

    def finalize(self):
        self.runs.sort(key=lambda r: r[0])
        self._starts = [r[0] for r in self.runs]

    def read(self, addr: int, size: int) -> Optional[bytes]:
        if addr is None or not size:
            return None
        i = bisect_right(self._starts, addr) - 1
        if i < 0:
            return None
        start, buf = self.runs[i]
        off = addr - start
        if off + size <= len(buf):
            return bytes(buf[off:off + size])
        return None

    def read_uint(self, addr: int, size: int) -> Optional[int]:
        raw = self.read(addr, size)
        if raw is None:
            return None
        return int.from_bytes(raw, self.endian, signed=False)

    def covers(self, addr: int, size: int) -> bool:
        return self.read(addr, size) is not None

    def touches(self, addr: int, size: int) -> bool:
        """일부라도 걸치는지."""
        if addr is None or not size:
            return False
        end = addr + size
        i = bisect_right(self._starts, end - 1) - 1
        while i >= 0:
            start, buf = self.runs[i]
            if start + len(buf) > addr:
                return True
            if start + len(buf) <= addr:
                return False
            i -= 1
        return False


class MemoryDump:
    """파싱 결과. DwarfReader.mem 자리에 채널별로 끼워 넣는다."""

    def __init__(self, path: str, big_endian: bool,
                 pair_order: str = 'hi_lo', expected_channels: int = 0):
        self.path = path
        self.big_endian = big_endian
        self.pair_order = pair_order
        self.channels: List[DumpChannel] = []
        self.word_bytes = 0
        self.rows = 0
        self.skipped = 0
        self.paired = False
        self.notes: List[str] = []
        self._parse(expected_channels)

    # ---------- 파싱
    def _parse(self, expected_channels: int):
        with open(self.path, 'r', encoding='utf-8-sig', errors='replace') as f:
            lines = f.read().splitlines()

        hdr_idx = None
        for i, line in enumerate(lines):
            if _ADDR_HDR_RE.search(line):
                hdr_idx = i
                break
        if hdr_idx is None:
            raise RuntimeError(
                "'Address' 로 시작하는 헤더 줄을 찾지 못했습니다. "
                "덤프 파일 형식을 확인해 주세요.")

        names = _parse_header(lines[hdr_idx])

        # 데이터 줄 수집
        raw_rows: List[Tuple[int, List[str]]] = []
        for line in lines[hdr_idx + 1:]:
            toks = _tokens(line)
            if len(toks) < 2:
                if line.strip():
                    self.skipped += 1
                continue
            raw_rows.append((int(toks[0], 16), toks[1:]))
        if not raw_rows:
            raise RuntimeError('헤더 다음에서 주소/값 데이터를 찾지 못했습니다.')

        # 값 개수와 폭 결정 (최빈값 기준 - 깨진 줄에 휘둘리지 않게)
        nvals = _mode([len(v) for _, v in raw_rows])
        vlen = _mode([len(t) for _, v in raw_rows for t in v])
        half_bytes = vlen // 2

        nchan = len(names) if names else 0
        if expected_channels:
            nchan = expected_channels

        # 채널당 값이 2개인가 (16비트 상/하위 분할)
        if nchan and nvals == nchan * 2:
            self.paired = True
            self.word_bytes = half_bytes * 2
        elif nchan and nvals == nchan:
            self.word_bytes = half_bytes
        else:
            # 헤더에서 채널 수를 못 얻었으면 값 개수로 추정
            if nvals % 2 == 0 and nvals // 2 in (1, 2, 3, 4):
                nchan, self.paired = nvals // 2, True
                self.word_bytes = half_bytes * 2
            else:
                nchan = nvals
                self.word_bytes = half_bytes
            self.notes.append(
                f'헤더에서 채널 수를 확정하지 못해 값 개수로 추정했습니다 '
                f'(채널 {nchan}개, 쌍 결합 {"예" if self.paired else "아니오"}).')

        if not names or len(names) != nchan:
            names = [f'Ch {chr(65 + i)}' for i in range(nchan)]
        endian = 'big' if self.big_endian else 'little'
        self.channels = [DumpChannel(n, endian) for n in names]
        # 주소 -> 채널별 바이트
        per_chan: List[Dict[int, bytes]] = [{} for _ in range(nchan)]
        for addr, vals in raw_rows:
            if len(vals) != nvals:
                self.skipped += 1
                continue
            for c in range(nchan):
                if self.paired:
                    a, b = vals[2 * c], vals[2 * c + 1]
                    hi, lo = (a, b) if self.pair_order == 'hi_lo' else (b, a)
                    word = (int(hi, 16) << (len(lo) * 4)) | int(lo, 16)
                else:
                    word = int(vals[c], 16)
                try:
                    per_chan[c][addr] = word.to_bytes(self.word_bytes, endian)
                except OverflowError:
                    self.skipped += 1
            self.rows += 1

        for c in range(nchan):
            self._build_runs(self.channels[c], per_chan[c])
            self.channels[c].finalize()

        addrs = sorted(per_chan[0]) if per_chan else []
        if addrs:
            self.addr_min, self.addr_max = addrs[0], addrs[-1] + self.word_bytes
            steps = {addrs[i + 1] - addrs[i] for i in range(min(len(addrs) - 1, 64))}
            if steps and steps != {self.word_bytes}:
                self.notes.append(
                    f'주소 간격이 일정하지 않습니다(워드 {self.word_bytes}바이트). '
                    f'빈 구간은 값 없음으로 표시됩니다.')
        else:
            self.addr_min = self.addr_max = 0

    @staticmethod
    def _build_runs(chan: DumpChannel, table: Dict[int, bytes]):
        """연속된 주소를 하나의 버퍼로 병합한다."""
        cur_start = None
        cur = bytearray()
        for addr in sorted(table):
            data = table[addr]
            if cur_start is not None and addr == cur_start + len(cur):
                cur.extend(data)
            else:
                if cur_start is not None:
                    chan.runs.append((cur_start, cur))
                cur_start, cur = addr, bytearray(data)
        if cur_start is not None:
            chan.runs.append((cur_start, cur))

    # ---------- 조회
    @property
    def channel_names(self) -> List[str]:
        return [c.name for c in self.channels]

    def covers(self, addr: int, size: int, partial: bool = True) -> bool:
        """어느 채널이든 이 영역을 담고 있는가."""
        for c in self.channels:
            if (c.touches(addr, size) if partial else c.covers(addr, size)):
                return True
        return False

    def summary(self) -> str:
        return (f'{self.rows}행  채널 {len(self.channels)}개  '
                f'워드 {self.word_bytes}바이트  '
                f'0x{self.addr_min:08X}~0x{self.addr_max:08X}'
                + (f'  (무시된 줄 {self.skipped})' if self.skipped else ''))


def _mode(values: List[int]) -> int:
    counts: Dict[int, int] = {}
    for v in values:
        counts[v] = counts.get(v, 0) + 1
    return max(counts.items(), key=lambda kv: kv[1])[0]


# ---------------------------------------------------------------- CLI 확인용
if __name__ == '__main__':
    import sys
    if len(sys.argv) < 2:
        print('usage: python memdump.py <dump.csv> [big|little]')
        raise SystemExit(1)
    be = (len(sys.argv) < 3 or sys.argv[2] == 'big')
    d = MemoryDump(sys.argv[1], big_endian=be)
    print(d.summary())
    print('채널:', ', '.join(d.channel_names),
          '| 쌍 결합:', '예' if d.paired else '아니오')
    for n in d.notes:
        print('  [!]', n)
    a = d.addr_min
    for i in range(min(6, d.rows)):
        addr = a + i * d.word_bytes
        vals = [c.read(addr, d.word_bytes) for c in d.channels]
        print(f'  0x{addr:08X}  ' +
              '  '.join(v.hex() if v else '--' for v in vals))
