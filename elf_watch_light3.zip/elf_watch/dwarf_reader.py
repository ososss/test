"""
dwarf_reader.py
ELF/DWARF 에서 전역변수 목록과 타입 트리를 추출한다.

- 전역변수  : DW_TAG_variable 중 location 이 DW_OP_addr/DW_OP_addrx 인 것
- 타입 전개 : struct / union / array(다차원) / enum / pointer / bitfield
- 값 디코딩 : ELF 의 SHF_ALLOC 섹션 이미지를 읽어 초기값 표시 (.bss 는 0)
- 엔디안    : ELF 헤더 기준 (MPC5674F = big endian)

의존성: pyelftools >= 0.29
"""

from __future__ import annotations

import os
import struct
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Tuple

from elftools.elf.elffile import ELFFile
from elftools.elf.constants import SH_FLAGS
from elftools.elf.sections import SymbolTableSection


# ---------------------------------------------------------------- 상수
MAX_ARRAY_CHILDREN = 4096      # 한 노드에 직접 나열할 배열 원소 최대 개수
CHUNK_LIMIT = 512              # 이 개수를 넘으면 [0..255] 형태로 그룹핑
CHUNK_SIZE = 256               # 그룹 하나의 기본 크기
MAX_POINTER_DEPTH = 3          # 포인터 자동 전개 깊이 제한 (자기참조 방어)

_TYPE_QUALIFIERS = {
    'DW_TAG_typedef',
    'DW_TAG_const_type',
    'DW_TAG_volatile_type',
    'DW_TAG_restrict_type',
    'DW_TAG_atomic_type',
    'DW_TAG_packed_type',
}

DW_ATE = {
    0x01: 'address', 0x02: 'boolean', 0x03: 'complex_float', 0x04: 'float',
    0x05: 'signed', 0x06: 'signed_char', 0x07: 'unsigned', 0x08: 'unsigned_char',
    0x0d: 'signed_fixed', 0x0e: 'unsigned_fixed',
}


# ---------------------------------------------------------------- 메모리 이미지
class MemoryImage:
    """ELF 의 로드 가능한 섹션들을 주소 공간에 매핑해 읽기를 제공."""

    def __init__(self, elffile: ELFFile):
        self.big_endian = not elffile.little_endian
        self._blocks: List[Tuple[int, int, Optional[bytes]]] = []   # (addr, size, data)

        for sec in elffile.iter_sections():
            flags = sec['sh_flags']
            if not (flags & SH_FLAGS.SHF_ALLOC):
                continue
            addr = sec['sh_addr']
            size = sec['sh_size']
            if size == 0:
                continue
            if sec['sh_type'] == 'SHT_NOBITS':      # .bss -> 0 으로 채움
                self._blocks.append((addr, size, None))
            else:
                self._blocks.append((addr, size, sec.data()))
        self._blocks.sort(key=lambda b: b[0])

    def read(self, addr: int, size: int) -> Optional[bytes]:
        if addr is None or size is None or size <= 0:
            return None
        for base, blen, data in self._blocks:
            if base <= addr and addr + size <= base + blen:
                if data is None:
                    return b'\x00' * size
                off = addr - base
                return data[off:off + size]
        return None

    def read_uint(self, addr: int, size: int) -> Optional[int]:
        raw = self.read(addr, size)
        if raw is None:
            return None
        return int.from_bytes(raw, 'big' if self.big_endian else 'little', signed=False)


# ---------------------------------------------------------------- 타입 정보
@dataclass
class TypeInfo:
    """DIE 를 해석한 결과. 표시에 필요한 정보만 담는다."""
    die: object = None
    kind: str = 'unknown'          # base/pointer/array/struct/union/enum/void/func/unknown
    name: str = 'void'             # 표시용 타입명 (typedef 이름 우선)
    byte_size: Optional[int] = None
    encoding: Optional[str] = None      # base type 일 때
    dims: List[Optional[int]] = field(default_factory=list)   # 배열 차원
    elem: Optional['TypeInfo'] = None   # 배열 원소 / 포인터 대상
    enum_map: Dict[int, str] = field(default_factory=dict)
    typedef_name: Optional[str] = None
    is_volatile: bool = False
    is_const: bool = False

    @property
    def display_name(self) -> str:
        base = self.name
        if self.is_const:
            base = 'const ' + base
        if self.is_volatile:
            base = 'volatile ' + base
        return base

    @property
    def is_aggregate(self) -> bool:
        return self.kind in ('struct', 'union', 'array')


# ---------------------------------------------------------------- 트리 노드
class VarNode:
    """Watch view 의 한 행. 자식은 요청 시점에 생성(lazy)."""

    __slots__ = ('name', 'type', 'address', 'byte_size', 'bit_size', 'bit_offset',
                 'reader', 'parent', '_children', 'dims_left', 'ptr_depth',
                 'is_placeholder', 'decl_file', 'decl_line', 'row', 'index_offset', 'bit_bytes', 'no_storage', 'const_value')

    def __init__(self, name, tinfo: TypeInfo, address, reader: 'DwarfReader',
                 parent=None, bit_size=None, bit_offset=None, dims_left=None,
                 ptr_depth=0, is_placeholder=False, index_offset=0):
        self.name = name
        self.type = tinfo
        self.address = address
        self.byte_size = tinfo.byte_size if tinfo else None
        self.bit_size = bit_size
        self.bit_offset = bit_offset          # 컨테이너 MSB 기준 비트 위치
        self.reader = reader
        self.parent = parent
        self._children: Optional[List['VarNode']] = None
        self.dims_left = dims_left if dims_left is not None else (
            list(tinfo.dims) if tinfo and tinfo.kind == 'array' else [])
        self.ptr_depth = ptr_depth
        self.is_placeholder = is_placeholder
        self.decl_file = None
        self.decl_line = None
        self.row = 0
        self.index_offset = index_offset
        self.bit_bytes = None
        self.no_storage = False
        self.const_value = None

    # ---------- 표시용 문자열 ----------
    @property
    def type_text(self) -> str:
        if self.is_placeholder:
            return ''
        t = self.type
        if t is None:
            return '?'
        if self.bit_size is not None:
            return f'{t.display_name} : {self.bit_size}'
        if t.kind == 'array' and self.dims_left:
            suffix = ''.join('[%s]' % ('' if d is None else d) for d in self.dims_left)
            return f'{t.elem.display_name if t.elem else "?"}{suffix}'
        return t.display_name

    @property
    def address_text(self) -> str:
        if self.address is None:
            return ''
        s = f'0x{self.address:08X}'
        if self.bit_size is not None and self.bit_offset is not None:
            s += f'.{self.bit_offset}'
        return s

    @property
    def size_text(self) -> str:
        if self.is_placeholder:
            return ''
        if self.bit_size is not None:
            return f'{self.bit_size} bit'
        if self.byte_size is None:
            return ''
        return str(self.byte_size)

    # ---------- 자식 ----------
    def has_children(self) -> bool:
        if self.is_placeholder or self.no_storage or self.address is None:
            return False
        t = self.type
        if t is None:
            return False
        if t.kind == 'array' and self.dims_left:
            return bool(self.dims_left[0])          # None/0 이면 전개 불가
        if t.kind in ('struct', 'union'):
            return bool(self.reader.member_dies(t.die))
        if t.kind == 'pointer':
            if self.ptr_depth >= MAX_POINTER_DEPTH:
                return False
            tgt = t.elem
            if tgt is None or tgt.kind in ('void', 'func'):
                return False
            return bool(self.address is not None and self.value_raw_int())
        return False

    def children(self) -> List['VarNode']:
        if self._children is None:
            self._children = self.reader.build_children(self)
        return self._children

    # ---------- 값 ----------
    def value_raw_int(self) -> Optional[int]:
        if self.address is None or not self.byte_size:
            return None
        return self.reader.mem.read_uint(self.address, self.byte_size)

    def value_text(self, hex_mode: bool = False) -> str:
        return self.reader.format_value(self, hex_mode)


# ---------------------------------------------------------------- 메인 리더
class DwarfReader:

    def __init__(self, path: str):
        self.path = path
        self._fp = open(path, 'rb')
        self._dbg_fp = None
        self._dbg_elf = None
        self.elf = ELFFile(self._fp)
        self.mem = MemoryImage(self.elf)
        self.big_endian = not self.elf.little_endian

        # has_dwarf_info() 는 .eh_frame 만 있어도 True 를 돌려준다.
        # 실제 타입 정보는 .debug_info 에 있으므로 직접 확인한다.
        self.debug_from: Optional[str] = None
        if not (self.elf.get_section_by_name('.debug_info') or
                self.elf.get_section_by_name('.zdebug_info')):
            alt = self._find_debuglink()
            if alt is None:
                raise RuntimeError(
                    '.debug_info 섹션이 없습니다. strip 되었거나 -g 없이 '
                    '빌드된 ELF 입니다.')
            # 분리된 디버그 파일(.gnu_debuglink)에서 디버그 정보를 읽는다.
            self._dbg_fp = open(alt, 'rb')
            self._dbg_elf = ELFFile(self._dbg_fp)
            if not self._dbg_elf.get_section_by_name('.debug_info'):
                raise RuntimeError(
                    f'분리 디버그 파일에도 .debug_info 가 없습니다: {alt}')
            self.debug_from = alt

        self.dwarf = (self._dbg_elf if self.debug_from else self.elf).get_dwarf_info()
        self._type_cache: Dict[tuple, TypeInfo] = {}
        self._member_cache: Dict[tuple, list] = {}
        self.dwarf_versions = set()
        self.optimized_out = 0
        self.warnings: List[str] = []
        self.uses_type_units = False
        self._sig_map: Dict[int, object] = {}
        if self.elf['e_type'] == 'ET_REL':
            self.warnings.append(
                '재배치 가능 오브젝트(.o) 입니다. 주소는 섹션 상대값이므로 '
                '실제 링크 주소와 다릅니다.')
        self.symbols: Dict[int, str] = {}     # addr -> name (포인터 역참조 표시용)

        self._build_signature_map()
        self._load_symbols()
        self.globals: List[VarNode] = self._collect_globals()
        if not self.globals:
            self.warnings.append(
                '전역변수 DIE 가 없습니다. 디버그 정보가 최소한으로만 '
                '들어간 빌드일 수 있습니다.')
        elif all((g.type is None or g.type.kind in ('void', 'unknown'))
                 for g in self.globals):
            self.warnings.append(
                '전역변수는 있으나 타입 정보가 없습니다. -g1 처럼 타입을 뺀 '
                '디버그 레벨로 빌드된 것으로 보입니다. -g2 이상으로 빌드하세요.')
        if self.uses_type_units:
            self.warnings.append('타입 유닛(-fdebug-types-section) 사용 중')

    def _find_debuglink(self) -> Optional[str]:
        """strip 시 분리된 디버그 파일(.gnu_debuglink)을 찾는다."""
        sec = self.elf.get_section_by_name('.gnu_debuglink')
        if sec is None:
            return None
        raw = sec.data()
        name = raw.split(b'\x00', 1)[0].decode('utf-8', 'replace')
        if not name:
            return None
        base = os.path.dirname(os.path.abspath(self.path))
        for cand in (os.path.join(base, name),
                     os.path.join(base, '.debug', name),
                     os.path.join(base, '..', 'lib', 'debug', name)):
            if os.path.isfile(cand):
                return cand
        raise RuntimeError(
            f'디버그 정보가 분리되어 있습니다(.gnu_debuglink -> {name}). '
            f'해당 파일을 ELF 와 같은 디렉터리에 두세요.')

    def close(self):
        for fp in (getattr(self, '_dbg_fp', None), self._fp):
            try:
                if fp:
                    fp.close()
            except Exception:
                pass

    # ---------------------------------------------------------- 유틸
    @staticmethod
    def _attr(die, name):
        a = die.attributes.get(name)
        return a.value if a is not None else None

    # DW_AT_bit_offset 은 음수가 될 수 있다(packed 구조체).
    # GCC 는 DW_FORM_sdata 로 음수를 그대로 내지만, clang 은 부호 없는 form 에
    # 2의 보수를 담아 낸다 (예: DW_FORM_data8 = 0xFFFFFFFFFFFFFFD1 = -47).
    _UNSIGNED_FORM_WIDTH = {
        'DW_FORM_data1': 1, 'DW_FORM_data2': 2,
        'DW_FORM_data4': 4, 'DW_FORM_data8': 8, 'DW_FORM_data16': 16,
    }

    @staticmethod
    def _attr_signed(die, name) -> Optional[int]:
        a = die.attributes.get(name)
        if a is None or not isinstance(a.value, int):
            return None
        v = a.value
        w = DwarfReader._UNSIGNED_FORM_WIDTH.get(a.form)
        if w is not None and v >= (1 << (w * 8 - 1)):
            v -= 1 << (w * 8)
        elif a.form == 'DW_FORM_udata' and v >= (1 << 63):
            v -= 1 << 64
        return v

    @staticmethod
    def _name_of(die) -> Optional[str]:
        v = DwarfReader._attr(die, 'DW_AT_name')
        if v is None:
            return None
        return v.decode('utf-8', 'replace') if isinstance(v, bytes) else str(v)

    def _build_signature_map(self):
        """타입 시그니처 -> 정의 DIE 매핑.

        DWARF4 는 .debug_types 섹션에, DWARF5 는 .debug_info 안의
        DW_UT_type 유닛에 타입 정의가 들어간다. 후자는 pyelftools 의
        get_DIE_by_sig8 이 찾지 못하므로 직접 만든다."""
        try:
            for cu in self.dwarf.iter_CUs():
                hdr = cu.header
                if hdr.get('unit_type') != 'DW_UT_type':
                    continue
                sig = hdr.get('type_signature')
                toff = hdr.get('type_offset')
                if sig is None or toff is None:
                    continue
                try:
                    die = self.dwarf.get_DIE_from_refaddr(cu.cu_offset + toff, cu)
                except Exception:
                    die = None
                if die is not None:
                    self._sig_map[sig] = die
        except Exception:
            pass

    @staticmethod
    def _die_key(die):
        """DIE 캐시 키.

        .debug_types(DWARF4) 의 DIE 오프셋은 .debug_info 와 독립적으로 매겨져
        서로 충돌한다. 오프셋만으로 캐시하면 엉뚱한 타입이 붙는다.
        소속 유닛 객체까지 키에 포함한다. (pyelftools 가 유닛을 캐시하고
        TypeInfo 가 DIE 를 붙들고 있으므로 id 는 안정적이다)"""
        cu = getattr(die, 'cu', None)
        return (id(cu) if cu is not None else 0, die.offset)

    def _die_by_sig(self, sig):
        die = self._sig_map.get(sig)
        if die is not None:
            return die
        try:
            return self.dwarf.get_DIE_by_sig8(sig)
        except Exception:
            return None

    def _type_die(self, die):
        """DW_AT_type 이 가리키는 DIE. DW_FORM_ref_sig8 도 처리한다."""
        if die is None:
            return None
        a = die.attributes.get('DW_AT_type')
        if a is None:
            return None
        if a.form == 'DW_FORM_ref_sig8':
            tgt = self._die_by_sig(a.value)
            if tgt is not None:
                self.uses_type_units = True
            return tgt
        try:
            return die.get_DIE_from_attribute('DW_AT_type')
        except (KeyError, AttributeError):
            return None

    def _load_symbols(self):
        for sec in self.elf.iter_sections():
            if not isinstance(sec, SymbolTableSection):
                continue
            for sym in sec.iter_symbols():
                if sym['st_info']['type'] == 'STT_OBJECT' and sym['st_value']:
                    self.symbols.setdefault(sym['st_value'], sym.name)

    # ---------------------------------------------------------- 메모리 소스 교체
    def set_memory(self, mem):
        """값을 읽어올 메모리 소스를 바꾼다(ELF 초기값 <-> 덤프 채널)."""
        self.mem = mem

    def values_across(self, node, mems, hex_mode=False) -> list:
        """여러 채널에서 같은 노드의 값을 읽어 문자열 목록으로 돌려준다.

        값 포맷은 노드가 들고 있는 reader 를 거치므로 그쪽 메모리를 바꿔야 한다.
        노드가 다른 reader 로 만들어졌을 때 조용히 한 채널 값만 반복 출력되는
        일을 막기 위해 self 와 node.reader 를 함께 전환한다."""
        target = node.reader or self
        saved_self, saved_node = self.mem, target.mem
        try:
            out = []
            for m in mems:
                self.mem = m
                target.mem = m
                out.append(node.value_text(hex_mode))
            return out
        finally:
            self.mem = saved_self
            target.mem = saved_node

    def mismatch_across(self, node, mems) -> bool:
        """채널 간 값이 다른지. 삼중화 채널 비교용.

        비트필드는 추출값으로, 그 외에는 원시 바이트로 비교한다.
        구조체/배열도 바이트 비교로 한 번에 걸린다."""
        if len(mems) < 2 or node.address is None or node.is_placeholder:
            return False
        target = node.reader or self
        saved_self, saved_node = self.mem, target.mem
        try:
            vals = []
            for m in mems:
                self.mem = m
                target.mem = m
                if node.bit_size is not None:
                    vals.append(target._read_bitfield(node))
                elif node.byte_size:
                    vals.append(m.read(node.address, node.byte_size))
                else:
                    return False
            present = [v for v in vals if v is not None]
            return len(present) > 1 and any(v != present[0] for v in present)
        finally:
            self.mem = saved_self
            target.mem = saved_node

    def symbol_at(self, addr: int) -> Optional[str]:
        return self.symbols.get(addr)

    # ---------------------------------------------------------- 타입 해석
    def type_of(self, die) -> TypeInfo:
        """DW_AT_type 을 따라가 TypeInfo 를 만든다."""
        if die is None:
            return TypeInfo(kind='void', name='void', byte_size=0)
        tdie = self._type_die(die)
        if tdie is None:
            return TypeInfo(kind='void', name='void', byte_size=0)
        return self.resolve_type(tdie)

    def _follow_signature(self, tdie):
        """-fdebug-types-section 으로 분리된 타입 정의를 찾아온다.

        선언용 DIE 에는 멤버가 없고 DW_AT_signature 만 들어 있다.
        실제 정의는 .debug_types(DWARF4) 또는 DW_UT_type 유닛(DWARF5) 안에 있다."""
        if tdie is None or 'DW_AT_signature' not in tdie.attributes:
            return tdie
        real = self._die_by_sig(tdie.attributes['DW_AT_signature'].value)
        if real is not None:
            self.uses_type_units = True
            return real
        return tdie

    def resolve_type(self, tdie) -> TypeInfo:
        if tdie is None:
            return TypeInfo(kind='void', name='void', byte_size=0)
        tdie = self._follow_signature(tdie)
        key = self._die_key(tdie)
        if key in self._type_cache:
            return self._type_cache[key]

        info = TypeInfo(die=tdie)
        self._type_cache[key] = info          # 자기참조 방어를 위해 먼저 등록
        self._fill_type(tdie, info)
        return info

    def _fill_type(self, tdie, info: TypeInfo):
        tag = tdie.tag
        name = self._name_of(tdie)
        size = self._attr(tdie, 'DW_AT_byte_size')

        # --- 한정자/typedef: 안쪽을 풀어서 그대로 흡수, 표시명만 갈아끼운다
        if tag in _TYPE_QUALIFIERS:
            inner = self.resolve_type(self._type_die(tdie))
            info.kind = inner.kind
            info.byte_size = inner.byte_size if size is None else size
            info.encoding = inner.encoding
            info.dims = list(inner.dims)
            info.elem = inner.elem
            info.enum_map = inner.enum_map
            info.die = inner.die if tag != 'DW_TAG_typedef' else inner.die
            if tag == 'DW_TAG_typedef':
                info.name = name or inner.name
                info.typedef_name = name
            else:
                info.name = inner.name
                info.is_const = inner.is_const or (tag == 'DW_TAG_const_type')
                info.is_volatile = inner.is_volatile or (tag == 'DW_TAG_volatile_type')
            return

        if tag == 'DW_TAG_base_type':
            enc = self._attr(tdie, 'DW_AT_encoding')
            info.kind = 'base'
            info.name = name or 'base'
            info.byte_size = size
            info.encoding = DW_ATE.get(enc, 'unknown')
            return

        if tag == 'DW_TAG_pointer_type':
            tgt = self.resolve_type(self._type_die(tdie))
            info.kind = 'pointer'
            info.elem = tgt
            info.byte_size = size or self.elf.elfclass // 8
            if tgt.kind == 'array' and tgt.elem is not None:
                suffix = ''.join('[%s]' % ('' if d is None else d) for d in tgt.dims)
                info.name = f'{tgt.elem.display_name} (*){suffix}'   # u32 (*)[3]
            elif tgt.kind == 'func':
                info.name = tgt.name.replace('(', '(*)(', 1) \
                    if '(' in tgt.name else f'{tgt.name} (*)()'
            else:
                info.name = f'{tgt.display_name} *'
            return

        if tag == 'DW_TAG_array_type':
            elem = self.resolve_type(self._type_die(tdie))
            dims = []
            for ch in tdie.iter_children():
                if ch.tag != 'DW_TAG_subrange_type':
                    continue
                cnt = self._attr(ch, 'DW_AT_count')
                if cnt is None:
                    ub = self._attr(ch, 'DW_AT_upper_bound')
                    cnt = (ub + 1) if isinstance(ub, int) else None
                dims.append(cnt if isinstance(cnt, int) else None)
            if not dims:
                dims = [None]
            info.kind = 'array'
            info.elem = elem
            info.dims = dims
            total = elem.byte_size
            if total is not None:
                for d in dims:
                    if d is None:
                        total = None
                        break
                    total *= d
            info.byte_size = size if size is not None else total
            info.name = elem.name + ''.join('[%s]' % ('' if d is None else d) for d in dims)
            return

        if tag in ('DW_TAG_structure_type', 'DW_TAG_union_type', 'DW_TAG_class_type'):
            info.kind = 'union' if tag == 'DW_TAG_union_type' else 'struct'
            kw = 'union' if info.kind == 'union' else 'struct'
            info.name = f'{kw} {name}' if name else f'{kw} <anonymous>'
            info.byte_size = size
            return

        if tag == 'DW_TAG_enumeration_type':
            info.kind = 'enum'
            info.name = f'enum {name}' if name else 'enum <anonymous>'
            info.byte_size = size
            for ch in tdie.iter_children():
                if ch.tag == 'DW_TAG_enumerator':
                    v = self._attr(ch, 'DW_AT_const_value')
                    if isinstance(v, int):
                        info.enum_map[v] = self._name_of(ch) or '?'
            return

        if tag in ('DW_TAG_subroutine_type', 'DW_TAG_subprogram'):
            ret = self.resolve_type(self._type_die(tdie))
            params = []
            try:
                for ch in tdie.iter_children():
                    if ch.tag == 'DW_TAG_formal_parameter':
                        params.append(self.type_of(ch).display_name)
                    elif ch.tag == 'DW_TAG_unspecified_parameters':
                        params.append('...')
            except Exception:
                pass
            info.kind = 'func'
            info.name = f'{ret.display_name} ({", ".join(params) or "void"})'
            info.byte_size = 0
            return

        info.kind = 'unknown'
        info.name = name or tag
        info.byte_size = size

    def member_dies(self, sdie) -> list:
        """구조체/공용체의 멤버 DIE 목록 (캐시)."""
        if sdie is None:
            return []
        key = self._die_key(sdie)
        if key not in self._member_cache:
            try:
                self._member_cache[key] = [c for c in sdie.iter_children()
                                           if c.tag == 'DW_TAG_member']
            except Exception:
                self._member_cache[key] = []
        return self._member_cache[key]

    # ---------------------------------------------------------- 전역변수 수집
    def _decode_location(self, die, cu) -> Optional[int]:
        """DW_AT_location 이 정적 주소인 경우에만 주소를 돌려준다."""
        attr = die.attributes.get('DW_AT_location')
        if attr is None:
            return None
        expr = attr.value
        if not isinstance(expr, (list, bytes, bytearray)):
            return None            # loclist 참조 등 -> 정적 전역 아님
        expr = bytes(expr)
        if not expr:
            return None

        op = expr[0]
        if op == 0x03:                                   # DW_OP_addr
            addr_size = cu['address_size']
            raw = expr[1:1 + addr_size]
            if len(raw) < addr_size:
                return None
            return int.from_bytes(raw, 'big' if self.big_endian else 'little')
        if op == 0xa1:                                   # DW_OP_addrx (DWARF5)
            idx, _ = _uleb128(expr, 1)
            try:
                return self.dwarf.get_addr(cu, idx)
            except Exception:
                return None
        return None

    def _origin_of(self, die):
        """DW_AT_specification / DW_AT_abstract_origin 을 따라가 원본 DIE 를 찾는다.

        LTO 빌드에서는 위치 정보를 가진 DIE 에 이름과 타입이 없고,
        DW_AT_abstract_origin 이 가리키는 DIE 에 들어 있다."""
        cur = die
        seen = {die.offset}
        for _ in range(8):
            nxt = None
            for attr in ('DW_AT_specification', 'DW_AT_abstract_origin'):
                if attr in cur.attributes:
                    try:
                        cand = cur.get_DIE_from_attribute(attr)
                    except Exception:
                        cand = None
                    if cand is not None and cand.offset not in seen:
                        seen.add(cand.offset)
                        nxt = cand
                        break
            if nxt is None:
                return cur
            cur = nxt
        return cur

    def _collect_globals(self) -> List[VarNode]:
        out: List[VarNode] = []
        seen = set()

        for cu in self.dwarf.iter_CUs():
            self.dwarf_versions.add(cu['version'])
            top = cu.get_top_DIE()
            if ('DW_AT_GNU_dwo_name' in top.attributes or
                    'DW_AT_dwo_name' in top.attributes):
                a = (top.attributes.get('DW_AT_GNU_dwo_name') or
                     top.attributes.get('DW_AT_dwo_name'))
                nm = a.value.decode('utf-8', 'replace') \
                    if isinstance(a.value, bytes) else str(a.value)
                msg = (f'분리 디버그 정보(-gsplit-dwarf) 사용: {nm}. '
                       f'.dwo 파일은 지원하지 않습니다. -gsplit-dwarf 없이 '
                       f'빌드하거나 dwp 로 합쳐 주세요.')
                if msg not in self.warnings:
                    self.warnings.append(msg)
            for die in top.iter_children():
                if die.tag != 'DW_TAG_variable':
                    continue
                if die.attributes.get('DW_AT_declaration') is not None:
                    continue
                origin = self._origin_of(die)
                name = self._name_of(die) or self._name_of(origin)
                if not name:
                    continue
                type_src = die if 'DW_AT_type' in die.attributes else origin
                addr = self._decode_location(die, cu)
                cval = self._attr(die, 'DW_AT_const_value')
                if addr is None and cval is None:
                    # 위치도 상수값도 없다 = 최적화로 제거됨.
                    # 빌드에 없다는 사실 자체가 정보이므로 목록에는 남긴다.
                    key = (name, 'origin', origin.offset)
                    if key in seen:
                        continue
                    seen.add(key)
                    n = VarNode(name, self.type_of(type_src), None, self)
                    n.no_storage = True
                    n.decl_line = self._attr(die, 'DW_AT_decl_line')
                    out.append(n)
                    self.optimized_out += 1
                    continue
                key = (name, 'origin', origin.offset)
                seen.add(key)
                if (name, addr) in seen:
                    continue
                seen.add((name, addr))

                tinfo = self.type_of(type_src)
                node = VarNode(name, tinfo, addr, self)
                node.decl_line = self._attr(die, 'DW_AT_decl_line')
                if addr is None:
                    node.const_value = cval
                out.append(node)

        out.sort(key=lambda n: n.name)
        for r, n in enumerate(out):
            n.row = r
        return out

    # ---------------------------------------------------------- 자식 생성
    def build_children(self, node: VarNode) -> List[VarNode]:
        t = node.type
        if t is None or node.is_placeholder:
            return []

        # ---- 배열: 바깥 차원 하나만 벗겨서 자식 생성 (다차원 지원)
        if t.kind == 'array' and node.dims_left:
            dims = node.dims_left
            count = dims[0]
            rest = dims[1:]
            elem = t.elem
            if elem is None or elem.byte_size is None or not count:
                return []
            stride = elem.byte_size
            for d in rest:
                if d is None:
                    return []
                stride *= d

            # 원소가 아주 많으면 [0..255] 형태로 묶어 트리를 얕게 유지
            if count > CHUNK_LIMIT:
                chunk = CHUNK_SIZE
                while count // chunk > CHUNK_SIZE:
                    chunk *= 16
                kids = []
                for start in range(0, count, chunk):
                    n = min(chunk, count - start)
                    last = start + n - 1
                    sub = TypeInfo(die=t.die, kind='array', name=t.name,
                                   byte_size=stride * n, elem=elem,
                                   dims=[n] + rest)
                    addr = None if node.address is None else node.address + start * stride
                    kids.append(VarNode(f'[{node.index_offset + start}..'
                                        f'{node.index_offset + last}]',
                                        sub, addr, self, parent=node,
                                        dims_left=[n] + rest,
                                        ptr_depth=node.ptr_depth,
                                        index_offset=node.index_offset + start))
                for r, k in enumerate(kids):
                    k.row = r
                return kids

            kids = []
            shown = min(count, MAX_ARRAY_CHILDREN)
            for i in range(shown):
                addr = None if node.address is None else node.address + i * stride
                label = f'[{node.index_offset + i}]'
                if rest:
                    sub = TypeInfo(die=t.die, kind='array', name=t.name,
                                   byte_size=stride, elem=elem, dims=list(rest))
                    kid = VarNode(label, sub, addr, self, parent=node,
                                  dims_left=list(rest), ptr_depth=node.ptr_depth)
                else:
                    kid = VarNode(label, elem, addr, self, parent=node,
                                  ptr_depth=node.ptr_depth)
                kids.append(kid)
            if count > shown:
                ph = VarNode(f'... ({count - shown} more)', None, None, self,
                             parent=node, is_placeholder=True)
                kids.append(ph)
            for r, k in enumerate(kids):
                k.row = r
            return kids

        # ---- 구조체 / 공용체
        if t.kind in ('struct', 'union'):
            kids = []
            for m in self.member_dies(t.die):
                mname = self._name_of(m)
                mtype = self.type_of(m)
                moff = self._member_offset(m)
                maddr = None
                if node.address is not None and moff is not None:
                    maddr = node.address + moff

                bit_size = self._attr(m, 'DW_AT_bit_size')
                bit_off = None
                bit_bytes = None
                if bit_size is not None:
                    bit_off, maddr, bit_bytes = self._bitfield_position(
                        m, node.address, moff, mtype)

                if mname is None:
                    inner = mtype
                    mname = f'<anonymous {inner.kind}>'
                kid = VarNode(mname, mtype, maddr, self, parent=node,
                              bit_size=bit_size, bit_offset=bit_off,
                              ptr_depth=node.ptr_depth)
                kid.bit_bytes = bit_bytes
                kids.append(kid)
            for r, k in enumerate(kids):
                k.row = r
            return kids

        # ---- 포인터: 대상 1개 전개
        if t.kind == 'pointer':
            tgt = t.elem
            if tgt is None or tgt.kind in ('void', 'func'):
                return []
            if node.ptr_depth >= MAX_POINTER_DEPTH:
                return []
            ptr_val = node.value_raw_int()
            if not ptr_val:
                return []
            kid = VarNode(f'*{node.name}', tgt, ptr_val, self, parent=node,
                          ptr_depth=node.ptr_depth + 1)
            return [kid]

        return []

    def _member_offset(self, mdie) -> Optional[int]:
        v = self._attr(mdie, 'DW_AT_data_member_location')
        if v is None:
            return 0            # union 멤버 / data_bit_offset 사용 시 오프셋 속성 없음
        if isinstance(v, int):
            return v
        if isinstance(v, (list, bytes, bytearray)):
            b = bytes(v)
            if b and b[0] == 0x23:                 # DW_OP_plus_uconst
                val, _ = _uleb128(b, 1)
                return val
        return None

    def _bitfield_position(self, mdie, parent_addr, moff, mtype):
        """
        비트필드에서 (bit_offset, 시작주소, 읽을 바이트 수) 를 계산.

        구조체 시작을 원점으로 하는 '비트 스트림 위치' start_bit 로 통일한 뒤
        바이트 경계로 잘라 필요한 만큼만 읽는다. 컨테이너 크기로 정렬하면
        packed 구조체나 컨테이너를 넘어가는 필드에서 깨진다.

          DWARF 4/5 : DW_AT_data_bit_offset 이 곧 start_bit
          DWARF 2/3 : DW_AT_bit_offset 은 컨테이너 MSB 기준이므로
                      little endian 은 LSB 기준으로 환산
                      (pack(1) 등에서 GCC 는 음수 bit_offset 을 내기도 한다)

        start_bit 의 비트 번호 방향은 엔디안에 따라 다르다.
          big endian    : 바이트의 MSB 가 0
          little endian : 바이트의 LSB 가 0
        """
        bit_size = self._attr(mdie, 'DW_AT_bit_size') or 0
        dbo = self._attr(mdie, 'DW_AT_data_bit_offset')

        if dbo is not None:
            start_bit = dbo
        else:
            bo = self._attr_signed(mdie, 'DW_AT_bit_offset')
            if bo is None:
                addr = None if parent_addr is None else parent_addr + (moff or 0)
                return None, addr, (mtype.byte_size or 4)
            container = self._attr(mdie, 'DW_AT_byte_size') or (mtype.byte_size or 4)
            base_bit = (moff or 0) * 8
            if self.big_endian:
                start_bit = base_bit + bo
            else:
                start_bit = base_bit + (container * 8 - bo - bit_size)

        byte_start = start_bit // 8          # 음수도 floor 로 올바르게 처리
        bit_in = start_bit - byte_start * 8  # 항상 0..7
        nbytes = (bit_in + bit_size + 7) // 8
        addr = None if parent_addr is None else parent_addr + byte_start
        return bit_in, addr, nbytes

    # ---------------------------------------------------------- 값 포맷
    def _read_bitfield(self, node: VarNode) -> Optional[int]:
        nbytes = node.bit_bytes or (node.type.byte_size if node.type else 4) or 4
        if node.bit_offset is None or not node.bit_size:
            return None
        raw = self.mem.read(node.address, nbytes)
        if raw is None:
            return None
        unit = int.from_bytes(raw, 'big' if self.big_endian else 'little')
        if self.big_endian:
            shift = nbytes * 8 - node.bit_offset - node.bit_size
        else:
            shift = node.bit_offset
        if shift < 0:
            return None
        return (unit >> shift) & ((1 << node.bit_size) - 1)

    def format_value(self, node: VarNode, hex_mode: bool = False) -> str:
        if node.is_placeholder or node.type is None:
            return ''
        if node.no_storage:
            return '<optimized out>'
        if node.address is None and node.const_value is not None:
            v = node.const_value
            return f'{v}  <constant>' if isinstance(v, int) else '<constant>'
        t = node.type

        # --- 비트필드
        if node.bit_size is not None:
            v = self._read_bitfield(node)
            if v is None:
                return '<no data>'
            if (t.encoding or '').startswith('signed') and \
                    (v >> (node.bit_size - 1)) & 1:
                v -= (1 << node.bit_size)          # 부호 확장
            if t.kind == 'enum' and v in t.enum_map:
                return f'{t.enum_map[v]} ({v})'
            return f'0x{v:X}' if hex_mode else str(v)

        if node.address is None:
            return ''

        # --- 배열
        if t.kind == 'array':
            if self._is_char_array(node):
                return self._read_string(node)
            n = node.dims_left[0] if node.dims_left else None
            if n is None:
                return '[]'                        # flexible array member
            # 스칼라 1차원 소형 배열은 TRACE32 처럼 값을 미리보기로 나열
            if (len(node.dims_left) == 1 and isinstance(n, int) and n <= 8
                    and t.elem and t.elem.kind in ('base', 'enum')):
                try:
                    vals = [c.value_text(hex_mode) for c in node.children()[:n]]
                    return f'({n}) ' + '{' + ', '.join(vals) + '}'
                except Exception:
                    pass
            return f'({n})'

        if t.kind in ('struct', 'union'):
            return '{...}'

        if t.kind == 'func':
            return ''

        size = t.byte_size
        if not size:
            return ''
        raw = self.mem.read(node.address, size)
        if raw is None:
            return '<no data>'
        endian = 'big' if self.big_endian else 'little'

        if t.kind == 'pointer':
            v = int.from_bytes(raw, endian)
            s = f'0x{v:08X}'
            sym = self.symbol_at(v)
            if sym:
                s += f' <{sym}>'
            return s

        if t.kind == 'enum':
            signed = any(k < 0 for k in t.enum_map)
            v = int.from_bytes(raw, endian, signed=signed)
            nm = t.enum_map.get(v)
            return f'{nm} ({v})' if nm else str(v)

        enc = t.encoding or 'unsigned'
        if enc == 'float':
            fmt = '>' if self.big_endian else '<'
            try:
                if size == 4:
                    return f'{struct.unpack(fmt + "f", raw)[0]:.6g}'
                if size == 8:
                    return f'{struct.unpack(fmt + "d", raw)[0]:.10g}'
            except struct.error:
                return '<bad float>'
            return '<float?>'

        if enc == 'boolean':
            return 'TRUE' if int.from_bytes(raw, endian) else 'FALSE'

        signed = enc in ('signed', 'signed_char')
        v = int.from_bytes(raw, endian, signed=signed)

        if enc in ('signed_char', 'unsigned_char') and size == 1:
            ch = chr(v & 0xFF)
            printable = ch if 32 <= (v & 0xFF) < 127 else '.'
            return f"0x{v & 0xFF:02X} '{printable}'" if hex_mode else f"{v} '{printable}'"

        if hex_mode:
            return f'0x{v & ((1 << (size * 8)) - 1):0{size * 2}X}'
        return str(v)

    def _is_char_array(self, node: VarNode) -> bool:
        t = node.type
        if t.kind != 'array' or len(node.dims_left) != 1 or t.elem is None:
            return False
        return t.elem.byte_size == 1 and (t.elem.encoding or '').endswith('char')

    def _read_string(self, node: VarNode, limit: int = 64) -> str:
        n = node.dims_left[0] or 0
        raw = self.mem.read(node.address, min(n, limit))
        if raw is None:
            return '<no data>'
        s = raw.split(b'\x00', 1)[0]
        txt = ''.join(chr(c) if 32 <= c < 127 else '.' for c in s)
        return f'"{txt}"'

    # ---------------------------------------------------------- 정보 요약
    def summary(self) -> dict:
        return {
            'file': self.path,
            'machine': self.elf['e_machine'],
            'class': f'ELF{self.elf.elfclass}',
            'endian': 'big' if self.big_endian else 'little',
            'dwarf': ', '.join(str(v) for v in sorted(self.dwarf_versions)),
            'globals': len(self.globals),
            'optimized_out': self.optimized_out,
            'warnings': self.warnings,
            'debug_from': self.debug_from,
        }


# ---------------------------------------------------------------- ULEB128
def _uleb128(buf: bytes, pos: int) -> Tuple[int, int]:
    result = 0
    shift = 0
    while pos < len(buf):
        b = buf[pos]
        pos += 1
        result |= (b & 0x7F) << shift
        if not (b & 0x80):
            break
        shift += 7
    return result, pos


# ---------------------------------------------------------------- CLI 확인용
def _dump(node: VarNode, depth: int, maxdepth: int, hex_mode=False):
    pad = '  ' * depth
    print(f'{pad}{node.name:<24} {node.value_text(hex_mode):<26} '
          f'{node.type_text:<24} {node.address_text:<12} {node.size_text}')
    if depth < maxdepth and node.has_children():
        for c in node.children()[:12]:
            _dump(c, depth + 1, maxdepth, hex_mode)


if __name__ == '__main__':
    import sys
    if len(sys.argv) < 2:
        print('usage: python dwarf_reader.py <file.elf> [depth]')
        raise SystemExit(1)
    rd = DwarfReader(sys.argv[1])
    depth = int(sys.argv[2]) if len(sys.argv) > 2 else 2
    for k, v in rd.summary().items():
        print(f'{k:>10}: {v}')
    print('-' * 100)
    for g in rd.globals:
        _dump(g, 0, depth)
