# 폐쇄망 오프라인 설치 안내

대상: **Windows x86-64 (Intel PC) / Python 3.12.2**

`wheels/` 안의 4개 휠만으로 인터넷 연결 없이 설치가 끝난다.

## 1. 반입 전 무결성 확인 (인터넷망에서)

```
certutil -hashfile wheels\pyelftools-0.33-py3-none-any.whl SHA256
```

`SHA256SUMS.txt` 의 값과 대조. 전체 목록:

| 파일 | 크기 | 용도 |
|---|---|---|
| `pyelftools-0.33-py3-none-any.whl` | 197 KB | ELF/DWARF 파서 (순수 파이썬, OS 무관) |
| `pyqt6-6.11.0-cp310-abi3-win_amd64.whl` | 6.6 MB | PyQt6 바인딩 |
| `pyqt6_qt6-6.11.2-py3-none-win_amd64.whl` | 75 MB | Qt6 런타임 DLL |
| `pyqt6_sip-13.12.0-cp312-cp312-win_amd64.whl` | 53 KB | SIP 런타임 |

## 2. 폐쇄망 PC에서 설치

```
install_offline.bat
```

또는 수동으로:

```
python -m pip install --no-index --find-links=wheels pyelftools PyQt6
```

`--no-index` 가 핵심이다. 이게 없으면 pip 가 PyPI 에 접속을 시도하다 타임아웃 난다.

가상환경을 쓰는 경우:

```
python -m venv .venv
.venv\Scripts\activate
python -m pip install --no-index --find-links=wheels pyelftools PyQt6
```

## 3. 설치 확인

```
python -c "import elftools, PyQt6.QtWidgets; print('ok')"
python t32_watch.py sample\fcs_sample_dwarf4.elf
```

## 휠 호환성 메모

- `pyelftools` 는 `py3-none-any` 태그다. **OS·CPU·파이썬 버전 무관**하게
  3.10 이상이면 그대로 쓸 수 있다. 리눅스 서버에도 같은 파일을 쓰면 된다.
- `pyqt6` 는 `cp310-abi3` 태그로 Python 3.10 이상에서 공통 동작한다.
- `pyqt6_sip` 만 `cp312` 전용이다. 폐쇄망 PC의 파이썬이 3.12가 아니면
  이 파일만 해당 버전으로 다시 받아야 한다.

파이썬 버전 확인:

```
python -c "import sys, platform; print(sys.version, platform.machine())"
```

`AMD64` 로 나오면 이 번들이 맞다. `ARM64` 면 다른 휠이 필요하다.

## 다른 환경용 휠을 다시 받을 때 (인터넷망)

```
pip download pyelftools PyQt6 --only-binary=:all: ^
    --python-version 3.12 --platform win_amd64 --implementation cp --abi cp312 ^
    -d wheels
```

리눅스 x86-64 용:

```
pip download pyelftools PyQt6 --only-binary=:all: \
    --python-version 3.12 --platform manylinux_2_28_x86_64 \
    --implementation cp --abi cp312 -d wheels_linux
```

## pyelftools 만 필요한 경우

GUI 없이 `dwarf_reader.py` 만 콘솔에서 쓸 거라면 pyelftools 하나면 충분하다.
PyQt6 75 MB 를 반입 심사에 올릴 필요가 없다.

```
python -m pip install --no-index --find-links=wheels pyelftools
python dwarf_reader.py target.elf 3
```
