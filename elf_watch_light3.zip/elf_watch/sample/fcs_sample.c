/*
 * fcs_sample.c - DWARF 파서 검증용 샘플
 * 스칼라 / 배열(다차원) / 열거형 / 구조체 중첩 / 공용체 / 익명 union
 * / 비트필드(빅엔디안) / 포인터(자기참조) / typedef / const / volatile
 */

#include <stdint.h>

/* ---------- 기본 typedef ---------- */
typedef uint8_t   u8;
typedef uint16_t  u16;
typedef uint32_t  u32;
typedef int32_t   s32;
typedef float     f32;
typedef double    f64;

/* ---------- 열거형 ---------- */
typedef enum {
    FCS_MODE_INIT    = 0,
    FCS_MODE_STANDBY = 1,
    FCS_MODE_ENGAGED = 2,
    FCS_MODE_DEGRADED= 3,
    FCS_MODE_FAIL    = 0xFF
} FcsMode_t;

/* ---------- 비트필드 (빅엔디안 검증용) ---------- */
typedef struct {
    u32 valid        : 1;
    u32 stale        : 1;
    u32 channel_id   : 3;   /* 0..7   */
    u32 subaddress   : 5;   /* 1553 SA */
    u32 word_count   : 6;
    u32 parity_err   : 1;
    u32 reserved     : 15;
} BusStatusBits_t;

typedef struct {
    u8  bc_ready : 1;
    u8  rt_ready : 1;
    u8  mode     : 2;
    u8  spare    : 4;
} SmallBits_t;

/* ---------- 중첩 구조체 ---------- */
typedef struct {
    f32 x;
    f32 y;
    f32 z;
} Vec3_t;

typedef struct {
    Vec3_t  rate;          /* p, q, r        */
    Vec3_t  accel;         /* nx, ny, nz     */
    f64     timestamp;
    u32     seq;
} ImuSample_t;

/* ---------- 공용체 + 익명 union ---------- */
typedef union {
    u32 raw;
    f32 fval;
    u8  bytes[4];
} Word32_t;

typedef struct {
    u16       label;
    u16       ssm;
    union {                 /* 익명 union */
        u32   bnr;
        f32   eng;
        u8    disc[4];
    };
    Word32_t  payload;
} ArincWord_t;

/* ---------- 자기참조 포인터 ---------- */
typedef struct FaultNode {
    u32                 code;
    u32                 count;
    struct FaultNode   *next;
} FaultNode_t;

/* ---------- 큰 복합 구조체 ---------- */
typedef struct {
    FcsMode_t        mode;
    BusStatusBits_t  bus_status;
    SmallBits_t      flags;
    ImuSample_t      imu[3];              /* 3중 IMU */
    f32              gains[4][6];         /* 2차원   */
    s32              cmd_history[2][3][4];/* 3차원   */
    char             build_id[24];
    ArincWord_t      arinc_in[2];
    FaultNode_t     *fault_head;
} FcsState_t;

/* ================= 전역 변수 ================= */

volatile FcsState_t   g_fcs_state;

u32                   g_cycle_count      = 0;
u16                   g_frame_counter    = 1000;
u8                    g_channel          = 2;
s32                   g_trim_offset      = -125;
f32                   g_dt_ms            = 5.0f;
f64                   g_mission_time_s   = 1234.5678;
char                  g_sw_version[16]   = "FCS-DAL-A 1.4.2";

FcsMode_t             g_current_mode     = FCS_MODE_ENGAGED;

Vec3_t                g_body_rate        = { 0.125f, -0.5f, 3.25f };
Vec3_t                g_rate_limit[2]    = { {10.0f, 10.0f, 5.0f},
                                             {20.0f, 20.0f, 9.0f} };

BusStatusBits_t       g_bus1_status      = { 1, 0, 5, 17, 32, 0, 0 };
SmallBits_t           g_small_flags      = { 1, 1, 2, 0 };

Word32_t              g_scratch          = { .raw = 0x3F800000u };
ArincWord_t           g_arinc_sample     = { 0203, 3, { .bnr = 0xDEADBEEFu },
                                             { .raw = 0x12345678u } };

u32                   g_mil1553_rx[8]    = { 0x1111, 0x2222, 0x3333, 0x4444,
                                             0x5555, 0x6666, 0x7777, 0x8888 };
f32                   g_gain_table[3][4] = { {1.0f, 2.0f, 3.0f, 4.0f},
                                             {0.5f, 0.25f, 0.125f, 0.0625f},
                                             {-1.0f, -2.0f, -3.0f, -4.0f} };

const u32             gc_crc_seed        = 0xFFFFFFFFu;
static u32            gs_internal_tick   = 7;      /* static 전역 */

FaultNode_t           g_fault_pool[3];
FaultNode_t          *g_fault_head       = &g_fault_pool[0];

u8                    g_big_buffer[512];

/* ================= 코드 ================= */
static void step(void)
{
    gs_internal_tick++;
    g_cycle_count++;
    g_frame_counter = (u16)(g_frame_counter + 1u);
}

void _start(void)
{
    g_fault_pool[0].code = 0x1001;
    g_fault_pool[0].next = &g_fault_pool[1];
    for (;;) {
        step();
    }
}
