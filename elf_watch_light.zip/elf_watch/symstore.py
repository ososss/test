"""
symstore.py - ELF 심볼 정보를 뽑아 암호화해 보관하고, ELF 없이 다시 여는 모듈

ELF 원본을 들고 다니지 않기 위한 수단이다.
전역 목록과 타입 그래프(멤버 오프셋, 비트필드 위치, 배열 차원, enum)를
직렬화해 암호화하고, 나중에 복호화해 같은 트리를 재구성한다.

암호는 파이썬 표준 라이브러리만 사용한다(추가 반입 없음).
  ChaCha20 (순수 파이썬) + HMAC-SHA256 (hmac/hashlib)
  키는 32바이트 키 파일에 보관한다.

주의: 인증된 암호 모듈이 아니다. 보관 중 기밀성에는 충분하지만,
기관의 비밀자료 취급 규정이 있다면 그쪽이 우선한다.
"""

from __future__ import annotations

import base64
import hashlib
import json
import os
import secrets
import sys
import zlib
from typing import List, Optional

import crypto
from dwarf_reader import DwarfReader, Member, TypeInfo, VarNode

STORE_EXT = '.ews'

# ------------------------------------------------------------------ 내장 키
# 키 파일을 따로 두지 않아도 동작하도록 도구 안에 기본 키를 둔다.
#
# 이 키는 비밀이 아니다. 도구 배포본을 가진 사람은 누구나 이 값을 읽을 수 있다.
# 따라서 내장 키로 암호화한 저장본은 '.ews 파일만 유출된 경우'에는 보호되지만,
# 도구까지 함께 나가면 보호되지 않는다.
# => 도구 배포본을 키와 같은 등급으로 관리할 것.
#
# 더 조이려면 키 파일을 두면 된다. 키 파일이 있으면 그쪽이 우선한다.
#   python symstore.py genkey team.key
_EMBEDDED_KEY_B64 = 'IhqpWc6HYwHzRlFUX+rk0p39i3nZacKIVfqi2tGsr4w='


def embedded_key() -> bytes:
    return base64.b64decode(_EMBEDDED_KEY_B64)


def resolve_key(key_path: Optional[str] = None) -> bytes:
    """키 파일이 지정되면 그것을, 아니면 내장 키를 쓴다."""
    if key_path:
        return load_key_file(key_path)
    return embedded_key()


def generate_key_file(path: str) -> str:
    """32바이트 키를 새로 만들어 파일로 저장한다."""
    key = secrets.token_bytes(32)
    with open(path, 'w', encoding='utf-8') as f:
        f.write('# ELF Watch symbol store key - 이 파일을 잃으면 복호화할 수 없습니다\n')
        f.write(base64.b64encode(key).decode() + '\n')
    try:
        os.chmod(path, 0o600)
    except Exception:
        pass
    return path


def load_key_file(path: str) -> bytes:
    with open(path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            key = base64.b64decode(line)
            if len(key) != 32:
                raise RuntimeError(f'키 길이가 32바이트가 아닙니다 ({len(key)}).')
            return key
    raise RuntimeError('키 파일에서 키를 찾지 못했습니다.')


def encrypt(payload: bytes, key: bytes, provider: Optional[str] = None) -> bytes:
    return crypto.seal(payload, key, provider)


def decrypt(blob: bytes, key: bytes) -> bytes:
    return crypto.unseal(blob, key)


# ==================================================================== 직렬화
class _Serializer:
    def __init__(self, rd: DwarfReader):
        self.rd = rd
        self.types: List[dict] = []
        self.ids: Dict[int, int] = {}

    def type_id(self, t: Optional[TypeInfo]) -> Optional[int]:
        if t is None:
            return None
        key = id(t)
        if key in self.ids:
            return self.ids[key]
        idx = len(self.types)
        self.ids[key] = idx
        self.types.append({})              # 자기참조 대비 자리 확보
        rec = {
            'k': t.kind, 'n': t.name, 'sz': t.byte_size,
            'e': t.encoding, 'd': t.dims or None,
            'td': t.typedef_name,
            'c': 1 if t.is_const else 0, 'v': 1 if t.is_volatile else 0,
        }
        if t.elem is not None:
            rec['el'] = self.type_id(t.elem)
        if t.enum_map:
            rec['em'] = [[k, v] for k, v in t.enum_map.items()]
        if t.kind in ('struct', 'union'):
            rec['m'] = [{
                'n': m.name, 't': self.type_id(m.type), 'o': m.offset,
                'bs': m.bit_size, 'bo': m.bit_offset, 'bb': m.bit_bytes,
            } for m in self.rd.members_of(t)]
        self.types[idx] = rec
        return idx


def _section_blobs(rd: DwarfReader) -> List[dict]:
    """ELF 초기값을 함께 담아 덤프 없이도 값이 보이게 한다."""
    out = []
    for base, size, data in rd.mem._blocks:
        if data is None:
            out.append({'a': base, 'z': size, 'b': None})     # .bss
        else:
            out.append({'a': base, 'z': size,
                        'b': base64.b64encode(data).decode()})
    return out


def export_store(elf_path: str, out_path: str, key: Optional[bytes] = None,
                 include_values: bool = True,
                 provider: Optional[str] = None) -> dict:
    """ELF -> 암호화된 심볼 저장 파일."""
    if key is None:
        key = embedded_key()
    rd = DwarfReader(elf_path)
    ser = _Serializer(rd)

    globs = []
    for g in rd.globals:
        globs.append({
            'n': g.name, 'a': g.address, 't': ser.type_id(g.type),
            'ns': 1 if g.no_storage else 0, 'ln': g.decl_line,
        })

    with open(elf_path, 'rb') as f:
        elf_sha = hashlib.sha256(f.read()).hexdigest()

    model = {
        'ver': 1,
        'src': os.path.basename(elf_path),
        'sha256': elf_sha,
        'machine': rd.elf['e_machine'],
        'elfclass': rd.elf.elfclass,
        'big_endian': rd.big_endian,
        'dwarf': sorted(rd.dwarf_versions),
        'types': ser.types,
        'globals': globs,
        'symbols': [[a, n] for a, n in rd.symbols.items()],
        'sections': _section_blobs(rd) if include_values else [],
    }
    raw = json.dumps(model, separators=(',', ':')).encode('utf-8')
    payload = zlib.compress(raw, 9)
    blob = crypto.seal(payload, key, provider)
    pname, kid, _ = crypto.peek(blob)
    with open(out_path, 'wb') as f:
        f.write(blob)
    rd.close()
    return {
        'globals': len(globs), 'types': len(ser.types),
        'json': len(raw), 'compressed': len(payload), 'file': len(blob),
        'sha256': elf_sha, 'src': model['src'],
        'provider': pname, 'key_id': kid,
    }


# ==================================================================== 복원
class _StoreMemory:
    """저장된 섹션 이미지. MemoryImage 와 같은 인터페이스."""

    def __init__(self, sections: List[dict], big_endian: bool):
        self.big_endian = big_endian
        self._blocks = []
        for s in sections:
            data = base64.b64decode(s['b']) if s['b'] else None
            self._blocks.append((s['a'], s['z'], data))
        self._blocks.sort(key=lambda b: b[0])

    def read(self, addr, size):
        if addr is None or not size:
            return None
        for base, blen, data in self._blocks:
            if base <= addr and addr + size <= base + blen:
                if data is None:
                    return b'\x00' * size
                off = addr - base
                return data[off:off + size]
        return None

    def read_uint(self, addr, size):
        raw = self.read(addr, size)
        if raw is None:
            return None
        return int.from_bytes(raw, 'big' if self.big_endian else 'little')


class StoreSource(DwarfReader):
    """ELF 없이 저장본에서 트리를 재구성한다.

    값 포맷·비트필드 추출·자식 생성은 DwarfReader 쪽 구현을 그대로 쓴다.
    DWARF 파싱 부분만 저장된 모델로 대체된다.
    """

    def __init__(self, store_path: str, key: Optional[bytes] = None):
        if key is None:
            key = embedded_key()
        with open(store_path, 'rb') as f:
            blob = f.read()
        self.provider_name, self.key_fingerprint, _ = crypto.peek(blob)
        model = json.loads(zlib.decompress(crypto.unseal(blob, key)))
        if model.get('ver') != 1:
            raise RuntimeError(f"지원하지 않는 저장본 버전입니다: {model.get('ver')}")

        self.path = store_path
        self.store_meta = model
        self.big_endian = bool(model['big_endian'])
        self.mem = _StoreMemory(model.get('sections', []), self.big_endian)
        self.symbols = {a: n for a, n in model.get('symbols', [])}
        self.warnings: List[str] = []
        self.address_base = None
        self.address_base_node = None
        self._catalog = None
        self.uses_type_units = False
        self.optimized_out = 0
        self.dwarf_versions = set(model.get('dwarf', []))
        self.debug_from = None
        self._fp = None
        self._dbg_fp = None

        self._types = self._rebuild_types(model['types'])
        self.globals = self._rebuild_globals(model['globals'])
        if not model.get('sections'):
            self.warnings.append('초기값 없이 저장된 파일입니다. 덤프를 올려야 값이 보입니다.')

    # ---------- 타입 그래프 복원
    def _rebuild_types(self, recs: List[dict]) -> List[TypeInfo]:
        out = [TypeInfo() for _ in recs]
        for t, r in zip(out, recs):
            t.kind = r.get('k', 'unknown')
            t.name = r.get('n', '?')
            t.byte_size = r.get('sz')
            t.encoding = r.get('e')
            t.dims = list(r.get('d') or [])
            t.typedef_name = r.get('td')
            t.is_const = bool(r.get('c'))
            t.is_volatile = bool(r.get('v'))
            if r.get('em'):
                t.enum_map = {k: v for k, v in r['em']}
        for t, r in zip(out, recs):
            if r.get('el') is not None:
                t.elem = out[r['el']]
            if 'm' in r:
                t.members = [
                    Member(m['n'], out[m['t']], m.get('o', 0),
                           m.get('bs'), m.get('bo'), m.get('bb'))
                    for m in r['m']]
        return out

    def _rebuild_globals(self, recs: List[dict]) -> List[VarNode]:
        out = []
        for r in recs:
            t = self._types[r['t']] if r.get('t') is not None else None
            n = VarNode(r['n'], t, r.get('a'), self)
            n.no_storage = bool(r.get('ns'))
            n.decl_line = r.get('ln')
            if n.no_storage:
                self.optimized_out += 1
            out.append(n)
        for i, n in enumerate(out):
            n.row = i
        return out

    # ---------- DWARF 의존 메서드 대체
    def members_of(self, tinfo: TypeInfo) -> list:
        return tinfo.members or []

    def close(self):
        pass

    def summary(self) -> dict:
        m = self.store_meta
        return {
            'file': self.path,
            'machine': m.get('machine', '?'),
            'class': f"ELF{m.get('elfclass', '?')}",
            'endian': 'big' if self.big_endian else 'little',
            'dwarf': ', '.join(str(v) for v in sorted(self.dwarf_versions)),
            'globals': len(self.globals),
            'optimized_out': self.optimized_out,
            'warnings': self.warnings,
            'source_elf': m.get('src'),
            'sha256': m.get('sha256'),
            'crypto': crypto.get_provider(self.provider_name).describe(),
            'key_id': self.key_fingerprint,
        }


# ==================================================================== 보관함
def app_dir() -> str:
    """실행 파일(또는 스크립트)이 있는 폴더.

    PyInstaller 로 묶은 경우 sys.executable 기준, 아니면 이 파일 기준.
    """
    if getattr(sys, 'frozen', False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


def default_store_dir() -> str:
    """심볼 저장본 보관 폴더 - 실행 파일 폴더 아래 symbols/.

    폐쇄망에서 도구를 폴더째 옮겨도 저장본이 따라오도록 홈 디렉터리가
    아니라 실행 폴더 하위에 둔다.
    """
    d = os.path.join(app_dir(), 'symbols')
    try:
        os.makedirs(d, exist_ok=True)
    except OSError:
        # 설치 폴더가 읽기 전용이면 홈으로 떨어진다
        d = os.path.join(os.path.expanduser('~'), '.elfwatch', 'symbols')
        os.makedirs(d, exist_ok=True)
    return d


def list_stores(store_dir: Optional[str] = None) -> List[str]:
    d = store_dir or default_store_dir()
    if not os.path.isdir(d):
        return []
    return sorted(f for f in os.listdir(d) if f.endswith(STORE_EXT))


# ==================================================================== CLI
if __name__ == '__main__':
    import sys
    args = sys.argv[1:]
    if not args:
        print('usage:')
        print('  python symstore.py export <in.elf> <out.ews> [key file] '
              '[--provider aesgcm256|chacha20]')
        print('  python symstore.py info   <in.ews> [key file]')
        print('  python symstore.py genkey <out.key>')
        print('  python symstore.py providers')
        print()
        print('키 파일을 생략하면 도구에 내장된 키를 씁니다.')
        raise SystemExit(1)

    prov = None
    if '--provider' in args:
        i = args.index('--provider')
        prov = args[i + 1]
        args = args[:i] + args[i + 2:]

    cmd = args[0]
    if cmd == 'providers':
        for n, desc, ok in crypto.available_providers():
            print(f"  {'O' if ok else 'X'} {n:<11} {desc}")
        print(f'\n기본값: {crypto.get_provider().name}')
        print(f'내장 키 지문: {crypto.key_id(embedded_key())}')
    elif cmd == 'genkey':
        print('키 생성:', generate_key_file(args[1]))
    elif cmd == 'export':
        key = resolve_key(args[3] if len(args) > 3 else None)
        info = export_store(args[1], args[2], key, provider=prov)
        print(f"전역 {info['globals']}개 / 타입 {info['types']}개")
        print(f"JSON {info['json']:,}B -> 압축 {info['compressed']:,}B "
              f"-> 파일 {info['file']:,}B")
        print(f"암호 {info['provider']}  키 {info['key_id']}"
              + ('  (내장 키)' if len(args) <= 3 else f"  ({args[3]})"))
        print(f"원본 SHA256 {info['sha256'][:16]}...")
    elif cmd == 'info':
        src = StoreSource(args[1], resolve_key(args[2] if len(args) > 2 else None))
        for k, v in src.summary().items():
            print(f'{k:>12}: {v}')
    else:
        print('알 수 없는 명령:', cmd)
        raise SystemExit(1)
