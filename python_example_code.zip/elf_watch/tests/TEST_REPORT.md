# 검증 보고서

## 검증 방법 — 실행 가능한 정답지

파서가 옳은지 판단하려면 기준값이 필요하다. 손으로 적은 기대값은 파서와 같은
오해를 공유할 수 있으므로, **프로그램을 실제로 실행시켜** 정답지를 만들었다.

```
edge_cases.c ──┬── gcc -DORACLE ──────────► x86-64 실행 ──► oracle.txt
               └── powerpc-gcc -DORACLE ──► qemu-ppc 실행 ─► oracle_be.txt
                                                                │
             동일 바이너리를 dwarf_reader 로 파싱 ──────────────┴─► 자동 비교
```

`edge_cases.c` 는 매크로로 자기 전역변수를 `경로=값` 형식으로 출력한다.

```c
#define P_I(e) printf("%s=%lld\n", #e, (long long)(e))
P_I(g_sbits.trim);        /* -> "g_sbits.trim=-1000" */
```

`#e` 가 만든 문자열은 C 표현식 그대로이므로, 파서가 만든 트리 경로
(`g_sbits` → `trim`)와 바로 대조할 수 있다. 비교 항목 **69개**.

빅엔디안 정답지는 qemu-ppc 로 실행해 얻었다. LE/BE 두 정답지를 서로 비교하면
차이나는 항목은 **의도적으로 엔디안 의존적인 공용체 오버레이 10개뿐**이었고,
이는 정답지 자체가 올바름을 뒷받침한다.

## 검증 매트릭스 — 18개 구성 전부 통과

| 구분 | 구성 | 결과 |
|---|---|---|
| DWARF 버전 (LE) | x86-64, DWARF 2 / 3 / 4 / 5 | 69/69 × 4 |
| DWARF 버전 (BE) | PowerPC, DWARF 2 / 3 / 4 / 5 | 69/69 × 4 |
| 최적화 (LE) | x86-64, -O0 / O1 / O2 / O3 / Os | 69, 68×4 |
| 최적화 (BE) | PowerPC, -O0 / O1 / O2 / O3 / Os | 69, 68×4 |
| 베어메탈 | MPC5674F 유사 링커 스크립트, DWARF 2/4/5 | 비트필드 OK |

`-O1` 이상에서 1건이 빠지는 것은 파서 결함이 아니다. `gs_dup` 은 GCC 가
상수 폴딩으로 제거해 DIE 에 `DW_AT_location` 도 `DW_AT_const_value` 도 없다.
저장 공간이 실제로 없으므로 읽을 값 자체가 존재하지 않는다.
(파서는 이런 변수를 목록에서 지우지 않고 `<optimized out>` 으로 표시한다.
빌드에서 사라졌다는 사실 자체가 확인해야 할 정보이기 때문이다.)

## 다룬 경계 케이스

- 익명 struct / 익명 union / 익명 union 안의 익명 struct
- 저장 단위(32bit)를 넘나드는 비트필드 (`20+20+20+4`)
- `__attribute__((packed))` 구조체의 바이트 경계에 걸친 24bit 필드
- 폭 0 비트필드(`u32 : 0`)에 의한 강제 정렬, 무명 패딩 비트필드
- 부호 있는 비트필드의 음수값 (`s32 trim : 12` = -1000)
- 5단 중첩 구조체
- 음수 열거자 enum, `0x7FFFFFFF` 열거자, 무명 enum
- 함수 포인터, 포인터 배열, 배열 포인터, `void *`, `const` 포인터
- 공용체 안의 구조체 배열 / `u64` / `double` 오버레이
- 가변 길이 배열 멤버 (`u16 items[]`)
- 2차원 구조체 배열 + 내부 비트필드
- 자기참조 이중 포인터, 2048 원소 대형 배열
- 두 컴파일 유닛에 동일 이름 `static` 변수
- `_Bool`, `s8`~`s64`, `u64`, `float`/`double` 경계값

## 비정상 입력

| 입력 | 동작 |
|---|---|
| `strip --strip-debug` 된 ELF | `.debug_info 섹션이 없습니다` 명시적 오류 |
| 재배치 오브젝트(.o) | 파싱은 되며 "주소가 섹션 상대값" 경고 표시 |
| 잘린 ELF / ELF 아닌 파일 / 빈 파일 | pyelftools 예외를 그대로 전달, GUI 는 대화상자 표시 |

## 2단계 — 타입 조합 대량 생성

손으로 쓴 케이스만으로는 조합 공간을 덮을 수 없어 `gen_types.py` 로
타입을 생성했다. 생성기는 헤더·전역변수·정답지 printf 를 한 번에 만든다.

```
gen_types.py ──► gen_types.h  (typedef 140여 개)
              ├► gen_types.c  (전역변수 160여 개 + 정적 초기화자)
              └► main()       (모든 스칼라 리프의 printf)
```

조합 축:

| 축 | 값 |
|---|---|
| 기반 타입 | char/signed char/unsigned char, short, int, long, long long, int8~64_t, uint8~64_t, float, double, _Bool (22종) |
| 비트필드 | 폭 1~63, 부호 있음/없음, 무명 패딩, 폭 0 정렬, 저장단위 초과 |
| 정렬 | 기본, `__attribute__((packed))`, `#pragma pack(1/2/4)`, `aligned(8/16)` |
| 배열 | 1~4차원, 크기 1~4, 스칼라/구조체/공용체 원소 |
| 중첩 | struct/union 최대 3단 재귀 + 익명 struct/union |
| 포인터 | `void *`, `const char *`, `int (*)[4]`, `void (*)(void)`, 전방선언 포인터 |
| enum | 0부터, 음수 포함, `0x7FFFFFFF`, 무명 |
| 한정자 | const, volatile, const volatile, typedef 4단 체인 |

시드를 바꾸면 다른 조합이 나온다. 실행 결과:

| 시드 | 비교 항목 | DWARF 2/4/5 × LE/BE |
|---|---|---|
| 20260909 | 7,321 | 6/6 통과 |
| 42 | 7,005 | 6/6 통과 |
| 1 | 각 시드 5,000~21,000 | 6/6 통과 |
| 7 | 8,026 | 6/6 통과 |
| 555 | 10,296 | 6/6 통과 |
| 8888 / 31337 / 99991 / 1234 | 5,300~31,700 | 통과 |

**누적 비교 항목 20만 건 이상, 실패 0건.**

덧붙여 `-g1` 처럼 타입 정보가 없는 빌드는 조용히 빈 트리를 내지 않고
경고를 표시한다.

## 3단계 — 컴파일러 / 아키텍처 / 디버그 형식

같은 조합 소스를 **다른 생산자(producer)** 로 빌드해 검증했다.
CodeWarrior 도 GCC 가 아니므로 이 축이 실질적으로 중요하다.

| 축 | 구성 | 결과 |
|---|---|---|
| 컴파일러 | gcc 13 / clang 18 × DWARF 2/3/4/5 | 8/8 통과 |
| 아키텍처 | x86-64(LE64), PowerPC(BE32), ARM(LE32), s390x(**BE64**) | 5/5 통과 |
| 디버그 형식 | `-gz` 압축, `-gz=zlib-gnu`, `-fdebug-types-section`(DWARF4/5), `-flto`(DWARF4/5), `-gstrict-dwarf`, `-ffunction-sections`+`--gc-sections`, `-g3`, PIE | 10/10 통과 |

추가로 다음도 검증했다.

| 항목 | 결과 |
|---|---|
| DWARF64 형식 (`-gdwarf64`, DWARF5·타입유닛 조합 포함) | 3/3 통과 |
| `.gnu_debuglink` 로 분리된 디버그 파일 | 통과 (자동으로 찾아 읽음) |
| **베어메탈 ROM 이미지 (LMA ≠ VMA)** | 통과 |

ROM 이미지는 MPC5674F 배치 그대로다. 초기화 데이터를 flash 에 두고
`.data : > sram AT> flash` 로 RAM 주소에 배치했다. 실행할 수 없으므로
같은 소스를 호스트용으로 빌드해 qemu 로 실행한 값을 정답지로 삼아 대조했다.
LMA/VMA 가 갈려도 초기값이 정확히 읽힌다.

`run_matrix_tests.sh` 한 번에 **28개 구성 / 220,668건** 비교, 실패 0.

s390x 는 **64비트 빅엔디안**이라 '빅엔디안'과 '32비트'가 얽혀 있던
가정을 분리해 준다. ARM 은 AAPCS 의 다른 구조체 정렬 규칙을 검증한다.

## 이 과정에서 찾아 고친 결함 11건

**1. 리틀엔디안 `DW_AT_data_bit_offset` 오독 (심각)**

DWARF 4/5 의 비트필드 오프셋을 컨테이너 크기 단위로 정렬해 해석했다.
빅엔디안에서는 우연히 맞았지만 리틀엔디안 DWARF 5 에서 15개 값이 전부 틀렸다.
packed 구조체에서는 양쪽 다 틀린다.

```
수정 전: unit_off = (dbo // (container*8)) * container   # 컨테이너 정렬
수정 후: byte_start = dbo // 8;  nbytes = (dbo%8 + bit_size + 7) // 8
```

바이트 단위로 정확히 필요한 만큼만 읽도록 바꿔 두 엔디안과 packed 구조체에서
모두 동작한다. **이 결함은 빅엔디안만 테스트했다면 발견되지 않았다.**

**2. packed 구조체의 음수 `DW_AT_bit_offset` (심각)**

조합 테스트에서 10,192건 중 143건이 실패했다. 전부 비트필드였고,
원인은 `#pragma pack(1)` 에서 GCC 가 내는 **음수 비트 오프셋**이었다.

```
int16_t m1_bf1 : 9;   ->  DW_AT_byte_size: 2
                          DW_AT_bit_offset: -7      <- 음수
                          DW_AT_data_member_location: 8
```

필드가 선언된 컨테이너(2바이트) 밖으로 삐져나가는 경우다.
컨테이너 안에 필드가 들어간다고 가정한 계산은 여기서 무너진다.

구조체 시작을 원점으로 하는 '비트 스트림 위치' 하나로 통일해 해결했다.

```
start_bit = data_member_location*8 + (엔디안별 환산)
byte_start = start_bit // 8          # 음수도 floor 로 처리
bit_in     = start_bit - byte_start*8
nbytes     = (bit_in + bit_size + 7) // 8
```

DWARF 2/3 의 `bit_offset` 과 DWARF 4/5 의 `data_bit_offset` 이
같은 경로로 처리되고, packed·저장단위 초과·음수 오프셋이 모두 풀린다.

**3. 부호 있는 비트필드 부호 확장 누락** — `s32 trim : 12` 의 -1000 이
3096 으로 표시됐다.

**4. 음수 열거자를 가진 enum** — `NEG_MID = -1` 이 4294967295 로 표시되고
열거자 이름 매칭에도 실패했다.

**5. 크기를 알 수 없는 배열** — flexible array member 가 `(None)` 으로 표시되고,
펼칠 수 없는데도 트리에 확장 화살표가 나타났다.

**6. clang 의 부호 없는 form 비트 오프셋 (심각)**

GCC 는 음수 `DW_AT_bit_offset` 을 `DW_FORM_sdata` 로 내지만
clang 은 부호 없는 form 에 2의 보수를 담는다.

```
gcc  : DW_AT_bit_offset : -7                     (DW_FORM_sdata)
clang: DW_AT_bit_offset : 0xFFFFFFFFFFFFFFD1     (DW_FORM_data8, = -47)
```

그대로 읽으면 천문학적인 양수가 되어 clang DWARF 2/3 에서 비트필드
261건이 전부 해석 불가였다. form 폭 기준으로 2의 보수를 되돌리도록 수정.
**GCC 만 테스트했다면 발견되지 않았다.**

**7. LTO 빌드에서 전역변수 전멸**

LTO 는 위치 정보를 가진 DIE 와 이름·타입을 가진 DIE 를 분리하고
`DW_AT_abstract_origin` 으로 연결한다. 이를 따라가지 않아 전역변수를
하나도 못 읽었다. `DW_AT_specification` / `DW_AT_abstract_origin`
추적을 추가하고 원본 DIE 기준으로 중복을 제거했다.

**8. 타입 유닛(`-fdebug-types-section`) 미지원**

DWARF4 는 `.debug_types` 섹션, DWARF5 는 `.debug_info` 안의
`DW_UT_type` 유닛에 타입 정의를 분리한다. 참조는 `DW_FORM_ref_sig8`.
DWARF5 쪽은 pyelftools 의 `get_DIE_by_sig8` 이 찾지 못해
시그니처 맵을 직접 만들었다. DWARF5 타입유닛에서 7,880/7,881 실패였다.

**9. DIE 캐시 키 충돌 (심각)**

`.debug_types` 의 DIE 오프셋은 `.debug_info` 와 독립적으로 매겨진다.
오프셋만으로 타입을 캐시하고 있어서, 서로 다른 섹션의 같은 오프셋 DIE 가
**엉뚱한 타입으로 표시**됐다. `uint8_t m1` 이 `S80_t` 구조체로 나오는 식이다.
소속 유닛까지 키에 포함하도록 수정.

이런 오표시는 값이 그럴듯하게 나오기 때문에 눈으로는 잡기 어렵다.
실행 정답지와 대조했기에 드러났다.

**10. `.dwo` / `-g1` 은 조용히 실패하지 않게

`-gsplit-dwarf` 는 디버그 정보가 별도 `.dwo` 파일에 있어 지원하지 않는다.
`-g1` 은 변수는 있으나 타입이 없다. 둘 다 빈 트리를 내는 대신
무엇이 문제이고 어떻게 빌드해야 하는지 안내한다.

**11. 동일 이름 static 변수** — 심볼 목록에서 이름으로 매칭해 두 CU 의
`gs_dup` 중 항상 첫 번째만 선택됐다. 행 인덱스 매칭으로 변경하고 목록에
선언 라인을 병기.

부수적으로 함수 포인터·배열 포인터 타입 표기를 C 선언 문법에 맞췄고
(`u32[3] *` → `u32 (*)[3]`), 대형 배열은 `[0..255]` 형태로 그룹핑하도록 했다.

## 성능

| 대상 | 크기 | 로드 | 전체 전개 |
|---|---|---|---|
| x86-64 DWARF4 | 53 KB | 16 ms | 2251 노드 / 11 ms |
| PowerPC static | 732 KB | 53 ms | 2251 노드 / 9 ms |

## 재실행

```bash
apt-get install gcc-powerpc-linux-gnu qemu-user

cd tests
./run_all_tests.sh                          # 손으로 쓴 경계 케이스 18구성
./run_combo_tests.sh                        # 타입 조합 대량 검증
./run_matrix_tests.sh                       # 컴파일러/아키텍처/디버그 형식
./run_combo_tests.sh "1 7 42 555 12345"     # 시드 지정
python3 gen_types.py 90 31337               # 헤더/소스만 생성
```

CodeWarrior 로 빌드한 실물 ELF 에 대해서도 같은 방식을 쓸 수 있다.
타깃에서 값을 찍는 진단 코드를 잠깐 넣어 정답지를 만들면,
파서 결과와 자동 대조가 가능하다.
