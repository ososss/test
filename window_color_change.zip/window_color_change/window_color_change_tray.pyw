import copy
import ctypes
import os
import sys

from PyQt6.QtCore import Qt
from PyQt6.QtGui import QAction, QActionGroup, QColor, QIcon, QPainter, QPen, QPixmap
from PyQt6.QtWidgets import QApplication, QInputDialog, QMenu, QMessageBox, QSystemTrayIcon

import window_color_change as engine
import window_color_change_settings as settings
import window_color_change_tools as tools

APP_TITLE = "윈도우 컬러 체인지"
MUTEX_NAME = "WindowColorChange.SingleInstance"
ERROR_ALREADY_EXISTS = 183
SCRIPT = os.path.abspath(__file__)


def make_icon(active):
    pm = QPixmap(64, 64)
    pm.fill(Qt.GlobalColor.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setPen(QPen(QColor("#5F6368"), 4))
    p.setBrush(QColor("#E6EDF3" if active else "#C4C7C5"))
    p.drawEllipse(4, 4, 56, 56)
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(QColor("#1B1F27" if active else "#80868B"))
    p.drawPie(6, 6, 52, 52, 90 * 16, 180 * 16)
    p.end()
    return QIcon(pm)


class Tray:
    def __init__(self, qapp, eapp):
        self.qapp = qapp
        self.app = eapp
        self.dialog = None
        self.picker = None
        self.icon_on = make_icon(True)
        self.icon_off = make_icon(False)
        self.tray = QSystemTrayIcon(self.icon_on)
        self.menu = QMenu()
        self.menu.aboutToShow.connect(self.refresh_menu_state)
        title = QAction(APP_TITLE, self.menu)
        title.setEnabled(False)
        self.menu.addAction(title)
        self.menu.addSeparator()
        self.toggles = {}
        for key, label, attr, func in (("filter", "필터", "filter_on", eapp.toggle_filter),
                                       ("mask", "mask", "mask_on", eapp.toggle_mask),
                                       ("see_through", "see_through", "see_on", eapp.toggle_see),
                                       ("hole", "hole", "hole_on", eapp.toggle_hole)):
            act = QAction(label, self.menu)
            act.setCheckable(True)
            act.setData(label)
            act.triggered.connect(lambda checked, a=attr, f=func: self.set_state(a, f, checked))
            self.menu.addAction(act)
            self.toggles[key] = (act, attr)
        self.color_menu = self.menu.addMenu("필터 색")
        self.color_menu.aboutToShow.connect(self.build_color_menu)
        self.set_menu = self.menu.addMenu("설정 세트")
        self.set_menu.aboutToShow.connect(self.build_set_menu)
        self.auto_act = QAction("자동 전환", self.menu)
        self.auto_act.setCheckable(True)
        self.auto_act.triggered.connect(self.toggle_auto)
        self.menu.addAction(self.auto_act)
        self.menu.addSeparator()
        self.edit_act = self.add_action(self.menu, "영역 그리기·편집...", self.edit_from_menu)
        self.add_action(self.menu, "설정...", self.open_settings)
        self.add_action(self.menu, "설정 다시 읽기", self.reload)
        self.add_action(self.menu, "설정 폴더 열기", self.open_folder)
        self.startup_act = QAction("Windows 시작 시 실행", self.menu)
        self.startup_act.setCheckable(True)
        self.startup_act.triggered.connect(self.toggle_startup)
        self.menu.addAction(self.startup_act)
        self.menu.addSeparator()
        self.add_action(self.menu, "종료", self.quit)
        self.tray.setContextMenu(self.menu)
        self.tray.activated.connect(self.on_activated)
        eapp.on_change = self.refresh
        eapp.notify_func = self.notify
        eapp.on_quit = self.quit
        eapp.on_edit_request = self.edit_window
        self.refresh()
        self.tray.show()

    @staticmethod
    def add_action(menu, text, slot):
        act = QAction(text, menu)
        act.triggered.connect(slot)
        menu.addAction(act)
        return act

    def hint(self, key):
        spec = (self.app.cfg.get("hotkeys") or {}).get(key)
        return "\t" + engine.format_hotkey(spec) if spec else ""

    def set_state(self, attr, func, checked):
        if bool(getattr(self.app, attr)) != bool(checked):
            func()
        self.refresh()

    def refresh(self):
        for key, (act, attr) in self.toggles.items():
            act.setChecked(bool(getattr(self.app, attr)))
            act.setText(act.data() + self.hint(key))
        self.edit_act.setText("영역 그리기·편집..." + self.hint("edit"))
        self.tray.setIcon(self.icon_on if self.app.filter_on and not self.app.peeking else self.icon_off)
        self.tray.setToolTip(("%s\n%s\n필터 색: %s" % (APP_TITLE, self.app.status_text(),
                                                     self.app.filter_label()))[:127])

    def refresh_menu_state(self):
        self.refresh()
        self.auto_act.setChecked(bool((self.app.global_cfg.get("auto") or {}).get("enabled", True)))
        try:
            self.startup_act.setChecked(tools.startup_enabled(SCRIPT))
        except (OSError, ImportError):
            self.startup_act.setChecked(False)

    def build_color_menu(self):
        m = self.color_menu
        m.clear()
        group = QActionGroup(m)
        base = QAction("설정값 (%s)" % engine.describe_filter(self.app.cfg["filter"]), m)
        base.setCheckable(True)
        base.setChecked(self.app.cycle_index == -1)
        base.triggered.connect(lambda checked=False: self.app.set_cycle(-1))
        group.addAction(base)
        m.addAction(base)
        for i, entry in enumerate(self.app.cycle_entries()):
            act = QAction(engine.cycle_label(entry), m)
            act.setCheckable(True)
            act.setChecked(self.app.cycle_index == i)
            act.triggered.connect(lambda checked=False, i=i: self.app.set_cycle(i))
            group.addAction(act)
            m.addAction(act)
        m.addSeparator()
        self.add_action(m, "다음 색" + self.hint("cycle"), lambda checked=False: self.app.cycle_next())
        self.add_action(m, "색 목록 편집...", lambda checked=False: self.open_settings(tab="필터"))

    def build_set_menu(self):
        m = self.set_menu
        m.clear()
        group = QActionGroup(m)
        current = self.app.set_name()
        for name in engine.list_sets():
            act = QAction(name, m)
            act.setCheckable(True)
            act.setChecked(name == current)
            act.triggered.connect(lambda checked=False, n=name: self.switch_set(n))
            group.addAction(act)
            m.addAction(act)
        m.addSeparator()
        self.add_action(m, "현재 설정을 새 세트로 저장...", self.save_set)
        self.add_action(m, "세트 관리...", lambda checked=False: self.open_settings(tab="세트"))

    def switch_set(self, name):
        if name != self.app.set_name() and self.app.switch_set(name):
            self.dialog_reload()

    def save_set(self, *_):
        name, ok = QInputDialog.getText(None, APP_TITLE, "새 세트 이름")
        name = (name or "").strip()
        if not ok or not name:
            return
        if name in engine.list_sets():
            answer = QMessageBox.question(None, APP_TITLE, "'%s' 세트가 이미 있습니다. 덮어쓸까요?" % name)
            if answer != QMessageBox.StandardButton.Yes:
                return
        try:
            self.app.save_set_as(name)
        except (ValueError, OSError) as e:
            QMessageBox.warning(None, APP_TITLE, str(e))
            return
        self.notify("설정 세트", "현재 설정을 '%s' 세트로 저장했습니다." % name)

    def toggle_auto(self, checked):
        g = copy.deepcopy(self.app.global_cfg)
        g.setdefault("auto", {})["enabled"] = bool(checked)
        g["active_set"] = self.app.set_name()
        try:
            engine.save_global(g)
        except (OSError, ValueError) as e:
            self.notify("자동 전환", "저장하지 못했습니다: %s" % e)
            return
        self.app.reload_global()
        self.notify("자동 전환", "켰습니다." if checked else "껐습니다.")
        self.dialog_reload()

    def toggle_startup(self, checked):
        try:
            tools.set_startup(SCRIPT, bool(checked))
        except (OSError, ImportError) as e:
            self.notify("Windows 시작 시 실행", "설정하지 못했습니다: %s" % e)
        self.refresh_menu_state()

    def edit_from_menu(self, *_):
        targets = list(self.app.overlays)
        if len(targets) == 1:
            self.edit_window(targets[0])
            return
        self.notify("영역 그리기·편집", "편집할 창을 클릭하세요.")
        self.picker = tools.WindowPicker(self.app, lambda info: info and self.edit_window(info["hwnd"]))
        self.picker.start()

    def edit_window(self, hwnd):
        if not hwnd:
            self.notify("영역 그리기·편집", "편집할 창을 찾지 못했습니다.")
            return
        cls, title = engine.get_class(hwnd), engine.get_title(hwnd)
        pi = self.app.match_index(cls, title)
        if pi is None:
            answer = QMessageBox.question(None, APP_TITLE, "이 창(class=%s)에 맞는 프로필이 없습니다.\n"
                                          "이 창용 프로필을 새로 만들까요?" % cls)
            if answer != QMessageBox.StandardButton.Yes:
                return
            cfg = copy.deepcopy(self.app.cfg)
            profile = settings.new_profile(len(cfg["profiles"]) + 1)
            profile["name"] = (title or cls)[:30]
            profile["match"]["class"] = cls
            cfg["profiles"].append(profile)
            try:
                engine.save_config(self.app.path, engine.check_config(cfg))
            except (ValueError, OSError) as e:
                QMessageBox.warning(None, APP_TITLE, str(e))
                return
            self.app.reload()
            pi = len(self.app.cfg["profiles"]) - 1
        try:
            tools.open_area_editor(self.app, hwnd, pi, self.after_edit)
        except ValueError as e:
            self.app.set_suspended(False)
            QMessageBox.warning(None, APP_TITLE, str(e))

    def after_edit(self, saved):
        if saved:
            self.notify("영역 그리기·편집", "영역을 저장하고 적용했습니다.")
            self.dialog_reload()

    def dialog_reload(self):
        if self.dialog is not None and self.dialog.isVisible():
            self.dialog.load_from_file()

    def notify(self, title, text):
        self.tray.showMessage(title, text, QSystemTrayIcon.MessageIcon.Information, 5000)

    def on_activated(self, reason):
        if reason == QSystemTrayIcon.ActivationReason.DoubleClick:
            self.open_settings()

    def open_settings(self, *_, tab=None):
        if self.dialog is None:
            self.dialog = settings.SettingsDialog(self.app)
        else:
            self.dialog.load_from_file()
        if tab:
            for i in range(self.dialog.tabs.count()):
                if self.dialog.tabs.tabText(i) == tab:
                    self.dialog.tabs.setCurrentIndex(i)
        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()

    def reload(self, *_):
        if self.app.reload():
            self.notify(APP_TITLE, "설정을 다시 읽었습니다.")
            self.dialog_reload()

    def open_folder(self, *_):
        os.startfile(os.path.dirname(os.path.abspath(self.app.path)))

    def quit(self, *_):
        if self.dialog is not None:
            self.dialog.close()
        self.qapp.quit()


def single_instance():
    k32 = ctypes.WinDLL("kernel32", use_last_error=True)
    k32.CreateMutexW.restype = ctypes.c_void_p
    k32.CreateMutexW.argtypes = [ctypes.c_void_p, ctypes.c_bool, ctypes.c_wchar_p]
    handle = k32.CreateMutexW(None, False, MUTEX_NAME)
    if not handle or ctypes.get_last_error() == ERROR_ALREADY_EXISTS:
        return None
    return handle


def create_engine_app():
    path = engine.startup_path()
    while True:
        try:
            return engine.App(path)
        except ValueError as e:
            answer = QMessageBox.question(None, APP_TITLE, "설정 파일에 오류가 있습니다.\n%s\n%s\n\n"
                                          "기본 설정으로 시작할까요? 기존 파일은 .bak으로 보관합니다." % (path, e))
            if answer != QMessageBox.StandardButton.Yes:
                return None
            os.replace(path, path + ".bak")
        except OSError as e:
            QMessageBox.critical(None, APP_TITLE, "시작하지 못했습니다.\n%s" % e)
            return None


def main():
    qapp = QApplication(sys.argv)
    qapp.setQuitOnLastWindowClosed(False)
    qapp.setApplicationName(APP_TITLE)
    if not engine.IS_WIN:
        QMessageBox.critical(None, APP_TITLE, "Windows 전용 프로그램입니다.")
        return 1
    mutex = single_instance()
    if mutex is None:
        QMessageBox.information(None, APP_TITLE, "이미 실행 중입니다. 작업 표시줄 오른쪽 트레이 아이콘을 확인하세요.")
        return 0
    ok, err = engine.init_engine(set_dpi=False)
    if not ok:
        QMessageBox.critical(None, APP_TITLE, err)
        return 1
    eapp = create_engine_app()
    if eapp is None:
        engine.uninit_engine()
        return 1
    holder = [eapp]
    handler = engine.install_console_handler(holder)
    tray = Tray(qapp, eapp)
    qapp.aboutToQuit.connect(eapp.shutdown)
    eapp.tick()
    if eapp.hotkey_errors:
        tray.notify("단축키", "\n".join(eapp.hotkey_errors))
    else:
        tray.notify(APP_TITLE, "트레이에서 실행 중입니다. 아이콘을 더블클릭하면 설정 창이 열립니다.")
    code = qapp.exec()
    tray.tray.hide()
    eapp.shutdown()
    engine.uninit_engine()
    del handler, mutex
    return code


if __name__ == "__main__":
    sys.exit(main())
