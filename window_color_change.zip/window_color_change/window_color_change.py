import ctypes
import json
import os
import re
import struct
import sys
import time

BASE_PATH = os.path.splitext(os.path.abspath(__file__))[0]
CONFIG_PATH = BASE_PATH + ".json"
GLOBAL_PATH = BASE_PATH + "_global.json"
SETS_DIR = BASE_PATH + "_sets"
DEFAULT_SET = "기본"
CLASS_NAME = "WindowColorChange"

PRESETS = {
    "smart_invert": [
        [0.574, -0.426, -0.426, 0.0, 0.0],
        [-1.430, -0.430, -1.430, 0.0, 0.0],
        [-0.144, -0.144, 0.856, 0.0, 0.0],
        [0.0, 0.0, 0.0, 1.0, 0.0],
        [1.0, 1.0, 1.0, 0.0, 1.0],
    ],
    "invert": [
        [-1.0, 0.0, 0.0, 0.0, 0.0],
        [0.0, -1.0, 0.0, 0.0, 0.0],
        [0.0, 0.0, -1.0, 0.0, 0.0],
        [0.0, 0.0, 0.0, 1.0, 0.0],
        [1.0, 1.0, 1.0, 0.0, 1.0],
    ],
    "dark_navy": [
        [0.457, -0.344, -0.341, 0.0, 0.0],
        [-1.138, -0.347, -1.144, 0.0, 0.0],
        [-0.115, -0.116, 0.685, 0.0, 0.0],
        [0.0, 0.0, 0.0, 1.0, 0.0],
        [0.902, 0.929, 0.953, 0.0, 1.0],
    ],
}

DEFAULT_CONFIG = {
    "refresh_ms": 16,
    "dpi_scale": True,
    "filter": {"start_on": True, "preset": "smart_invert", "background": None, "text": None, "matrix": None,
               "brightness": 0, "contrast": 0, "saturation": 0,
               "cycle": ["smart_invert", "dark_navy", "invert"]},
    "mask": {"start_on": True, "click_through": True, "alpha": 255, "color": "#1B1F27"},
    "see_through": {"start_on": True, "alpha": 255, "use_filter": False},
    "hole": {"start_on": True, "use_filter": False, "cover": True, "hide_border": True, "dwm_fix": False},
    "hotkeys": {
        "filter": "ctrl+alt+f",
        "mask": "ctrl+alt+m",
        "see_through": "ctrl+alt+t",
        "hole": "ctrl+alt+h",
        "peek": "ctrl+alt+space",
        "cycle": "ctrl+alt+c",
        "edit": "ctrl+alt+e",
        "pick": "ctrl+alt+p",
        "reload": "ctrl+alt+r",
        "quit": "ctrl+alt+q",
    },
    "profiles": [
        {
            "name": "기본",
            "enabled": True,
            "match": {"class": "LyncConversationWindowClass", "title_contains": ""},
            "base": "frame",
            "filter_area": {"left": 0, "top": 0, "right": "100%", "bottom": "100%"},
            "filter_holes": [],
            "filter": None,
            "masks": [
                {"name": "영역 1", "left": 0, "top": -44, "right": "100%", "bottom": "100%",
                 "hotkey": "ctrl+alt+1", "enabled": True},
                {"name": "영역 2", "left": 0, "top": 80, "right": 52, "bottom": -120,
                 "hotkey": "ctrl+alt+2", "enabled": True},
            ],
            "see_through_areas": [
                {"name": "영역 3", "left": 60, "top": 80, "right": -20, "bottom": -120,
                 "hotkey": "ctrl+alt+3", "enabled": False},
            ],
            "hole_areas": [
                {"name": "영역 4", "left": 60, "top": 80, "right": -20, "bottom": -120,
                 "hotkey": "ctrl+alt+4", "enabled": False},
            ],
        }
    ],
}

DEFAULT_GLOBAL = {
    "active_set": DEFAULT_SET,
    "auto": {
        "enabled": True,
        "rules": [
            {"name": "야간", "enabled": False, "when": {"time": "18:00-07:00"},
             "then": {"filter": True}, "else": {"filter": False}},
        ],
    },
}

IDENTITY = [[1.0 if i == j else 0.0 for j in range(5)] for i in range(5)]
AREA_KINDS = ("masks", "see_through_areas", "hole_areas")
AREA_LABELS = {"masks": "mask", "see_through_areas": "see_through", "hole_areas": "hole"}
CONSOLE_EXIT_EVENTS = (1, 2, 5, 6)
TIMER_ID = 1
ERROR_CLASS_ALREADY_EXISTS = 1410

WS_POPUP, WS_CHILD, WS_VISIBLE = 0x80000000, 0x40000000, 0x10000000
WS_EX_TRANSPARENT, WS_EX_TOOLWINDOW = 0x00000020, 0x00000080
WS_EX_LAYERED, WS_EX_NOACTIVATE = 0x00080000, 0x08000000
WS_EX_TOPMOST, GWL_EXSTYLE = 0x00000008, -20
SW_HIDE = 0
SWP_NOACTIVATE, SWP_SHOWWINDOW, SWP_NOOWNERZORDER = 0x0010, 0x0040, 0x0200
HWND_TOP = 0
GW_HWNDPREV, GA_ROOT = 3, 2
LWA_ALPHA = 0x2
WM_PAINT, WM_ERASEBKGND, WM_MOUSEACTIVATE = 0x000F, 0x0014, 0x0021
WM_TIMER, WM_HOTKEY = 0x0113, 0x0312
MA_NOACTIVATE = 3
RGN_OR, RGN_DIFF, RGN_COPY = 2, 4, 5
MW_FILTERMODE_EXCLUDE = 0
DWMWA_EXTENDED_FRAME_BOUNDS, DWMWA_CLOAKED = 9, 14
MONITOR_DEFAULTTONEAREST, MDT_EFFECTIVE_DPI = 2, 0
CF_UNICODETEXT, GMEM_MOVEABLE = 13, 0x0002
IDC_ARROW = 32512
HWND_TOPMOST = -1
ULW_ALPHA, AC_SRC_ALPHA, BI_RGB, DIB_RGB_COLORS = 2, 1, 0, 0
KEY_DOWN = 0x8000
HOLE_COVER = "hole"
DWMWA_NCRENDERING_ENABLED, DWMWA_NCRENDERING_POLICY = 1, 2
DWMNCRP_USEWINDOWSTYLE, DWMNCRP_DISABLED = 0, 1
DWMWA_WINDOW_CORNER_PREFERENCE, DWMWCP_DONOTROUND = 33, 1
DWMWA_SYSTEMBACKDROP_TYPE, DWMSBT_NONE = 38, 1
DWMWA_BORDER_COLOR, DWMWA_COLOR_NONE, DWMWA_COLOR_DEFAULT = 34, 0xFFFFFFFE, 0xFFFFFFFF
SWP_NOSIZE, SWP_NOMOVE, SWP_NOZORDER, SWP_FRAMECHANGED = 0x0001, 0x0002, 0x0004, 0x0020
RDW_INVALIDATE, RDW_ALLCHILDREN, RDW_FRAME = 0x0001, 0x0080, 0x0400
ACTION_KEYS = {"filter": "filter_on", "mask": "mask_on", "see_through": "see_on", "hole": "hole_on"}
ADJUST_KEYS = ("brightness", "contrast", "saturation")
FILTER_COLOR_KEYS = ("preset", "background", "text", "matrix")
MOD_ALT, MOD_CONTROL, MOD_SHIFT, MOD_WIN, MOD_NOREPEAT = 0x1, 0x2, 0x4, 0x8, 0x4000

_MODS = {"alt": MOD_ALT, "ctrl": MOD_CONTROL, "control": MOD_CONTROL, "shift": MOD_SHIFT, "win": MOD_WIN}
_VKEYS = {
    "space": 0x20, "pageup": 0x21, "pagedown": 0x22, "end": 0x23, "home": 0x24,
    "left": 0x25, "up": 0x26, "right": 0x27, "down": 0x28, "insert": 0x2D, "delete": 0x2E,
    "pause": 0x13, "scrolllock": 0x91, "esc": 0x1B, "tab": 0x09,
    "`": 0xC0, "backquote": 0xC0, "-": 0xBD, "minus": 0xBD, "=": 0xBB, "equals": 0xBB,
}
_VKEYS.update({"f%d" % i: 0x6F + i for i in range(1, 25)})
_VKEYS.update({"numpad%d" % i: 0x60 + i for i in range(10)})


def resolve_edge(value, size, scale):
    if isinstance(value, str):
        text = value.strip()
        if text.endswith("%"):
            return int(round(size * float(text[:-1]) / 100.0))
        value = float(text)
    value = float(value)
    px = int(round(abs(value) * scale))
    return size - px if value < 0 else px


def resolve_rect(spec, width, height, scale):
    left = resolve_edge(spec.get("left", 0), width, scale)
    top = resolve_edge(spec.get("top", 0), height, scale)
    right = resolve_edge(spec.get("right", "100%"), width, scale)
    bottom = resolve_edge(spec.get("bottom", "100%"), height, scale)
    left, right = max(0, min(left, width)), max(0, min(right, width))
    top, bottom = max(0, min(top, height)), max(0, min(bottom, height))
    if right <= left or bottom <= top:
        return None
    return (left, top, right, bottom)


def rect_spec(rect, width, height, scale):
    left, top, right, bottom = rect
    return {"left": edge_value(left, width, scale), "top": edge_value(top, height, scale),
            "right": edge_value(right, width, scale), "bottom": edge_value(bottom, height, scale)}


def edge_value(rel, size, scale):
    rel = max(0, min(rel, size))
    if rel <= size / 2:
        return int(round(rel / scale))
    dist = int(round((size - rel) / scale))
    return "100%" if dist == 0 else -dist


def parse_color(text, default=0x00271F1B):
    try:
        s = str(text).strip().lstrip("#")
        r, g, b = int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16)
        return r | (g << 8) | (b << 16)
    except (ValueError, IndexError):
        return default


def parse_hotkey(text):
    parts = [p for p in str(text).replace(" ", "").lower().split("+") if p]
    mods, vk = 0, None
    for p in parts:
        if p in _MODS:
            mods |= _MODS[p]
        elif p in _VKEYS:
            vk = _VKEYS[p]
        elif len(p) == 1 and p.isascii() and p.isalnum():
            vk = ord(p.upper())
        else:
            raise ValueError("알 수 없는 키 '%s'" % p)
    if vk is None:
        raise ValueError("수식키 말고 실제 키가 하나 있어야 합니다")
    return mods | MOD_NOREPEAT, vk


def format_hotkey(text):
    parts = [p for p in str(text).replace(" ", "").split("+") if p]
    return "+".join(p.upper() if len(p) == 1 else p.capitalize() for p in parts)


def match_profile(profile, cls, title):
    if not profile.get("enabled", True):
        return False
    m = profile.get("match") or {}
    want_cls = m.get("class") or ""
    want_title = (m.get("title_contains") or "").lower()
    if not want_cls and not want_title:
        return False
    if want_cls and cls != want_cls:
        return False
    if want_title and want_title not in (title or "").lower():
        return False
    return True


def parse_rgb(text):
    s = str(text).strip().lstrip("#")
    if len(s) != 6:
        raise ValueError("색은 #RRGGBB 형식이어야 합니다: %r" % text)
    try:
        return tuple(int(s[i:i + 2], 16) / 255.0 for i in (0, 2, 4))
    except ValueError:
        raise ValueError("색은 #RRGGBB 형식이어야 합니다: %r" % text)


def tone_matrix(base, background, text):
    bg = parse_rgb(background or "#000000")
    fg = parse_rgb(text or "#FFFFFF")
    k = [fg[j] - bg[j] for j in range(3)]
    m = [list(row) for row in base]
    for i in range(3):
        for j in range(3):
            m[i][j] = round(base[i][j] * k[j], 4)
    for j in range(3):
        m[4][j] = round(bg[j] + k[j] * base[4][j], 4)
    return m


def matrix_for(filter_cfg):
    m = filter_cfg.get("matrix")
    if m:
        if len(m) != 5 or any(len(row) != 5 for row in m):
            raise ValueError("filter.matrix는 5x5 숫자 배열이어야 합니다")
        return [[float(v) for v in row] for row in m]
    name = filter_cfg.get("preset") or "smart_invert"
    if name not in PRESETS:
        raise ValueError("알 수 없는 preset '%s' (사용 가능: %s)" % (name, ", ".join(PRESETS)))
    background, text = filter_cfg.get("background"), filter_cfg.get("text")
    if background or text:
        base = PRESETS[name] if name in ("smart_invert", "invert") else PRESETS["smart_invert"]
        return tone_matrix(base, background, text)
    return PRESETS[name]


def describe_filter(filter_cfg):
    if filter_cfg.get("matrix"):
        text = "사용자 행렬"
    else:
        name = filter_cfg.get("preset") or "smart_invert"
        background, color = filter_cfg.get("background"), filter_cfg.get("text")
        if background or color:
            base = name if name in ("smart_invert", "invert") else "smart_invert"
            text = "%s, 배경 %s / 글자 %s" % (base, background or "#000000", color or "#FFFFFF")
        else:
            text = name
    adjust = ["%s %+d" % (k, int(filter_cfg.get(k) or 0)) for k in ADJUST_KEYS if filter_cfg.get(k)]
    return text + (" (" + ", ".join(adjust) + ")" if adjust else "")


def matmul5(a, b):
    return [[sum(a[i][k] * b[k][j] for k in range(5)) for j in range(5)] for i in range(5)]


def adjust_matrix(brightness=0, contrast=0, saturation=0):
    def unit(v):
        return max(-100.0, min(100.0, float(v or 0))) / 100.0

    b, k, t = unit(brightness), 1.0 + unit(contrast), 1.0 + unit(saturation)
    w = (0.2126, 0.7152, 0.0722)
    sat = [[(1.0 - t) * w[i] + (t if i == j else 0.0) for j in range(3)] + [0.0, 0.0] for i in range(3)]
    sat += [[0.0, 0.0, 0.0, 1.0, 0.0], [0.0, 0.0, 0.0, 0.0, 1.0]]
    con = [[(k if i < 3 else 1.0) if i == j else 0.0 for j in range(5)] for i in range(5)]
    con[4] = [0.5 * (1.0 - k)] * 3 + [0.0, 1.0]
    bri = [[1.0 if i == j else 0.0 for j in range(5)] for i in range(5)]
    bri[4] = [b, b, b, 0.0, 1.0]
    return matmul5(matmul5(sat, con), bri)


def filter_matrix(filter_cfg):
    m = matrix_for(filter_cfg)
    if any(filter_cfg.get(k) for k in ADJUST_KEYS):
        m = matmul5(m, adjust_matrix(*(filter_cfg.get(k) or 0 for k in ADJUST_KEYS)))
    return m


def cycle_override(entry):
    if isinstance(entry, str):
        entry = {"preset": entry}
    if not isinstance(entry, dict):
        raise ValueError("filter.cycle 항목은 preset 이름이나 { } 객체여야 합니다")
    override = {k: None for k in FILTER_COLOR_KEYS}
    override["preset"] = "smart_invert"
    override.update({k: v for k, v in entry.items() if k != "name"})
    return override


def cycle_label(entry):
    if isinstance(entry, str):
        return entry
    return entry.get("name") or describe_filter(cycle_override(entry))


def effective_filter(global_filter, runtime=None, profile_filter=None):
    f = dict(global_filter or {})
    if runtime:
        f.update(runtime)
    if profile_filter:
        f.update(profile_filter)
    return f


def area_alpha(spec, default):
    v = spec.get("alpha")
    if v is None or v == "":
        return default
    return max(0, min(255, int(v)))


def parse_time_range(text):
    m = re.fullmatch(r"\s*(\d{1,2}):(\d{2})\s*-\s*(\d{1,2}):(\d{2})\s*", str(text))
    if not m:
        raise ValueError("time은 HH:MM-HH:MM 형식이어야 합니다: %r" % text)
    h1, m1, h2, m2 = (int(g) for g in m.groups())
    if h1 > 23 or h2 > 23 or m1 > 59 or m2 > 59:
        raise ValueError("time 값이 범위를 벗어났습니다: %r" % text)
    return h1 * 60 + m1, h2 * 60 + m2


def in_time_range(minutes, start, end):
    if start == end:
        return True
    if start < end:
        return start <= minutes < end
    return minutes >= start or minutes < end


def check_rule(rule):
    if not isinstance(rule, dict):
        raise ValueError("규칙은 { } 객체여야 합니다")
    name = rule.get("name") or "규칙"
    when = rule.get("when") or {}
    if not isinstance(when, dict):
        raise ValueError("규칙 '%s': when은 { } 객체여야 합니다" % name)
    if when.get("time"):
        try:
            parse_time_range(when["time"])
        except ValueError as e:
            raise ValueError("규칙 '%s': %s" % (name, e))
    if when.get("dark_mode") not in (None, True, False):
        raise ValueError("규칙 '%s': dark_mode는 true/false여야 합니다" % name)
    for part in ("then", "else"):
        acts = rule.get(part) or {}
        if not isinstance(acts, dict):
            raise ValueError("규칙 '%s': %s는 { } 객체여야 합니다" % (name, part))
        for key, value in acts.items():
            if key in ACTION_KEYS:
                if not isinstance(value, bool):
                    raise ValueError("규칙 '%s' %s.%s는 true/false여야 합니다" % (name, part, key))
            elif key == "preset":
                if value not in PRESETS:
                    raise ValueError("규칙 '%s' %s.preset: 알 수 없는 preset '%s'" % (name, part, value))
            elif key == "set":
                if not valid_set_name(value):
                    raise ValueError("규칙 '%s' %s.set: 세트 이름이 올바르지 않습니다" % (name, part))
            else:
                raise ValueError("규칙 '%s' %s: 알 수 없는 항목 '%s'" % (name, part, key))
    return rule


def rule_matches(rule, ctx):
    when = rule.get("when") or {}
    active = False
    if when.get("time"):
        start, end = parse_time_range(when["time"])
        if not in_time_range(ctx["minutes"], start, end):
            return False
        active = True
    if when.get("dark_mode") is not None:
        if bool(when["dark_mode"]) != bool(ctx["dark"]):
            return False
        active = True
    cls = when.get("window_class") or ""
    title = (when.get("title_contains") or "").lower()
    if cls or title:
        if not any((not cls or c == cls) and (not title or title in t) for c, t in ctx["windows"]):
            return False
        active = True
    return active


def validate_regions(cfg):
    for p in cfg.get("profiles") or []:
        pname = p.get("name", "?")
        specs = [("filter_area", p.get("filter_area") or {})]
        specs += [("filter_holes", s) for s in p.get("filter_holes") or []]
        specs += [(s.get("name", "masks"), s) for s in p.get("masks") or []]
        specs += [(s.get("name", "see_through_areas"), s) for s in p.get("see_through_areas") or []]
        specs += [(s.get("name", "hole_areas"), s) for s in p.get("hole_areas") or []]
        for label, spec in specs:
            try:
                resolve_rect(spec, 1000, 1000, 1.0)
            except (ValueError, TypeError) as e:
                raise ValueError("프로필 '%s'의 '%s' 좌표 오류: %s" % (pname, label, e))


def merge_config(user):
    if not isinstance(user, dict):
        raise ValueError("설정 파일의 최상위는 { } 객체여야 합니다")
    cfg = json.loads(json.dumps(DEFAULT_CONFIG))
    for key, val in user.items():
        if isinstance(val, dict) and isinstance(cfg.get(key), dict):
            cfg[key].update(val)
        else:
            cfg[key] = val
    validate_regions(cfg)
    return cfg


def check_filter(f, where):
    for k in ADJUST_KEYS:
        v = f.get(k) or 0
        if isinstance(v, bool) or not isinstance(v, (int, float)) or not -100 <= v <= 100:
            raise ValueError("%s.%s는 -100~100 사이 숫자여야 합니다" % (where, k))
    try:
        filter_matrix(f)
    except ValueError as e:
        raise ValueError("%s: %s" % (where, e))


def check_config(cfg):
    cfg = merge_config(cfg)
    f = cfg["filter"]
    check_filter(f, "filter")
    cycle = f.get("cycle") or []
    if not isinstance(cycle, list):
        raise ValueError("filter.cycle은 목록이어야 합니다")
    for entry in cycle:
        check_filter(effective_filter(f, cycle_override(entry)), "filter.cycle")
    parse_rgb(cfg["mask"].get("color") or "#1B1F27")
    for key, spec in (cfg.get("hotkeys") or {}).items():
        if spec:
            try:
                parse_hotkey(spec)
            except ValueError as e:
                raise ValueError("hotkeys.%s: %s" % (key, e))
    for p in cfg.get("profiles") or []:
        pname = p.get("name") or "?"
        pf = p.get("filter")
        if pf is not None:
            if not isinstance(pf, dict):
                raise ValueError("프로필 '%s'의 filter는 { } 객체여야 합니다" % pname)
            check_filter(effective_filter(f, None, pf), "프로필 '%s' filter" % pname)
        for kind in AREA_KINDS:
            for a in p.get(kind) or []:
                name = a.get("name") or kind
                if a.get("hotkey"):
                    try:
                        parse_hotkey(a["hotkey"])
                    except ValueError as e:
                        raise ValueError("%s '%s' hotkey: %s" % (kind, name, e))
                if kind == "masks" and a.get("color"):
                    try:
                        parse_rgb(a["color"])
                    except ValueError as e:
                        raise ValueError("masks '%s' color: %s" % (name, e))
                if kind in ("masks", "see_through_areas") and a.get("alpha") not in (None, ""):
                    v = a["alpha"]
                    if isinstance(v, bool) or not isinstance(v, int) or not 0 <= v <= 255:
                        raise ValueError("%s '%s' alpha는 0~255 정수여야 합니다" % (kind, name))
    return cfg


def save_config(path, cfg):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def load_config(path):
    if not os.path.exists(path):
        with open(path, "w", encoding="utf-8") as f:
            json.dump(DEFAULT_CONFIG, f, ensure_ascii=False, indent=2)
        print("기본 설정 파일을 만들었습니다:", path)
        return json.loads(json.dumps(DEFAULT_CONFIG))
    with open(path, encoding="utf-8-sig") as f:
        user = json.load(f)
    return merge_config(user)


def valid_set_name(name):
    return (isinstance(name, str) and bool(re.fullmatch(r'[^\\/:*?"<>|]{1,40}', name))
            and name.strip() == name and name not in (".", ".."))


def set_path(name):
    if not name or name == DEFAULT_SET:
        return CONFIG_PATH
    return os.path.join(SETS_DIR, name + ".json")


def set_name_of(path):
    if os.path.abspath(path) == os.path.abspath(CONFIG_PATH):
        return DEFAULT_SET
    return os.path.splitext(os.path.basename(path))[0]


def list_sets():
    names = [DEFAULT_SET]
    if os.path.isdir(SETS_DIR):
        names += sorted(os.path.splitext(f)[0] for f in os.listdir(SETS_DIR)
                        if f.lower().endswith(".json") and os.path.splitext(f)[0] != DEFAULT_SET)
    return names


def merge_global(user):
    g = json.loads(json.dumps(DEFAULT_GLOBAL))
    if isinstance(user, dict):
        if isinstance(user.get("active_set"), str) and user["active_set"]:
            g["active_set"] = user["active_set"]
        if isinstance(user.get("auto"), dict):
            g["auto"].update(user["auto"])
    rules = g["auto"].get("rules")
    if not isinstance(rules, list):
        raise ValueError("auto.rules는 목록이어야 합니다")
    for rule in rules:
        check_rule(rule)
    return g


def load_global(path=None):
    path = path or GLOBAL_PATH
    if not os.path.exists(path):
        return merge_global({})
    with open(path, encoding="utf-8-sig") as f:
        return merge_global(json.load(f))


def save_global(cfg, path=None):
    save_config(path or GLOBAL_PATH, merge_global(cfg))


def startup_path():
    try:
        name = load_global().get("active_set") or DEFAULT_SET
    except (OSError, ValueError):
        name = DEFAULT_SET
    path = set_path(name)
    return path if os.path.exists(path) else CONFIG_PATH


IS_WIN = os.name == "nt"

if IS_WIN:
    from ctypes import wintypes

    user32 = ctypes.WinDLL("user32", use_last_error=True)
    gdi32 = ctypes.WinDLL("gdi32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    dwmapi = ctypes.WinDLL("dwmapi")
    magdll = ctypes.WinDLL("Magnification", use_last_error=True)
    try:
        shcore = ctypes.WinDLL("shcore")
    except OSError:
        shcore = None

    LRESULT = ctypes.c_ssize_t
    HANDLE, HWND = wintypes.HANDLE, wintypes.HWND
    BOOL, UINT, DWORD, INT = wintypes.BOOL, wintypes.UINT, wintypes.DWORD, ctypes.c_int
    PRECT, PPOINT = ctypes.POINTER(wintypes.RECT), ctypes.POINTER(wintypes.POINT)
    PMSG = ctypes.POINTER(wintypes.MSG)
    WNDPROC = ctypes.WINFUNCTYPE(LRESULT, HWND, UINT, wintypes.WPARAM, wintypes.LPARAM)
    WNDENUMPROC = ctypes.WINFUNCTYPE(BOOL, HWND, wintypes.LPARAM)
    HANDLER_ROUTINE = ctypes.WINFUNCTYPE(BOOL, DWORD)

    class WNDCLASSEXW(ctypes.Structure):
        _fields_ = [("cbSize", UINT), ("style", UINT), ("lpfnWndProc", WNDPROC),
                    ("cbClsExtra", INT), ("cbWndExtra", INT), ("hInstance", wintypes.HINSTANCE),
                    ("hIcon", HANDLE), ("hCursor", HANDLE), ("hbrBackground", HANDLE),
                    ("lpszMenuName", wintypes.LPCWSTR), ("lpszClassName", wintypes.LPCWSTR),
                    ("hIconSm", HANDLE)]

    class PAINTSTRUCT(ctypes.Structure):
        _fields_ = [("hdc", HANDLE), ("fErase", BOOL), ("rcPaint", wintypes.RECT),
                    ("fRestore", BOOL), ("fIncUpdate", BOOL), ("rgbReserved", ctypes.c_byte * 32)]

    class MAGTRANSFORM(ctypes.Structure):
        _fields_ = [("v", (ctypes.c_float * 3) * 3)]

    class MAGCOLOREFFECT(ctypes.Structure):
        _fields_ = [("transform", (ctypes.c_float * 5) * 5)]

    def _fn(dll, name, restype, *argtypes):
        f = getattr(dll, name)
        f.restype = restype
        f.argtypes = list(argtypes)
        return f

    def _opt(dll, name, restype, *argtypes):
        if dll is None:
            return None
        try:
            return _fn(dll, name, restype, *argtypes)
        except AttributeError:
            return None

    RegisterClassExW = _fn(user32, "RegisterClassExW", wintypes.ATOM, ctypes.POINTER(WNDCLASSEXW))
    CreateWindowExW = _fn(user32, "CreateWindowExW", HWND, DWORD, wintypes.LPCWSTR, wintypes.LPCWSTR,
                          DWORD, INT, INT, INT, INT, HWND, HANDLE, wintypes.HINSTANCE, ctypes.c_void_p)
    DestroyWindow = _fn(user32, "DestroyWindow", BOOL, HWND)
    DefWindowProcW = _fn(user32, "DefWindowProcW", LRESULT, HWND, UINT, wintypes.WPARAM, wintypes.LPARAM)
    ShowWindow = _fn(user32, "ShowWindow", BOOL, HWND, INT)
    SetWindowPos = _fn(user32, "SetWindowPos", BOOL, HWND, HWND, INT, INT, INT, INT, UINT)
    MoveWindow = _fn(user32, "MoveWindow", BOOL, HWND, INT, INT, INT, INT, BOOL)
    GetWindow = _fn(user32, "GetWindow", HWND, HWND, UINT)
    GetWindowLongPtrW = _fn(user32, "GetWindowLongPtrW", ctypes.c_ssize_t, HWND, INT)
    IsWindow = _fn(user32, "IsWindow", BOOL, HWND)
    IsWindowVisible = _fn(user32, "IsWindowVisible", BOOL, HWND)
    IsIconic = _fn(user32, "IsIconic", BOOL, HWND)
    IsHungAppWindow = _fn(user32, "IsHungAppWindow", BOOL, HWND)
    GetWindowRect = _fn(user32, "GetWindowRect", BOOL, HWND, PRECT)
    GetClientRect = _fn(user32, "GetClientRect", BOOL, HWND, PRECT)
    ClientToScreen = _fn(user32, "ClientToScreen", BOOL, HWND, PPOINT)
    EnumWindows = _fn(user32, "EnumWindows", BOOL, WNDENUMPROC, wintypes.LPARAM)
    GetClassNameW = _fn(user32, "GetClassNameW", INT, HWND, wintypes.LPWSTR, INT)
    GetWindowTextW = _fn(user32, "GetWindowTextW", INT, HWND, wintypes.LPWSTR, INT)
    SetLayeredWindowAttributes = _fn(user32, "SetLayeredWindowAttributes", BOOL, HWND,
                                     wintypes.COLORREF, ctypes.c_ubyte, DWORD)
    SetWindowRgn = _fn(user32, "SetWindowRgn", INT, HWND, HANDLE, BOOL)
    GetWindowRgn = _fn(user32, "GetWindowRgn", INT, HWND, HANDLE)
    InvalidateRect = _fn(user32, "InvalidateRect", BOOL, HWND, ctypes.c_void_p, BOOL)
    BeginPaint = _fn(user32, "BeginPaint", HANDLE, HWND, ctypes.POINTER(PAINTSTRUCT))
    EndPaint = _fn(user32, "EndPaint", BOOL, HWND, ctypes.POINTER(PAINTSTRUCT))
    FillRect = _fn(user32, "FillRect", INT, HANDLE, PRECT, HANDLE)
    RegisterHotKey = _fn(user32, "RegisterHotKey", BOOL, HWND, INT, UINT, UINT)
    UnregisterHotKey = _fn(user32, "UnregisterHotKey", BOOL, HWND, INT)
    GetMessageW = _fn(user32, "GetMessageW", BOOL, PMSG, HWND, UINT, UINT)
    TranslateMessage = _fn(user32, "TranslateMessage", BOOL, PMSG)
    DispatchMessageW = _fn(user32, "DispatchMessageW", LRESULT, PMSG)
    PostQuitMessage = _fn(user32, "PostQuitMessage", None, INT)
    SetTimer = _fn(user32, "SetTimer", ctypes.c_size_t, HWND, ctypes.c_size_t, UINT, ctypes.c_void_p)
    KillTimer = _fn(user32, "KillTimer", BOOL, HWND, ctypes.c_size_t)
    GetCursorPos = _fn(user32, "GetCursorPos", BOOL, PPOINT)
    WindowFromPoint = _fn(user32, "WindowFromPoint", HWND, wintypes.POINT)
    GetAncestor = _fn(user32, "GetAncestor", HWND, HWND, UINT)
    MonitorFromWindow = _fn(user32, "MonitorFromWindow", HANDLE, HWND, DWORD)
    LoadCursorW = _fn(user32, "LoadCursorW", HANDLE, wintypes.HINSTANCE, ctypes.c_void_p)
    OpenClipboard = _fn(user32, "OpenClipboard", BOOL, HWND)
    EmptyClipboard = _fn(user32, "EmptyClipboard", BOOL)
    SetClipboardData = _fn(user32, "SetClipboardData", HANDLE, UINT, HANDLE)
    CloseClipboard = _fn(user32, "CloseClipboard", BOOL)
    SetProcessDpiAwarenessContext = _opt(user32, "SetProcessDpiAwarenessContext", BOOL, ctypes.c_void_p)
    SetProcessDPIAware = _opt(user32, "SetProcessDPIAware", BOOL)

    CreateSolidBrush = _fn(gdi32, "CreateSolidBrush", HANDLE, wintypes.COLORREF)
    DeleteObject = _fn(gdi32, "DeleteObject", BOOL, HANDLE)
    CreateRectRgn = _fn(gdi32, "CreateRectRgn", HANDLE, INT, INT, INT, INT)
    CombineRgn = _fn(gdi32, "CombineRgn", INT, HANDLE, HANDLE, HANDLE, INT)
    EqualRgn = _fn(gdi32, "EqualRgn", BOOL, HANDLE, HANDLE)

    GetModuleHandleW = _fn(kernel32, "GetModuleHandleW", wintypes.HMODULE, wintypes.LPCWSTR)
    GlobalAlloc = _fn(kernel32, "GlobalAlloc", HANDLE, UINT, ctypes.c_size_t)
    GlobalLock = _fn(kernel32, "GlobalLock", ctypes.c_void_p, HANDLE)
    GlobalUnlock = _fn(kernel32, "GlobalUnlock", BOOL, HANDLE)
    GlobalFree = _fn(kernel32, "GlobalFree", HANDLE, HANDLE)
    SetConsoleCtrlHandler = _fn(kernel32, "SetConsoleCtrlHandler", BOOL, HANDLER_ROUTINE, BOOL)

    DwmGetWindowAttribute = _fn(dwmapi, "DwmGetWindowAttribute", ctypes.c_long,
                                HWND, DWORD, ctypes.c_void_p, DWORD)
    GetDpiForMonitor = _opt(shcore, "GetDpiForMonitor", ctypes.c_long, HANDLE, INT,
                            ctypes.POINTER(UINT), ctypes.POINTER(UINT))
    SetProcessDpiAwareness = _opt(shcore, "SetProcessDpiAwareness", ctypes.c_long, INT)

    MagInitialize = _fn(magdll, "MagInitialize", BOOL)
    MagUninitialize = _fn(magdll, "MagUninitialize", BOOL)
    MagSetWindowSource = _fn(magdll, "MagSetWindowSource", BOOL, HWND, wintypes.RECT)
    MagSetWindowTransform = _fn(magdll, "MagSetWindowTransform", BOOL, HWND, ctypes.POINTER(MAGTRANSFORM))
    MagSetColorEffect = _fn(magdll, "MagSetColorEffect", BOOL, HWND, ctypes.POINTER(MAGCOLOREFFECT))
    MagSetWindowFilterList = _fn(magdll, "MagSetWindowFilterList", BOOL, HWND, DWORD, INT,
                                 ctypes.POINTER(HWND))

    class BITMAPINFOHEADER(ctypes.Structure):
        _fields_ = [("biSize", DWORD), ("biWidth", wintypes.LONG), ("biHeight", wintypes.LONG),
                    ("biPlanes", wintypes.WORD), ("biBitCount", wintypes.WORD), ("biCompression", DWORD),
                    ("biSizeImage", DWORD), ("biXPelsPerMeter", wintypes.LONG),
                    ("biYPelsPerMeter", wintypes.LONG), ("biClrUsed", DWORD), ("biClrImportant", DWORD)]

    class BITMAPINFO(ctypes.Structure):
        _fields_ = [("bmiHeader", BITMAPINFOHEADER), ("bmiColors", DWORD * 3)]

    class BLENDFUNCTION(ctypes.Structure):
        _fields_ = [("BlendOp", ctypes.c_ubyte), ("BlendFlags", ctypes.c_ubyte),
                    ("SourceConstantAlpha", ctypes.c_ubyte), ("AlphaFormat", ctypes.c_ubyte)]

    GetAsyncKeyState = _fn(user32, "GetAsyncKeyState", ctypes.c_short, INT)
    RedrawWindow = _fn(user32, "RedrawWindow", BOOL, HWND, ctypes.c_void_p, HANDLE, UINT)
    DwmSetWindowAttribute = _fn(dwmapi, "DwmSetWindowAttribute", ctypes.c_long, HWND, DWORD,
                                ctypes.c_void_p, DWORD)
    GetDC = _fn(user32, "GetDC", HANDLE, HWND)
    ReleaseDC = _fn(user32, "ReleaseDC", INT, HWND, HANDLE)
    UpdateLayeredWindow = _fn(user32, "UpdateLayeredWindow", BOOL, HWND, HANDLE, PPOINT,
                              ctypes.POINTER(wintypes.SIZE), HANDLE, PPOINT, wintypes.COLORREF,
                              ctypes.POINTER(BLENDFUNCTION), DWORD)
    CreateCompatibleDC = _fn(gdi32, "CreateCompatibleDC", HANDLE, HANDLE)
    DeleteDC = _fn(gdi32, "DeleteDC", BOOL, HANDLE)
    SelectObject = _fn(gdi32, "SelectObject", HANDLE, HANDLE, HANDLE)
    CreateDIBSection = _fn(gdi32, "CreateDIBSection", HANDLE, HANDLE, ctypes.POINTER(BITMAPINFO), UINT,
                           ctypes.POINTER(ctypes.c_void_p), HANDLE, DWORD)

    APP_OWNERS = {}

    def _wndproc(hwnd, msg, wparam, lparam):
        try:
            if hwnd in APP_OWNERS:
                if msg == WM_HOTKEY:
                    APP_OWNERS[hwnd].on_hotkey(wparam)
                    return 0
                if msg == WM_TIMER and wparam == TIMER_ID:
                    APP_OWNERS[hwnd].tick()
                    return 0
            if msg == WM_MOUSEACTIVATE:
                return MA_NOACTIVATE
        except Exception as e:
            print("  ! 처리 오류:", e)
        return DefWindowProcW(hwnd, msg, wparam, lparam)

    WNDPROC_REF = WNDPROC(_wndproc)


def get_class(hwnd):
    buf = ctypes.create_unicode_buffer(256)
    GetClassNameW(hwnd, buf, 256)
    return buf.value


def get_title(hwnd):
    buf = ctypes.create_unicode_buffer(512)
    GetWindowTextW(hwnd, buf, 512)
    return buf.value


def is_cloaked(hwnd):
    val = wintypes.DWORD(0)
    if DwmGetWindowAttribute(hwnd, DWMWA_CLOAKED, ctypes.byref(val), ctypes.sizeof(val)) == 0:
        return val.value != 0
    return False


def get_base_rect(hwnd, base):
    rc = wintypes.RECT()
    if base == "client":
        if not GetClientRect(hwnd, ctypes.byref(rc)):
            return None
        pt = wintypes.POINT(0, 0)
        if not ClientToScreen(hwnd, ctypes.byref(pt)):
            return None
        return (pt.x, pt.y, pt.x + rc.right, pt.y + rc.bottom)
    if DwmGetWindowAttribute(hwnd, DWMWA_EXTENDED_FRAME_BOUNDS, ctypes.byref(rc), ctypes.sizeof(rc)) == 0:
        return (rc.left, rc.top, rc.right, rc.bottom)
    if GetWindowRect(hwnd, ctypes.byref(rc)):
        return (rc.left, rc.top, rc.right, rc.bottom)
    return None


def get_scale(hwnd):
    if GetDpiForMonitor:
        mon = MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST)
        dx, dy = wintypes.UINT(0), wintypes.UINT(0)
        if mon and GetDpiForMonitor(mon, MDT_EFFECTIVE_DPI, ctypes.byref(dx), ctypes.byref(dy)) == 0 and dx.value:
            return dx.value / 96.0
    return 1.0


def window_rect(hwnd):
    rc = wintypes.RECT()
    if GetWindowRect(hwnd, ctypes.byref(rc)):
        return (rc.left, rc.top, rc.right, rc.bottom)
    return None


def copy_rgn(src):
    dst = CreateRectRgn(0, 0, 0, 0)
    CombineRgn(dst, src, None, RGN_COPY)
    return dst


def region_union(rects):
    rgn = CreateRectRgn(0, 0, 0, 0)
    for left, top, right, bottom in rects:
        part = CreateRectRgn(left, top, right, bottom)
        CombineRgn(rgn, rgn, part, RGN_OR)
        DeleteObject(part)
    return rgn


def region_minus(width, height, holes):
    rgn = CreateRectRgn(0, 0, width, height)
    for left, top, right, bottom in holes:
        part = CreateRectRgn(left, top, right, bottom)
        CombineRgn(rgn, rgn, part, RGN_DIFF)
        DeleteObject(part)
    return rgn


def copy_to_clipboard(text, owner):
    data = text.encode("utf-16-le") + b"\x00\x00"
    if not OpenClipboard(owner):
        return False
    try:
        EmptyClipboard()
        hmem = GlobalAlloc(GMEM_MOVEABLE, len(data))
        if not hmem:
            return False
        ptr = GlobalLock(hmem)
        if not ptr:
            GlobalFree(hmem)
            return False
        ctypes.memmove(ptr, data, len(data))
        GlobalUnlock(hmem)
        if not SetClipboardData(CF_UNICODETEXT, hmem):
            GlobalFree(hmem)
            return False
        return True
    finally:
        CloseClipboard()


def set_dpi_awareness():
    if SetProcessDpiAwarenessContext and SetProcessDpiAwarenessContext(ctypes.c_void_p(-4)):
        return
    if SetProcessDpiAwareness and SetProcessDpiAwareness(2) == 0:
        return
    if SetProcessDPIAware:
        SetProcessDPIAware()


def register_window_class():
    wc = WNDCLASSEXW()
    wc.cbSize = ctypes.sizeof(WNDCLASSEXW)
    wc.lpfnWndProc = WNDPROC_REF
    wc.hInstance = GetModuleHandleW(None)
    wc.hCursor = LoadCursorW(None, ctypes.c_void_p(IDC_ARROW))
    wc.lpszClassName = CLASS_NAME
    if not RegisterClassExW(ctypes.byref(wc)):
        err = ctypes.get_last_error()
        if err != ERROR_CLASS_ALREADY_EXISTS:
            raise ctypes.WinError(err)


def set_color_effect(mag, matrix):
    eff = MAGCOLOREFFECT()
    for i in range(5):
        for j in range(5):
            eff.transform[i][j] = matrix[i][j]
    MagSetColorEffect(mag, ctypes.byref(eff))


def cursor_pos():
    pt = wintypes.POINT()
    GetCursorPos(ctypes.byref(pt))
    return pt.x, pt.y


def key_down(vk):
    return bool(GetAsyncKeyState(vk) & KEY_DOWN)


def visible_top_windows(exclude=()):
    found = []
    skip = set(exclude)

    def callback(hwnd, _lparam):
        try:
            if hwnd not in skip and IsWindowVisible(hwnd) and not IsIconic(hwnd) and not is_cloaked(hwnd):
                found.append(hwnd)
        except Exception:
            pass
        return True

    EnumWindows(WNDENUMPROC(callback), 0)
    return found


def top_window_at(x, y, exclude=()):
    for hwnd in visible_top_windows(exclude):
        if get_class(hwnd) == CLASS_NAME:
            continue
        r = window_rect(hwnd)
        if r and r[0] <= x < r[2] and r[1] <= y < r[3]:
            return hwnd
    return None


def find_targets(profile, exclude=()):
    probe = dict(profile, enabled=True)
    need_title = bool((profile.get("match") or {}).get("title_contains"))
    return [hwnd for hwnd in visible_top_windows(exclude)
            if match_profile(probe, get_class(hwnd), get_title(hwnd) if need_title else "")]


def base_geometry(hwnd, base, dpi_scale=True):
    rect = get_base_rect(hwnd, base or "frame")
    if not rect:
        return None
    L, T, R, B = rect
    return L, T, R - L, B - T, (get_scale(hwnd) if dpi_scale else 1.0)


def system_dark_mode():
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                            r"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize") as key:
            value, _ = winreg.QueryValueEx(key, "AppsUseLightTheme")
        return value == 0
    except (OSError, ImportError):
        return False


def get_dwm_dword(hwnd, attr):
    val = wintypes.DWORD(0)
    if DwmGetWindowAttribute(hwnd, attr, ctypes.byref(val), ctypes.sizeof(val)) == 0:
        return val.value
    return None


def set_dwm_dword(hwnd, attr, value):
    val = wintypes.DWORD(value)
    return DwmSetWindowAttribute(hwnd, attr, ctypes.byref(val), ctypes.sizeof(val)) == 0


def frame_changed(hwnd):
    SetWindowPos(hwnd, None, 0, 0, 0, 0,
                 SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE | SWP_FRAMECHANGED)


def render_layered(hwnd, x, y, w, h, rects):
    screen = GetDC(None)
    mem = CreateCompatibleDC(screen)
    bmi = BITMAPINFO()
    bmi.bmiHeader.biSize = ctypes.sizeof(BITMAPINFOHEADER)
    bmi.bmiHeader.biWidth = w
    bmi.bmiHeader.biHeight = -h
    bmi.bmiHeader.biPlanes = 1
    bmi.bmiHeader.biBitCount = 32
    bmi.bmiHeader.biCompression = BI_RGB
    bits = ctypes.c_void_p()
    bitmap = CreateDIBSection(screen, ctypes.byref(bmi), DIB_RGB_COLORS, ctypes.byref(bits), None, 0)
    try:
        if not bitmap or not bits.value:
            return False
        old = SelectObject(mem, bitmap)
        ctypes.memset(bits.value, 0, w * h * 4)
        for (left, top, right, bottom), color, alpha in rects:
            r, g, b = color & 0xFF, (color >> 8) & 0xFF, (color >> 16) & 0xFF
            row = bytes((b * alpha // 255, g * alpha // 255, r * alpha // 255, alpha)) * (right - left)
            for yy in range(top, bottom):
                ctypes.memmove(bits.value + (yy * w + left) * 4, row, len(row))
        blend = BLENDFUNCTION(0, 0, 255, AC_SRC_ALPHA)
        ok = UpdateLayeredWindow(hwnd, screen, ctypes.byref(wintypes.POINT(x, y)),
                                 ctypes.byref(wintypes.SIZE(w, h)), mem, ctypes.byref(wintypes.POINT(0, 0)),
                                 0, ctypes.byref(blend), ULW_ALPHA)
        SelectObject(mem, old)
        return bool(ok)
    finally:
        if bitmap:
            DeleteObject(bitmap)
        DeleteDC(mem)
        ReleaseDC(None, screen)


class Overlay:
    def __init__(self, app, target, pi):
        self.app, self.target, self.pi = app, target, pi
        self.profile = app.cfg["profiles"][pi]
        self.hinst = GetModuleHandleW(None)
        self.windows = []
        self.matrix = app.profile_matrix(pi)
        click = WS_EX_LAYERED | WS_EX_TRANSPARENT | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE
        try:
            self.host = self._popup(click, "window_color_change_filter", 255)
            self.mag = self._magnifier(self.host, "window_color_change_mag", self.matrix)
            ex = WS_EX_LAYERED | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE
            if app.cfg["mask"].get("click_through", True):
                ex |= WS_EX_TRANSPARENT
            self.mask = self._popup(ex, "window_color_change_mask", None)
        except OSError:
            for hw in reversed(self.windows):
                DestroyWindow(hw)
            raise
        self.see_groups = {}
        self.host_geom = None
        self.mask_geom = None
        self.last_pos = None
        self.vis = {self.host: False, self.mask: False}
        self.hole_applied = False
        self.hole_orig = None
        self.hole_expected = None
        self.hole_key = None
        self.dwm_state = None

    def _popup(self, ex, title, alpha):
        hw = CreateWindowExW(ex, CLASS_NAME, title, WS_POPUP, 0, 0, 1, 1, None, None, self.hinst, None)
        if not hw:
            raise ctypes.WinError(ctypes.get_last_error())
        self.windows.append(hw)
        if alpha is not None:
            SetLayeredWindowAttributes(hw, 0, alpha, LWA_ALPHA)
        return hw

    def _magnifier(self, parent, title, matrix):
        hw = CreateWindowExW(0, "Magnifier", title, WS_CHILD | WS_VISIBLE, 0, 0, 1, 1,
                             parent, None, self.hinst, None)
        if not hw:
            raise ctypes.WinError(ctypes.get_last_error())
        tf = MAGTRANSFORM()
        tf.v[0][0] = tf.v[1][1] = tf.v[2][2] = 1.0
        MagSetWindowTransform(hw, ctypes.byref(tf))
        set_color_effect(hw, matrix)
        return hw

    def all_windows(self):
        return [self.host, self.mask] + [g["host"] for g in self.see_groups.values()]

    def set_matrix(self, matrix):
        self.matrix = matrix
        set_color_effect(self.mag, matrix)
        for g in self.see_groups.values():
            g["effect"] = None

    def _see_group(self, key):
        g = self.see_groups.get(key)
        if g is None:
            alpha = 255 if key == HOLE_COVER else key
            click = WS_EX_LAYERED | WS_EX_TRANSPARENT | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE
            host = self._popup(click, "window_color_change_see", alpha)
            try:
                mag = self._magnifier(host, "window_color_change_see_mag", IDENTITY)
            except OSError:
                self.windows.remove(host)
                DestroyWindow(host)
                raise
            g = {"host": host, "mag": mag, "geom": None, "effect": False}
            self.see_groups[key] = g
            self.vis[host] = False
            self.app.rebuild_own()
        return g

    def _drop_see_group(self, alpha):
        g = self.see_groups.pop(alpha)
        self.vis.pop(g["host"], None)
        if g["host"] in self.windows:
            self.windows.remove(g["host"])
        DestroyWindow(g["host"])

    def _hide(self, hwnd):
        if self.vis.get(hwnd):
            ShowWindow(hwnd, SW_HIDE)
            self.vis[hwnd] = False

    def hide(self):
        for hw in self.all_windows():
            self._hide(hw)

    def destroy(self):
        self.restore_holes()
        for alpha in list(self.see_groups):
            self._drop_see_group(alpha)
        DestroyWindow(self.mask)
        DestroyWindow(self.host)

    def apply_holes(self, size, rects):
        target = self.target
        if IsHungAppWindow(target):
            return
        if not self.hole_applied:
            current = CreateRectRgn(0, 0, 0, 0)
            if GetWindowRgn(target, current) == 0:
                DeleteObject(current)
                current = None
            self.hole_orig = current
            if self.app.hole_dwm_fix or self.app.hole_hide_border:
                self.dwm_prepare(self.app.hole_dwm_fix, self.app.hole_hide_border)
        rgn = copy_rgn(self.hole_orig) if self.hole_orig else CreateRectRgn(0, 0, size[0], size[1])
        for left, top, right, bottom in rects:
            part = CreateRectRgn(left, top, right, bottom)
            CombineRgn(rgn, rgn, part, RGN_DIFF)
            DeleteObject(part)
        if self.hole_expected:
            DeleteObject(self.hole_expected)
        self.hole_expected = copy_rgn(rgn)
        SetWindowRgn(target, rgn, True)
        if self.dwm_state is not None:
            RedrawWindow(target, None, None, RDW_INVALIDATE | RDW_FRAME | RDW_ALLCHILDREN)
        self.hole_applied = True
        self.hole_key = (size, rects)

    def restore_holes(self):
        if not self.hole_applied:
            return
        alive = IsWindow(self.target)
        if alive and IsHungAppWindow(self.target):
            return
        if alive:
            SetWindowRgn(self.target, self.hole_orig, True)
            self.dwm_restore()
        elif self.hole_orig:
            DeleteObject(self.hole_orig)
        self.dwm_state = None
        if self.hole_expected:
            DeleteObject(self.hole_expected)
        self.hole_orig = None
        self.hole_expected = None
        self.hole_applied = False
        self.hole_key = None

    def dwm_prepare(self, full, border):
        target = self.target
        state = {}
        if full:
            enabled = get_dwm_dword(target, DWMWA_NCRENDERING_ENABLED)
            state.update({"nc_disabled": enabled == 0,
                          "backdrop": get_dwm_dword(target, DWMWA_SYSTEMBACKDROP_TYPE),
                          "corner": get_dwm_dword(target, DWMWA_WINDOW_CORNER_PREFERENCE)})
            set_dwm_dword(target, DWMWA_NCRENDERING_POLICY, DWMNCRP_DISABLED)
            if state["backdrop"] is not None:
                set_dwm_dword(target, DWMWA_SYSTEMBACKDROP_TYPE, DWMSBT_NONE)
            if state["corner"] is not None:
                set_dwm_dword(target, DWMWA_WINDOW_CORNER_PREFERENCE, DWMWCP_DONOTROUND)
            frame_changed(target)
        if border:
            original = get_dwm_dword(target, DWMWA_BORDER_COLOR)
            if set_dwm_dword(target, DWMWA_BORDER_COLOR, DWMWA_COLOR_NONE):
                state["border"] = DWMWA_COLOR_DEFAULT if original is None else original
        self.dwm_state = state

    def dwm_restore(self):
        state, self.dwm_state = self.dwm_state, None
        if state is None:
            return
        target = self.target
        if "border" in state:
            set_dwm_dword(target, DWMWA_BORDER_COLOR, state["border"])
        if "nc_disabled" in state:
            set_dwm_dword(target, DWMWA_NCRENDERING_POLICY,
                          DWMNCRP_DISABLED if state["nc_disabled"] else DWMNCRP_USEWINDOWSTYLE)
            if state["backdrop"] is not None:
                set_dwm_dword(target, DWMWA_SYSTEMBACKDROP_TYPE, state["backdrop"])
            if state["corner"] is not None:
                set_dwm_dword(target, DWMWA_WINDOW_CORNER_PREFERENCE, state["corner"])
            frame_changed(target)
        RedrawWindow(target, None, None, RDW_INVALIDATE | RDW_FRAME | RDW_ALLCHILDREN)

    def holes_intact(self):
        current = CreateRectRgn(0, 0, 0, 0)
        try:
            return GetWindowRgn(self.target, current) != 0 and bool(EqualRgn(current, self.hole_expected))
        finally:
            DeleteObject(current)

    def _stacked(self, hwnds):
        below = self.target
        for hw in hwnds:
            above = GetWindow(below, GW_HWNDPREV)
            while above and above != hw and above in self.app.own and not IsWindowVisible(above):
                above = GetWindow(above, GW_HWNDPREV)
            if above != hw:
                return False
            below = hw
        return True

    def _enabled_rects(self, kind, W, H, s):
        for i, spec in enumerate(self.profile.get(kind) or []):
            if not self.app.area_enabled.get((kind, self.pi, i), True):
                continue
            r = resolve_rect(spec, W, H, s)
            if r:
                yield spec, r

    def update(self):
        app, target = self.app, self.target
        if not IsWindow(target):
            return False
        if not IsWindowVisible(target) or IsIconic(target) or is_cloaked(target):
            self.hide()
            return True
        base = get_base_rect(target, self.profile.get("base") or "frame")
        if not base:
            self.hide()
            return True
        L, T, R, B = base
        W, H = R - L, B - T
        if W < 2 or H < 2:
            self.hide()
            return True
        s = get_scale(target) if app.dpi_scale else 1.0
        fx = app.fx

        hole_rects = [r for _, r in self._enabled_rects("hole_areas", W, H, s)] if fx["hole"] else []
        wr = window_rect(target) if hole_rects else None
        if wr:
            ox, oy = L - wr[0], T - wr[1]
            size = (wr[2] - wr[0], wr[3] - wr[1])
            rects = tuple((0 if a <= 0 else a + ox, 0 if b <= 0 else b + oy,
                           size[0] if c >= W else c + ox, size[1] if d >= H else d + oy)
                          for a, b, c, d in hole_rects)
            if (size, rects) != self.hole_key or (app.check_holes and not self.holes_intact()):
                self.apply_holes(size, rects)
        else:
            self.restore_holes()

        host_geom = None
        if fx["filter"]:
            area = resolve_rect(self.profile.get("filter_area") or {}, W, H, s)
            if area:
                fl, ft, fr, fb = area
                cuts = [resolve_rect(spec, W, H, s) for spec in self.profile.get("filter_holes") or []]
                if app.hole_cover or not app.hole_use_filter:
                    cuts += hole_rects
                holes = [(h[0] - fl, h[1] - ft, h[2] - fl, h[3] - ft) for h in cuts if h]
                host_geom = (L + fl, T + ft, fr - fl, fb - ft, tuple(holes))

        see_rects = {}
        if fx["see"]:
            default_alpha = area_alpha(app.cfg["see_through"], 255)
            for spec, r in self._enabled_rects("see_through_areas", W, H, s):
                see_rects.setdefault(area_alpha(spec, default_alpha), []).append(r)
        keys = sorted(see_rects)
        if hole_rects and app.hole_cover:
            see_rects[HOLE_COVER] = hole_rects
            keys.append(HOLE_COVER)
        dropped = [k for k in self.see_groups if k not in see_rects]
        for key in dropped:
            self._drop_see_group(key)
        if dropped:
            app.rebuild_own()

        mask_geom = None
        if fx["mask"]:
            mcfg = app.cfg["mask"]
            default_color = mcfg.get("color") or "#1B1F27"
            default_alpha = area_alpha(mcfg, 255)
            rects = [(r, parse_color(spec.get("color") or default_color), area_alpha(spec, default_alpha))
                     for spec, r in self._enabled_rects("masks", W, H, s)]
            if rects:
                mask_geom = (W, H, tuple(rects))

        if host_geom is None:
            self._hide(self.host)
        if mask_geom is None:
            self._hide(self.mask)

        changed = False
        if (L, T, W, H) != self.last_pos:
            self.last_pos = (L, T, W, H)
            changed = True
        if host_geom is not None and host_geom != self.host_geom:
            x, y, w, h, holes = host_geom
            MoveWindow(self.mag, 0, 0, w, h, False)
            if holes:
                SetWindowRgn(self.host, region_minus(w, h, holes), True)
            elif self.host_geom and self.host_geom[4]:
                SetWindowRgn(self.host, None, True)
            self.host_geom = host_geom
            changed = True
        see_stack = []
        for key in keys:
            g = self._see_group(key)
            geom = (L, T, W, H, tuple(see_rects[key]))
            if geom != g["geom"]:
                MoveWindow(g["mag"], 0, 0, W, H, False)
                SetWindowRgn(g["host"], region_union(see_rects[key]), True)
                g["geom"] = geom
                changed = True
            use = app.hole_use_filter if key == HOLE_COVER else app.see_use_filter
            effect = bool(use and fx["filter"])
            if effect != g["effect"]:
                set_color_effect(g["mag"], self.matrix if effect else IDENTITY)
                g["effect"] = effect
            see_stack.append((g["host"], (L, T, W, H)))
        if mask_geom is not None and mask_geom != self.mask_geom:
            render_layered(self.mask, L, T, W, H, mask_geom[2])
            self.mask_geom = mask_geom
            changed = True

        stack = []
        if host_geom is not None:
            stack.append((self.host, host_geom[:4]))
        stack += see_stack
        if mask_geom is not None:
            stack.append((self.mask, (L, T, W, H)))
        if stack and (changed or not all(self.vis.get(hw) for hw, _ in stack)
                      or not self._stacked([hw for hw, _ in stack])):
            above = GetWindow(target, GW_HWNDPREV)
            while above and above in app.own:
                above = GetWindow(above, GW_HWNDPREV)
            if above and GetWindowLongPtrW(above, GWL_EXSTYLE) & WS_EX_TOPMOST:
                above = None
            after = above or HWND_TOP
            for hw, (x, y, w, h) in stack:
                SetWindowPos(hw, after, x, y, w, h, SWP_NOACTIVATE | SWP_NOOWNERZORDER | SWP_SHOWWINDOW)
                self.vis[hw] = True

        mags = []
        if host_geom is not None:
            mags.append((self.mag, host_geom[:4]))
        for key in keys:
            mags.append((self.see_groups[key]["mag"], (L, T, W, H)))
        for mag, (x, y, w, h) in mags:
            MagSetWindowSource(mag, wintypes.RECT(x, y, x + w, y + h))
            InvalidateRect(mag, None, True)
        return True


class App:
    def __init__(self, path):
        self.path = path
        self.cfg = None
        self.overlays = {}
        self.own = set()
        self.hotkeys = {}
        self.hotkey_lines = []
        self.hotkey_errors = []
        self.timer = False
        self.pick_first = None
        self.tick_count = 0
        self.last_error = None
        self.check_holes = False
        self.on_change = None
        self.notify_func = None
        self.on_quit = None
        self.on_edit_request = None
        self.peeking = False
        self.suspended = False
        self.peek_vk = None
        self.runtime_filter = None
        self.cycle_index = -1
        self.preview_cfg = None
        self.rule_states = {}
        self.in_rules = False
        self.fx = {"filter": False, "mask": False, "see": False, "hole": False}
        try:
            self.global_cfg = load_global()
        except (OSError, ValueError) as e:
            print("  ! 전역 설정 오류, 기본값 사용:", e)
            self.global_cfg = merge_global({})
        self.msg_hwnd = CreateWindowExW(0, CLASS_NAME, "window_color_change_msg", WS_POPUP,
                                        0, 0, 0, 0, None, None, GetModuleHandleW(None), None)
        if not self.msg_hwnd:
            raise ctypes.WinError(ctypes.get_last_error())
        APP_OWNERS[self.msg_hwnd] = self
        try:
            self.load()
        except Exception:
            APP_OWNERS.pop(self.msg_hwnd, None)
            DestroyWindow(self.msg_hwnd)
            self.msg_hwnd = None
            raise
        self.print_help()

    def load(self):
        cfg = check_config(load_config(self.path))
        profiles = cfg.get("profiles") or []
        self.cfg = cfg
        self.dpi_scale = bool(cfg.get("dpi_scale", True))
        self.refresh_ms = max(10, int(cfg.get("refresh_ms", 16)))
        self.discover_every = max(1, 250 // self.refresh_ms)
        self.rules_every = max(1, 1000 // self.refresh_ms)
        self.filter_on = bool(cfg["filter"].get("start_on", True))
        self.mask_on = bool(cfg["mask"].get("start_on", True))
        self.see_on = bool(cfg["see_through"].get("start_on", True))
        self.see_use_filter = bool(cfg["see_through"].get("use_filter", False))
        self.hole_on = bool(cfg["hole"].get("start_on", True))
        self.hole_use_filter = bool(cfg["hole"].get("use_filter", False))
        self.hole_cover = bool(cfg["hole"].get("cover", True))
        self.hole_dwm_fix = bool(cfg["hole"].get("dwm_fix", False))
        self.hole_hide_border = bool(cfg["hole"].get("hide_border", True))
        self.runtime_filter = None
        self.cycle_index = -1
        self.preview_cfg = None
        self.peeking = False
        self.area_enabled = {(kind, pi, i): bool(a.get("enabled", True))
                             for pi, p in enumerate(profiles)
                             for kind in AREA_KINDS
                             for i, a in enumerate(p.get(kind) or [])}
        self.register_hotkeys()
        self.restart_timer()

    def set_name(self):
        return set_name_of(self.path)

    def restart_timer(self):
        if self.timer:
            KillTimer(self.msg_hwnd, TIMER_ID)
        self.timer = bool(SetTimer(self.msg_hwnd, TIMER_ID, self.refresh_ms, None))

    def notify(self, title, text):
        print("[%s] %s" % (title, text))
        if self.notify_func:
            try:
                self.notify_func(title, text)
            except Exception:
                pass

    def changed(self):
        if self.on_change:
            try:
                self.on_change()
            except Exception:
                pass

    def on_hotkey(self, hid):
        action = self.hotkeys.get(hid)
        if action:
            try:
                action()
            except Exception as e:
                self.notify("단축키 처리 오류", str(e))

    def _register(self, hid, spec, action, label):
        if not spec:
            return
        try:
            mods, vk = parse_hotkey(spec)
        except ValueError as e:
            self.hotkey_errors.append("형식 오류 '%s': %s" % (spec, e))
            return
        if RegisterHotKey(self.msg_hwnd, hid, mods, vk):
            self.hotkeys[hid] = action
            self.hotkey_lines.append("  %-14s %s" % (format_hotkey(spec), label))
        else:
            self.hotkey_errors.append("등록 실패 '%s' (%s) - 이미 다른 곳에서 쓰는 조합일 수 있습니다" % (spec, label))

    def register_hotkeys(self):
        for hid in list(self.hotkeys):
            UnregisterHotKey(self.msg_hwnd, hid)
        self.hotkeys = {}
        self.hotkey_lines = []
        self.hotkey_errors = []
        hk = self.cfg.get("hotkeys") or {}
        self._register(1, hk.get("filter"), self.toggle_filter, "필터 켜기/끄기")
        self._register(2, hk.get("mask"), self.toggle_mask, "mask 전체 켜기/끄기")
        self._register(6, hk.get("see_through"), self.toggle_see, "see_through 전체 켜기/끄기")
        self._register(7, hk.get("hole"), self.toggle_hole, "hole 전체 켜기/끄기")
        self._register(8, hk.get("peek"), self.start_peek, "누르는 동안 원래 화면")
        self._register(9, hk.get("cycle"), self.cycle_next, "필터 색 바꾸기")
        self._register(10, hk.get("edit"), self.request_edit, "영역 편집 (트레이 앱)")
        self._register(3, hk.get("pick"), self.pick, "좌표 따기 (같은 창에서 두 번 = 영역 JSON)")
        self._register(4, hk.get("reload"), self.reload, "설정 다시 읽기")
        self._register(5, hk.get("quit"), self.quit, "종료")
        try:
            self.peek_vk = parse_hotkey(hk["peek"])[1] if hk.get("peek") else None
        except ValueError:
            self.peek_vk = None
        groups = {}
        for pi, p in enumerate(self.cfg.get("profiles") or []):
            for kind in AREA_KINDS:
                for i, a in enumerate(p.get(kind) or []):
                    spec = a.get("hotkey")
                    if not spec:
                        continue
                    try:
                        key = parse_hotkey(spec)
                    except ValueError as e:
                        self.hotkey_errors.append("형식 오류 '%s': %s" % (spec, e))
                        continue
                    g = groups.setdefault(key, {"spec": spec, "keys": [], "names": []})
                    g["keys"].append((kind, pi, i))
                    g["names"].append(a.get("name") or "%s %d" % (AREA_LABELS[kind], i + 1))
        hid = 100
        for g in groups.values():
            label = ", ".join(g["names"])
            self._register(hid, g["spec"], lambda k=g["keys"], l=label: self.toggle_areas(k, l),
                           "영역 [%s] 켜기/끄기" % label)
            hid += 1
        if self.hotkey_errors:
            self.notify("단축키", "\n".join(self.hotkey_errors))

    def print_help(self):
        print("=" * 64)
        print(" 윈도우 컬러 체인지 실행 중   설정 세트: %s (%s)" % (self.set_name(), self.path))
        for line in self.hotkey_lines:
            print(line)
        print(" 현재: %s / 필터 색: %s" % (self.status_text(), self.filter_label()))
        print("=" * 64)

    def status_text(self):
        on = lambda v: "켬" if v else "끔"
        return "[%s] 필터 %s / mask %s / see_through %s / hole %s" % (
            self.set_name(), on(self.filter_on), on(self.mask_on), on(self.see_on), on(self.hole_on))

    def filter_label(self):
        entries = self.cycle_entries()
        if self.cycle_index is not None and 0 <= self.cycle_index < len(entries):
            return cycle_label(entries[self.cycle_index])
        if self.runtime_filter:
            return describe_filter(self.runtime_filter)
        return describe_filter(self.cfg["filter"])

    def profile_matrix(self, pi):
        for cfg in (self.preview_cfg, self.cfg):
            if not cfg:
                continue
            profiles = cfg.get("profiles") or []
            pf = profiles[pi].get("filter") if 0 <= pi < len(profiles) else None
            try:
                return filter_matrix(effective_filter(cfg.get("filter") or {}, self.runtime_filter, pf))
            except (ValueError, TypeError, KeyError, IndexError):
                continue
        return IDENTITY

    def refresh_matrices(self):
        for ov in self.overlays.values():
            ov.set_matrix(self.profile_matrix(ov.pi))
        self.tick()

    def preview(self, cfg):
        self.preview_cfg = cfg
        self.refresh_matrices()

    def cycle_entries(self):
        return list(self.cfg["filter"].get("cycle") or [])

    def set_cycle(self, index, quiet=False):
        entries = self.cycle_entries()
        if index is None or index < 0 or index >= len(entries):
            self.cycle_index, self.runtime_filter = -1, None
        else:
            self.cycle_index = index
            self.runtime_filter = cycle_override(entries[index])
        self.refresh_matrices()
        if not quiet:
            self.notify("필터 색", self.filter_label())
        self.changed()

    def cycle_next(self):
        n = len(self.cycle_entries())
        nxt = 0 if self.cycle_index is None else self.cycle_index + 1
        self.set_cycle(nxt if nxt < n else -1)

    def set_preset(self, name, quiet=False):
        for i, e in enumerate(self.cycle_entries()):
            if e == name:
                return self.set_cycle(i, quiet)
        self.cycle_index = None
        self.runtime_filter = cycle_override(name)
        self.refresh_matrices()
        if not quiet:
            self.notify("필터 색", self.filter_label())
        self.changed()

    def start_peek(self):
        if not self.peeking:
            self.peeking = True
            self.tick()
            self.changed()

    def set_suspended(self, flag):
        self.suspended = bool(flag)
        self.tick()
        self.changed()

    def request_edit(self):
        x, y = cursor_pos()
        hwnd = top_window_at(x, y, self.own)
        if self.on_edit_request:
            self.on_edit_request(hwnd)
        else:
            self.notify("영역 편집", "영역 편집은 트레이 앱에서 사용할 수 있습니다.")

    def _toggled(self, label, value):
        print("[%s] %s" % (label, "켬" if value else "끔"))
        self.tick()
        self.changed()

    def toggle_filter(self):
        self.filter_on = not self.filter_on
        self._toggled("필터", self.filter_on)

    def toggle_mask(self):
        self.mask_on = not self.mask_on
        self._toggled("mask 전체", self.mask_on)

    def toggle_see(self):
        self.see_on = not self.see_on
        self._toggled("see_through 전체", self.see_on)

    def toggle_hole(self):
        self.hole_on = not self.hole_on
        self._toggled("hole 전체", self.hole_on)

    def restore_holes(self):
        for ov in list(self.overlays.values()):
            ov.restore_holes()

    def toggle_areas(self, keys, label):
        new = not all(self.area_enabled.get(k, True) for k in keys)
        for k in keys:
            self.area_enabled[k] = new
        kinds = {k[0] for k in keys}
        states = (("masks", self.mask_on), ("see_through_areas", self.see_on), ("hole_areas", self.hole_on))
        off = [AREA_LABELS[kind] for kind, on in states if kind in kinds and not on]
        note = "  (%s 전체가 꺼져 있어 지금은 안 보입니다)" % "/".join(off) if off else ""
        print("[영역] %s: %s%s" % (label, "켬" if new else "끔", note))
        self.tick()
        self.changed()

    def match_index(self, cls, title):
        for pi, p in enumerate(self.cfg.get("profiles") or []):
            if match_profile(p, cls, title):
                return pi
        return None

    def pick(self):
        pt = wintypes.POINT()
        if not GetCursorPos(ctypes.byref(pt)):
            return
        hw = WindowFromPoint(pt)
        top = GetAncestor(hw, GA_ROOT) if hw else None
        for t, ov in self.overlays.items():
            if top in ov.all_windows():
                top = t
                break
        if not top:
            self.notify("좌표 따기", "마우스 아래에서 창을 찾지 못했습니다.")
            return
        cls, title = get_class(top), get_title(top)
        pi = self.match_index(cls, title)
        profiles = self.cfg.get("profiles") or []
        base_name = (profiles[pi].get("base") or "frame") if pi is not None else "frame"
        base = get_base_rect(top, base_name)
        if not base:
            self.notify("좌표 따기", "창 위치를 읽지 못했습니다.")
            return
        L, T, R, B = base
        W, H = R - L, B - T
        s = get_scale(top) if self.dpi_scale else 1.0
        x, y = pt.x - L, pt.y - T
        if pi is not None:
            where = "프로필 '%s'" % profiles[pi].get("name", pi)
        else:
            where = "일치하는 프로필 없음 - match.class에 위 class 값을 넣으세요"
        print('[좌표] class="%s"  title="%s"  (%s)' % (cls, title, where))
        print("  창 %dx%d, 배율 %.2f, 기준 %s" % (round(W / s), round(H / s), s, base_name))
        print("  왼쪽/위 기준 x=%d, y=%d   오른쪽/아래 기준 x=%d, y=%d"
              % (round(x / s), round(y / s), -round((W - x) / s), -round((H - y) / s)))
        if self.pick_first and self.pick_first[0] == top:
            _, x0, y0 = self.pick_first
            self.pick_first = None
            l, r = sorted((x0, x))
            t, b = sorted((y0, y))
            spec = {"name": "새 영역", "left": edge_value(l, W, s), "top": edge_value(t, H, s),
                    "right": edge_value(r, W, s), "bottom": edge_value(b, H, s)}
            text = json.dumps(spec, ensure_ascii=False)
            copied = bool(self.msg_hwnd) and copy_to_clipboard(text, self.msg_hwnd)
            self.notify("영역 좌표", text + ("\n클립보드에 복사됨" if copied else ""))
        else:
            self.pick_first = (top, x, y)
            self.notify("좌표 따기", 'class="%s"%s\n반대쪽 모서리로 옮겨 한 번 더 누르세요'
                        % (cls, "" if pi is not None else " (일치하는 프로필 없음)"))

    def reload(self):
        print("[설정] 다시 읽는 중...")
        try:
            self.load()
        except Exception as e:
            self.notify("설정 오류", "이전 설정을 유지합니다: %s" % e)
            return False
        for ov in list(self.overlays.values()):
            ov.destroy()
        self.overlays.clear()
        self.own = set()
        self.pick_first = None
        self.tick_count = 0
        self.print_help()
        self.tick()
        self.reassert_rules()
        self.changed()
        return True

    def reload_global(self):
        try:
            self.global_cfg = load_global()
        except (OSError, ValueError) as e:
            self.notify("자동 전환 설정 오류", str(e))
            return False
        self.rule_states = {}
        self.evaluate_rules()
        return True

    def switch_set(self, name):
        path = set_path(name)
        if not os.path.exists(path):
            self.notify("설정 세트", "세트 '%s'을(를) 찾지 못했습니다." % name)
            return False
        old = self.path
        self.path = path
        if not self.reload():
            self.path = old
            return False
        self.global_cfg["active_set"] = name
        try:
            save_global(self.global_cfg)
        except (OSError, ValueError) as e:
            print("  ! 전역 설정 저장 실패:", e)
        self.reassert_rules()
        self.notify("설정 세트", "'%s' 세트로 바꿨습니다." % name)
        self.changed()
        return True

    def save_set_as(self, name):
        if not valid_set_name(name) or name == DEFAULT_SET:
            raise ValueError("세트 이름으로 쓸 수 없습니다: %r" % name)
        os.makedirs(SETS_DIR, exist_ok=True)
        save_config(set_path(name), self.cfg)
        return set_path(name)

    def delete_set(self, name):
        if name == DEFAULT_SET or name == self.set_name():
            raise ValueError("기본 세트나 사용 중인 세트는 지울 수 없습니다")
        os.remove(set_path(name))

    def rule_context(self, rules):
        now = time.localtime()
        ctx = {"minutes": now.tm_hour * 60 + now.tm_min, "dark": False, "windows": []}
        whens = [r.get("when") or {} for r in rules if r.get("enabled", True)]
        if any(w.get("dark_mode") is not None for w in whens):
            ctx["dark"] = system_dark_mode()
        if any(w.get("window_class") or w.get("title_contains") for w in whens):
            ctx["windows"] = [(get_class(h), get_title(h).lower()) for h in visible_top_windows(self.own)]
        return ctx

    def evaluate_rules(self):
        auto = self.global_cfg.get("auto") or {}
        rules = auto.get("rules") or []
        if self.in_rules or not auto.get("enabled", True) or not rules:
            return
        self.in_rules = True
        try:
            ctx = self.rule_context(rules)
            for i, rule in enumerate(rules):
                if not rule.get("enabled", True):
                    self.rule_states.pop(i, None)
                    continue
                state = rule_matches(rule, ctx)
                if self.rule_states.get(i) is state:
                    continue
                self.rule_states[i] = state
                acts = rule.get("then" if state else "else") or {}
                if acts:
                    self.apply_actions(acts, allow_set=True)
                    self.notify("자동 전환", "%s: %s" % (rule.get("name") or "규칙 %d" % (i + 1),
                                                      "조건 맞음" if state else "조건 벗어남"))
        finally:
            self.in_rules = False

    def apply_actions(self, acts, allow_set=True):
        target_set = acts.get("set")
        if allow_set and target_set and target_set != self.set_name():
            self.switch_set(target_set)
        changed = False
        for key, attr in ACTION_KEYS.items():
            if key in acts and getattr(self, attr) != bool(acts[key]):
                setattr(self, attr, bool(acts[key]))
                changed = True
        if acts.get("preset"):
            self.set_preset(acts["preset"], quiet=True)
        if changed:
            self.tick()
            self.changed()

    def reassert_rules(self):
        auto = self.global_cfg.get("auto") or {}
        if not auto.get("enabled", True):
            return
        rules = auto.get("rules") or []
        for i, state in list(self.rule_states.items()):
            if i < len(rules):
                acts = rules[i].get("then" if state else "else") or {}
                if acts:
                    self.apply_actions(acts, allow_set=False)

    def quit(self):
        print("[종료] 윈도우 컬러 체인지를 닫습니다.")
        if self.on_quit:
            self.on_quit()
        else:
            PostQuitMessage(0)

    def rebuild_own(self):
        self.own = set()
        for ov in self.overlays.values():
            self.own.update(ov.all_windows())
        own = list(self.own)
        arr = (wintypes.HWND * len(own))(*own) if own else None
        for ov in self.overlays.values():
            MagSetWindowFilterList(ov.mag, MW_FILTERMODE_EXCLUDE, len(own), arr)
            hidden = own + [ov.target]
            harr = (wintypes.HWND * len(hidden))(*hidden)
            for g in ov.see_groups.values():
                MagSetWindowFilterList(g["mag"], MW_FILTERMODE_EXCLUDE, len(hidden), harr)

    def discover(self):
        profiles = self.cfg.get("profiles") or []
        need_title = any((p.get("match") or {}).get("title_contains") for p in profiles)
        found = {}

        def callback(hwnd, _lparam):
            try:
                if hwnd in self.own or not IsWindowVisible(hwnd):
                    return True
                cls = get_class(hwnd)
                title = get_title(hwnd) if need_title else ""
                for pi, p in enumerate(profiles):
                    if match_profile(p, cls, title):
                        found[hwnd] = pi
                        break
            except Exception:
                pass
            return True

        EnumWindows(WNDENUMPROC(callback), 0)
        changed = False
        for t in [t for t in self.overlays if t not in found]:
            self.overlays.pop(t).destroy()
            changed = True
        for t, pi in found.items():
            if t not in self.overlays:
                try:
                    self.overlays[t] = Overlay(self, t, pi)
                    changed = True
                except OSError as e:
                    print("  ! 오버레이 생성 실패:", e)
        if changed:
            self.rebuild_own()
            print("[대상] 감지된 창 %d개" % len(self.overlays))

    def tick(self):
        try:
            self.tick_count += 1
            periodic = self.tick_count == 1 or self.tick_count % self.discover_every == 0
            if self.peeking and (self.peek_vk is None or not key_down(self.peek_vk)):
                self.peeking = False
                self.changed()
            off = self.peeking or self.suspended
            self.fx = {"filter": self.filter_on and not off, "mask": self.mask_on and not off,
                       "see": self.see_on and not off, "hole": self.hole_on and not off}
            if periodic:
                self.discover()
            self.check_holes = periodic
            dead = [t for t, ov in self.overlays.items() if not ov.update()]
            if dead:
                for t in dead:
                    self.overlays.pop(t).destroy()
                self.rebuild_own()
                print("[대상] 감지된 창 %d개" % len(self.overlays))
            if self.tick_count == 1 or self.tick_count % self.rules_every == 0:
                self.evaluate_rules()
        except Exception as e:
            msg = "%s: %s" % (type(e).__name__, e)
            if msg != self.last_error:
                print("  ! 갱신 오류:", msg)
                self.last_error = msg

    def run(self):
        self.tick()
        msg = wintypes.MSG()
        while True:
            ret = GetMessageW(ctypes.byref(msg), None, 0, 0)
            if ret == 0 or ret == -1:
                break
            TranslateMessage(ctypes.byref(msg))
            DispatchMessageW(ctypes.byref(msg))

    def shutdown(self):
        if self.msg_hwnd and self.timer:
            KillTimer(self.msg_hwnd, TIMER_ID)
        self.timer = False
        for hid in list(self.hotkeys):
            UnregisterHotKey(self.msg_hwnd, hid)
        self.hotkeys = {}
        for ov in list(self.overlays.values()):
            ov.destroy()
        self.overlays.clear()
        self.own = set()
        if self.msg_hwnd:
            APP_OWNERS.pop(self.msg_hwnd, None)
            DestroyWindow(self.msg_hwnd)
            self.msg_hwnd = None


def init_engine(set_dpi=True):
    if not IS_WIN:
        return False, "Windows 전용 프로그램입니다."
    if struct.calcsize("P") != 8:
        return False, "64비트 Python이 필요합니다. 돋보기 API는 32비트 프로세스에서 제대로 동작하지 않습니다."
    if set_dpi:
        set_dpi_awareness()
    if not MagInitialize():
        return False, "돋보기 API 초기화(MagInitialize)에 실패했습니다."
    try:
        register_window_class()
    except OSError as e:
        return False, "창 클래스 등록 실패: %s" % e
    return True, ""


def uninit_engine():
    MagUninitialize()


def install_console_handler(holder):
    def on_console_event(event):
        if event in CONSOLE_EXIT_EVENTS and holder:
            try:
                holder[0].restore_holes()
            except Exception:
                pass
        return False

    handler = HANDLER_ROUTINE(on_console_event)
    SetConsoleCtrlHandler(handler, True)
    return handler


def main():
    ok, err = init_engine()
    if not ok:
        print(err)
        return 1
    app = None
    holder = []
    console_handler = install_console_handler(holder)
    try:
        app = App(startup_path())
        holder.append(app)
        app.run()
    except ValueError as e:
        print("설정 오류:", e)
        return 1
    except KeyboardInterrupt:
        pass
    finally:
        if app is not None:
            app.shutdown()
        uninit_engine()
        del console_handler
    print("종료했습니다.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
