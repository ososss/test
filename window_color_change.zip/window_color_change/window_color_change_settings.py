import copy
import json

from PyQt6.QtCore import Qt, QTimer, pyqtSignal
from PyQt6.QtGui import QColor, QFont
from PyQt6.QtWidgets import (
    QAbstractItemView, QApplication, QCheckBox, QColorDialog, QComboBox, QDialog, QFormLayout,
    QHBoxLayout, QHeaderView, QInputDialog, QLabel, QLineEdit, QListWidget, QListWidgetItem, QMessageBox,
    QPlainTextEdit, QPushButton, QSlider, QSpinBox, QTabWidget, QTableWidget, QTableWidgetItem,
    QVBoxLayout, QWidget,
)

import window_color_change as engine

APP_TITLE = "윈도우 컬러 체인지"
EDGE_DEFAULTS = {"left": 0, "top": 0, "right": "100%", "bottom": "100%"}
AREA_COLUMNS = {
    "filter_holes": ["name", "left", "top", "right", "bottom"],
    "masks": ["name", "left", "top", "right", "bottom", "hotkey", "enabled", "alpha", "color"],
    "see_through_areas": ["name", "left", "top", "right", "bottom", "hotkey", "enabled", "alpha"],
    "hole_areas": ["name", "left", "top", "right", "bottom", "hotkey", "enabled"],
}
COLUMN_WIDTHS = {"name": 150, "left": 70, "top": 70, "right": 70, "bottom": 70,
                 "hotkey": 120, "enabled": 70, "alpha": 60, "color": 90}
HOTKEY_KEYS = ("filter", "mask", "see_through", "hole", "peek", "cycle", "edit", "pick", "reload", "quit")
HOTKEY_HINT = ("형식: ctrl / alt / shift / win + 키\n"
               "키: a-z, 0-9, f1-f24, numpad0-9, space, insert, delete, home, end, "
               "pageup, pagedown, pause, scrolllock, esc, tab")
COORD_HINT = ("좌표: 0 이상은 창 왼쪽·위에서, 음수는 오른쪽·아래에서 잰 거리(px), \"100%\"는 끝입니다. "
              "color 칸은 더블클릭해서 고를 수 있고, 좌표 따기로 복사한 영역은 '클립보드에서 추가'로 넣습니다.")


def parse_coord(text, default, where):
    t = str(text).strip()
    if not t:
        return default
    try:
        if t.endswith("%"):
            float(t[:-1])
            return t
        v = float(t)
    except ValueError:
        raise ValueError("%s: 숫자나 \"50%%\" 형식이어야 합니다 (%s)" % (where, t))
    return int(v) if v.is_integer() else v


def new_profile(n):
    return {"name": "프로필 %d" % n, "enabled": True, "match": {"class": "", "title_contains": ""},
            "base": "frame", "filter_area": dict(EDGE_DEFAULTS), "filter_holes": [], "filter": None, "masks": [],
            "see_through_areas": [], "hole_areas": []}


class ColorField(QWidget):
    changed = pyqtSignal()

    def __init__(self, optional=False):
        super().__init__()
        self.optional = optional
        self.value = None
        self.button = QPushButton()
        self.button.setMinimumWidth(110)
        self.button.clicked.connect(self.choose)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(self.button)
        if optional:
            clear = QPushButton("없음")
            clear.clicked.connect(lambda checked=False: self.set_value(None))
            lay.addWidget(clear)
        lay.addStretch(1)
        self.set_value(None)

    def set_value(self, value):
        self.value = str(value).upper() if value else None
        if self.value and QColor(self.value).isValid():
            light = QColor(self.value).lightness() > 128
            self.button.setText(self.value)
            self.button.setStyleSheet("background:%s;color:%s;" % (self.value, "#000000" if light else "#FFFFFF"))
        else:
            self.button.setText(self.value or ("없음" if self.optional else "선택"))
            self.button.setStyleSheet("")
        self.changed.emit()

    def choose(self, *_):
        c = QColorDialog.getColor(QColor(self.value or "#808080"), self, "색 선택")
        if c.isValid():
            self.set_value(c.name())


class AreaTable(QWidget):
    def __init__(self, kind):
        super().__init__()
        self.kind = kind
        self.columns = AREA_COLUMNS[kind]
        self.painting = False
        self.table = QTableWidget(0, len(self.columns))
        self.table.setHorizontalHeaderLabels(self.columns)
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        header.setStretchLastSection(True)
        for c, key in enumerate(self.columns):
            self.table.setColumnWidth(c, COLUMN_WIDTHS[key])
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.cellDoubleClicked.connect(self.on_double_click)
        self.table.itemChanged.connect(self.on_item_changed)
        buttons = QHBoxLayout()
        for text, slot in (("추가", self.add_empty), ("클립보드에서 추가", self.paste), ("삭제", self.remove),
                           ("위로", self.move_up), ("아래로", self.move_down)):
            b = QPushButton(text)
            b.clicked.connect(slot)
            buttons.addWidget(b)
        buttons.addStretch(1)
        lay = QVBoxLayout(self)
        lay.addWidget(self.table)
        lay.addLayout(buttons)

    def set_items(self, items):
        self.table.setRowCount(0)
        for item in items:
            self.append(item)

    def append(self, item):
        r = self.table.rowCount()
        self.table.insertRow(r)
        extras = {k: v for k, v in item.items() if k not in self.columns}
        for c, key in enumerate(self.columns):
            if key == "enabled":
                cell = QTableWidgetItem()
                cell.setFlags(Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsEnabled
                              | Qt.ItemFlag.ItemIsSelectable)
                cell.setCheckState(Qt.CheckState.Checked if item.get("enabled", True) else Qt.CheckState.Unchecked)
            else:
                value = item.get(key, EDGE_DEFAULTS.get(key, ""))
                cell = QTableWidgetItem("" if value is None else str(value))
            if c == 0:
                cell.setData(Qt.ItemDataRole.UserRole, extras)
            self.table.setItem(r, c, cell)
            if key == "color":
                self.paint_color(cell)

    def paint_color(self, cell):
        self.painting = True
        try:
            c = QColor(cell.text().strip())
            if cell.text().strip() and c.isValid():
                cell.setBackground(c)
                cell.setForeground(QColor("#000000" if c.lightness() > 128 else "#FFFFFF"))
            else:
                cell.setData(Qt.ItemDataRole.BackgroundRole, None)
                cell.setData(Qt.ItemDataRole.ForegroundRole, None)
        finally:
            self.painting = False

    def on_item_changed(self, cell):
        if not self.painting and self.columns[cell.column()] == "color":
            self.paint_color(cell)

    def on_double_click(self, row, col):
        if self.columns[col] != "color":
            return
        cell = self.table.item(row, col)
        c = QColorDialog.getColor(QColor(cell.text().strip() or "#1B1F27"), self, "색 선택")
        if c.isValid():
            cell.setText(c.name().upper())

    def items(self):
        out = []
        for r in range(self.table.rowCount()):
            first = self.table.item(r, 0)
            item = dict(first.data(Qt.ItemDataRole.UserRole) or {}) if first else {}
            for c, key in enumerate(self.columns):
                cell = self.table.item(r, c)
                if key == "enabled":
                    item["enabled"] = cell is not None and cell.checkState() == Qt.CheckState.Checked
                    continue
                text = cell.text().strip() if cell else ""
                if key in EDGE_DEFAULTS:
                    item[key] = parse_coord(text, EDGE_DEFAULTS[key], "%s %d행 %s" % (self.kind, r + 1, key))
                elif key == "alpha":
                    if text:
                        try:
                            item[key] = int(text)
                        except ValueError:
                            raise ValueError("%s %d행 alpha: 0~255 정수여야 합니다 (%s)" % (self.kind, r + 1, text))
                    else:
                        item.pop(key, None)
                elif text:
                    item[key] = text
                else:
                    item.pop(key, None)
            out.append(item)
        return out

    def add_empty(self, *_):
        item = {"name": "새 영역"}
        item.update(EDGE_DEFAULTS)
        if "enabled" in self.columns:
            item["enabled"] = True
        self.append(item)
        self.table.selectRow(self.table.rowCount() - 1)

    def paste(self, *_):
        text = QApplication.clipboard().text().strip()
        try:
            data = json.loads(text)
        except ValueError:
            data = None
        rows = data if isinstance(data, list) else [data]
        rows = [d for d in rows if isinstance(d, dict) and any(k in d for k in EDGE_DEFAULTS)]
        if not rows:
            QMessageBox.information(self, APP_TITLE, "클립보드에 영역 JSON이 없습니다.\n"
                                    "좌표 따기 단축키를 영역의 양쪽 모서리에서 한 번씩 누르면 복사됩니다.")
            return
        for d in rows:
            self.append(d)
        self.table.selectRow(self.table.rowCount() - 1)

    def remove(self, *_):
        r = self.table.currentRow()
        if r >= 0:
            self.table.removeRow(r)

    def move_up(self, *_):
        self.move(-1)

    def move_down(self, *_):
        self.move(1)

    def move(self, delta):
        r = self.table.currentRow()
        t = r + delta
        if r < 0 or t < 0 or t >= self.table.rowCount():
            return
        for c in range(self.table.columnCount()):
            a = self.table.takeItem(r, c)
            b = self.table.takeItem(t, c)
            self.table.setItem(r, c, b)
            self.table.setItem(t, c, a)
        self.table.selectRow(t)


class SettingsDialog(QDialog):
    def __init__(self, eapp):
        super().__init__()
        self.eapp = eapp
        self.setWindowTitle("%s 설정" % APP_TITLE)
        self.resize(900, 640)
        self.cfg = {}
        self.profile_index = -1
        self.loading = False
        self.global_cfg = engine.merge_global({})
        self.picker = None
        self.preview_timer = QTimer(self)
        self.preview_timer.setSingleShot(True)
        self.preview_timer.timeout.connect(self.do_preview)
        self.tabs = QTabWidget()
        self.tabs.addTab(self.build_general(), "일반")
        self.tabs.addTab(self.build_filter(), "필터")
        self.tabs.addTab(self.build_mask(), "mask")
        self.tabs.addTab(self.build_see(), "see_through")
        self.tabs.addTab(self.build_hole(), "hole")
        self.tabs.addTab(self.build_hotkeys(), "단축키")
        self.tabs.addTab(self.build_profiles(), "프로필")
        self.rules_tab = RulesTab()
        self.tabs.addTab(self.rules_tab, "자동 전환")
        self.sets_tab = SetsTab(self)
        self.tabs.addTab(self.sets_tab, "세트")
        self.json_edit = QPlainTextEdit()
        font = QFont("Consolas")
        font.setStyleHint(QFont.StyleHint.Monospace)
        self.json_edit.setFont(font)
        self.json_index = self.tabs.addTab(self.json_edit, "JSON")
        self.last_tab = 0
        self.tabs.currentChanged.connect(self.on_tab_changed)
        self.status = QLabel()
        bottom = QHBoxLayout()
        bottom.addWidget(self.status, 1)
        for text, slot in (("파일에서 다시 불러오기", self.load_from_file), ("적용", self.apply),
                           ("저장 후 닫기", self.save_and_close), ("닫기", self.close_dialog)):
            b = QPushButton(text)
            b.clicked.connect(slot)
            bottom.addWidget(b)
        lay = QVBoxLayout(self)
        lay.addWidget(self.tabs)
        lay.addLayout(bottom)
        self.load_from_file()

    def build_general(self):
        w = QWidget()
        f = QFormLayout(w)
        self.refresh = QSpinBox()
        self.refresh.setRange(10, 1000)
        self.refresh.setSuffix(" ms")
        self.dpi = QCheckBox()
        f.addRow("refresh_ms", self.refresh)
        f.addRow("dpi_scale", self.dpi)
        info = QLabel("설정 파일: %s" % self.eapp.path)
        info.setWordWrap(True)
        info.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        f.addRow(info)
        return w

    def build_filter(self):
        w = QWidget()
        f = QFormLayout(w)
        self.f_start = QCheckBox()
        self.f_preset = QComboBox()
        self.f_preset.addItems(list(engine.PRESETS))
        self.f_bg = ColorField(optional=True)
        self.f_text = ColorField(optional=True)
        self.f_matrix = QPlainTextEdit()
        self.f_matrix.setPlaceholderText("비우면 preset과 background/text를 사용합니다. 5x5 숫자 배열 JSON")
        self.f_matrix.setFixedHeight(80)
        self.f_adjust = {key: SliderField() for key in engine.ADJUST_KEYS}
        self.f_cycle = CycleTable()
        f.addRow("start_on", self.f_start)
        f.addRow("preset", self.f_preset)
        f.addRow("background", self.f_bg)
        f.addRow("text", self.f_text)
        f.addRow("matrix", self.f_matrix)
        for key, field in self.f_adjust.items():
            f.addRow(key, field)
        f.addRow("cycle", self.f_cycle)
        self.f_preset.currentTextChanged.connect(self.schedule_preview)
        self.f_bg.changed.connect(self.schedule_preview)
        self.f_text.changed.connect(self.schedule_preview)
        self.f_matrix.textChanged.connect(self.schedule_preview)
        for field in self.f_adjust.values():
            field.changed.connect(self.schedule_preview)
        return w

    def build_mask(self):
        w = QWidget()
        f = QFormLayout(w)
        self.m_start = QCheckBox()
        self.m_click = QCheckBox()
        self.m_alpha = QSpinBox()
        self.m_alpha.setRange(0, 255)
        self.m_color = ColorField()
        f.addRow("start_on", self.m_start)
        f.addRow("click_through", self.m_click)
        f.addRow("alpha", self.m_alpha)
        f.addRow("color", self.m_color)
        return w

    def build_see(self):
        w = QWidget()
        f = QFormLayout(w)
        self.s_start = QCheckBox()
        self.s_alpha = QSpinBox()
        self.s_alpha.setRange(0, 255)
        self.s_filter = QCheckBox()
        f.addRow("start_on", self.s_start)
        f.addRow("alpha", self.s_alpha)
        f.addRow("use_filter", self.s_filter)
        return w

    def build_hole(self):
        w = QWidget()
        f = QFormLayout(w)
        self.h_start = QCheckBox()
        self.h_filter = QCheckBox()
        self.h_cover = QCheckBox("hole 영역 위에 뒤 화면을 다시 그려 회색·테두리 잔상을 덮음")
        self.h_border = QCheckBox("hole이 켜진 동안 창 테두리 선 숨김 (Windows 11)")
        self.h_dwm = QCheckBox("창 프레임·배경 효과·둥근 모서리 끄기 (회색이 계속 보일 때)")
        f.addRow("start_on", self.h_start)
        f.addRow("use_filter", self.h_filter)
        f.addRow("cover", self.h_cover)
        f.addRow("hide_border", self.h_border)
        f.addRow("dwm_fix", self.h_dwm)
        return w

    def build_hotkeys(self):
        w = QWidget()
        f = QFormLayout(w)
        self.hk_edits = {}
        for key in HOTKEY_KEYS:
            ed = QLineEdit()
            ed.setPlaceholderText("예: ctrl+alt+f")
            self.hk_edits[key] = ed
            f.addRow(key, ed)
        hint = QLabel(HOTKEY_HINT)
        hint.setWordWrap(True)
        f.addRow(hint)
        return w

    def build_profiles(self):
        w = QWidget()
        lay = QVBoxLayout(w)
        top = QHBoxLayout()
        self.p_combo = QComboBox()
        self.p_combo.setMinimumWidth(220)
        self.p_combo.currentIndexChanged.connect(self.on_profile_changed)
        add = QPushButton("프로필 추가")
        add.clicked.connect(self.add_profile)
        rem = QPushButton("프로필 삭제")
        rem.clicked.connect(self.remove_profile)
        top.addWidget(QLabel("프로필"))
        top.addWidget(self.p_combo)
        top.addWidget(add)
        top.addWidget(rem)
        draw = QPushButton("영역 그리기·편집")
        draw.clicked.connect(self.edit_areas)
        top.addWidget(draw)
        top.addStretch(1)
        lay.addLayout(top)
        form = QFormLayout()
        self.p_name = QLineEdit()
        self.p_name.textEdited.connect(self.on_name_edited)
        self.p_enabled = QCheckBox()
        self.p_class = QLineEdit()
        self.p_class.setPlaceholderText("'창 선택'을 누르고 대상 창을 클릭하면 채워집니다")
        class_row = QHBoxLayout()
        class_row.addWidget(self.p_class, 1)
        pick = QPushButton("창 선택")
        pick.clicked.connect(self.pick_window)
        class_row.addWidget(pick)
        self.p_title = QLineEdit()
        self.p_base = QComboBox()
        self.p_base.addItems(["frame", "client"])
        area_row = QHBoxLayout()
        self.p_area = {}
        for edge in EDGE_DEFAULTS:
            ed = QLineEdit()
            ed.setMaximumWidth(80)
            self.p_area[edge] = ed
            area_row.addWidget(QLabel(edge))
            area_row.addWidget(ed)
        area_row.addStretch(1)
        form.addRow("name", self.p_name)
        form.addRow("enabled", self.p_enabled)
        form.addRow("match.class", class_row)
        form.addRow("match.title_contains", self.p_title)
        form.addRow("base", self.p_base)
        form.addRow("filter_area", area_row)
        lay.addLayout(form)
        self.area_tabs = QTabWidget()
        self.area_tables = {}
        for kind in AREA_COLUMNS:
            table = AreaTable(kind)
            self.area_tables[kind] = table
            self.area_tabs.addTab(table, kind)
        self.area_tabs.addTab(self.build_profile_filter(), "filter")
        lay.addWidget(self.area_tabs, 1)
        hint = QLabel(COORD_HINT)
        hint.setWordWrap(True)
        lay.addWidget(hint)
        return w

    def fill_forms(self, cfg):
        self.loading = True
        try:
            self.cfg = cfg
            self.refresh.setValue(int(cfg.get("refresh_ms", 16)))
            self.dpi.setChecked(bool(cfg.get("dpi_scale", True)))
            f = cfg.get("filter") or {}
            self.f_start.setChecked(bool(f.get("start_on", True)))
            preset = f.get("preset") or "smart_invert"
            if self.f_preset.findText(preset) < 0:
                self.f_preset.addItem(preset)
            self.f_preset.setCurrentText(preset)
            self.f_bg.set_value(f.get("background"))
            self.f_text.set_value(f.get("text"))
            self.f_matrix.setPlainText(json.dumps(f["matrix"]) if f.get("matrix") else "")
            for key, field in self.f_adjust.items():
                field.set_value(f.get(key) or 0)
            self.f_cycle.set_entries(f.get("cycle") or [])
            m = cfg.get("mask") or {}
            self.m_start.setChecked(bool(m.get("start_on", True)))
            self.m_click.setChecked(bool(m.get("click_through", True)))
            self.m_alpha.setValue(int(m.get("alpha", 255)))
            self.m_color.set_value(m.get("color") or "#1B1F27")
            st = cfg.get("see_through") or {}
            self.s_start.setChecked(bool(st.get("start_on", True)))
            self.s_alpha.setValue(int(st.get("alpha", 255)))
            self.s_filter.setChecked(bool(st.get("use_filter", False)))
            h = cfg.get("hole") or {}
            self.h_start.setChecked(bool(h.get("start_on", True)))
            self.h_filter.setChecked(bool(h.get("use_filter", False)))
            self.h_cover.setChecked(bool(h.get("cover", True)))
            self.h_border.setChecked(bool(h.get("hide_border", True)))
            self.h_dwm.setChecked(bool(h.get("dwm_fix", False)))
            hk = cfg.get("hotkeys") or {}
            for key, ed in self.hk_edits.items():
                ed.setText(hk.get(key) or "")
            profiles = cfg.setdefault("profiles", [])
            if not profiles:
                profiles.append(new_profile(1))
            self.p_combo.clear()
            for i, p in enumerate(profiles):
                self.p_combo.addItem(p.get("name") or "프로필 %d" % (i + 1))
            self.profile_index = -1
            self.p_combo.setCurrentIndex(0)
            self.load_profile(0)
        finally:
            self.loading = False

    def load_profile(self, i):
        p = self.cfg["profiles"][i]
        m = p.get("match") or {}
        self.p_name.setText(p.get("name") or "")
        self.p_enabled.setChecked(bool(p.get("enabled", True)))
        self.p_class.setText(m.get("class") or "")
        self.p_title.setText(m.get("title_contains") or "")
        self.p_base.setCurrentText(p.get("base") or "frame")
        fa = p.get("filter_area") or {}
        for edge, ed in self.p_area.items():
            ed.setText(str(fa.get(edge, EDGE_DEFAULTS[edge])))
        for kind, table in self.area_tables.items():
            table.set_items(p.get(kind) or [])
        pf = p.get("filter") if isinstance(p.get("filter"), dict) else None
        self.pf_use.setChecked(pf is not None)
        self.on_profile_filter_toggled(pf is not None)
        pf = pf or {}
        preset = pf.get("preset") or "smart_invert"
        if self.pf_preset.findText(preset) < 0:
            self.pf_preset.addItem(preset)
        self.pf_preset.setCurrentText(preset)
        self.pf_bg.set_value(pf.get("background"))
        self.pf_text.set_value(pf.get("text"))
        for key, field in self.pf_adjust.items():
            field.set_value(pf.get(key) or 0)
        self.profile_index = i

    def commit_profile(self, cfg):
        profiles = cfg.setdefault("profiles", [])
        i = self.profile_index
        if i < 0 or i >= len(profiles):
            return
        p = profiles[i]
        p["name"] = self.p_name.text().strip() or "프로필 %d" % (i + 1)
        p["enabled"] = self.p_enabled.isChecked()
        match = p.setdefault("match", {})
        match["class"] = self.p_class.text().strip()
        match["title_contains"] = self.p_title.text().strip()
        p["base"] = self.p_base.currentText()
        fa = p.setdefault("filter_area", {})
        for edge, ed in self.p_area.items():
            fa[edge] = parse_coord(ed.text(), EDGE_DEFAULTS[edge], "filter_area %s" % edge)
        for kind, table in self.area_tables.items():
            p[kind] = table.items()
        if self.pf_use.isChecked():
            pf = {"preset": self.pf_preset.currentText(), "background": self.pf_bg.value,
                  "text": self.pf_text.value, "matrix": None}
            for key, field in self.pf_adjust.items():
                pf[key] = field.value()
            p["filter"] = pf
        else:
            p["filter"] = None

    def form_to_cfg(self):
        cfg = copy.deepcopy(self.cfg)
        cfg["refresh_ms"] = self.refresh.value()
        cfg["dpi_scale"] = self.dpi.isChecked()
        f = cfg.setdefault("filter", {})
        f["start_on"] = self.f_start.isChecked()
        f["preset"] = self.f_preset.currentText()
        f["background"] = self.f_bg.value
        f["text"] = self.f_text.value
        text = self.f_matrix.toPlainText().strip()
        try:
            f["matrix"] = json.loads(text) if text else None
        except ValueError:
            raise ValueError("filter.matrix: JSON 형식이 아닙니다")
        for key, field in self.f_adjust.items():
            f[key] = field.value()
        f["cycle"] = self.f_cycle.entries()
        m = cfg.setdefault("mask", {})
        m["start_on"] = self.m_start.isChecked()
        m["click_through"] = self.m_click.isChecked()
        m["alpha"] = self.m_alpha.value()
        if self.m_color.value:
            m["color"] = self.m_color.value
        st = cfg.setdefault("see_through", {})
        st["start_on"] = self.s_start.isChecked()
        st["alpha"] = self.s_alpha.value()
        st["use_filter"] = self.s_filter.isChecked()
        h = cfg.setdefault("hole", {})
        h["start_on"] = self.h_start.isChecked()
        h["use_filter"] = self.h_filter.isChecked()
        h["cover"] = self.h_cover.isChecked()
        h["hide_border"] = self.h_border.isChecked()
        h["dwm_fix"] = self.h_dwm.isChecked()
        hk = cfg.setdefault("hotkeys", {})
        for key, ed in self.hk_edits.items():
            hk[key] = ed.text().strip()
        self.commit_profile(cfg)
        return cfg

    def current_cfg(self):
        if self.tabs.currentIndex() == self.json_index:
            try:
                data = json.loads(self.json_edit.toPlainText())
            except ValueError as e:
                raise ValueError("JSON 형식 오류: %s" % e)
            return engine.merge_config(data)
        cfg = self.form_to_cfg()
        self.cfg = cfg
        return cfg

    def warn(self, text):
        QMessageBox.warning(self, APP_TITLE, text)

    def on_tab_changed(self, i):
        if self.loading:
            return
        prev = self.last_tab
        try:
            if prev == self.json_index and i != self.json_index:
                data = json.loads(self.json_edit.toPlainText())
                self.fill_forms(engine.merge_config(data))
            elif i == self.json_index and prev != self.json_index:
                self.cfg = self.form_to_cfg()
                self.json_edit.setPlainText(json.dumps(self.cfg, ensure_ascii=False, indent=2))
        except ValueError as e:
            self.warn(str(e))
            self.loading = True
            self.tabs.setCurrentIndex(prev)
            self.loading = False
            return
        self.last_tab = i

    def on_name_edited(self, text):
        if 0 <= self.profile_index < self.p_combo.count():
            self.p_combo.setItemText(self.profile_index, text or "(이름 없음)")

    def on_profile_changed(self, i):
        if self.loading or i < 0 or i == self.profile_index:
            return
        try:
            self.commit_profile(self.cfg)
        except ValueError as e:
            self.warn(str(e))
            self.loading = True
            self.p_combo.setCurrentIndex(self.profile_index)
            self.loading = False
            return
        self.load_profile(i)

    def reset_profile_combo(self, select):
        profiles = self.cfg["profiles"]
        self.loading = True
        self.p_combo.clear()
        for k, p in enumerate(profiles):
            self.p_combo.addItem(p.get("name") or "프로필 %d" % (k + 1))
        self.p_combo.setCurrentIndex(select)
        self.loading = False
        self.profile_index = -1
        self.load_profile(select)

    def add_profile(self, *_):
        try:
            self.commit_profile(self.cfg)
        except ValueError as e:
            self.warn(str(e))
            return
        profiles = self.cfg.setdefault("profiles", [])
        profiles.append(new_profile(len(profiles) + 1))
        self.reset_profile_combo(len(profiles) - 1)

    def remove_profile(self, *_):
        profiles = self.cfg.get("profiles") or []
        i = self.profile_index
        if i < 0 or i >= len(profiles):
            return
        answer = QMessageBox.question(self, APP_TITLE, "프로필 '%s'을(를) 삭제할까요?" % self.p_combo.currentText())
        if answer != QMessageBox.StandardButton.Yes:
            return
        del profiles[i]
        if not profiles:
            profiles.append(new_profile(1))
        self.reset_profile_combo(min(i, len(profiles) - 1))

    def load_from_file(self, *_):
        try:
            cfg = engine.load_config(self.eapp.path)
        except (OSError, ValueError) as e:
            self.warn("설정 파일을 읽지 못해 실행 중인 설정을 보여 줍니다.\n%s" % e)
            cfg = copy.deepcopy(self.eapp.cfg)
        keep = self.profile_index
        self.fill_forms(cfg)
        if 0 < keep < len(self.cfg["profiles"]):
            self.reset_profile_combo(keep)
        self.json_edit.setPlainText(json.dumps(self.cfg, ensure_ascii=False, indent=2))
        try:
            self.global_cfg = engine.load_global()
        except (OSError, ValueError) as e:
            self.warn("자동 전환 설정을 읽지 못해 기본값을 보여 줍니다.\n%s" % e)
            self.global_cfg = engine.merge_global({})
        self.rules_tab.set_global(self.global_cfg)
        self.sets_tab.refresh()
        self.setWindowTitle("%s 설정 - 세트: %s" % (APP_TITLE, engine.set_name_of(self.eapp.path)))
        self.status.setText("")

    def apply(self, *_):
        try:
            cfg = engine.check_config(self.current_cfg())
            glob = self.rules_tab.to_global(self.global_cfg)
            glob["active_set"] = engine.set_name_of(self.eapp.path)
            glob = engine.merge_global(glob)
        except (ValueError, TypeError) as e:
            self.warn("설정 오류\n%s" % e)
            return False
        try:
            engine.save_config(self.eapp.path, cfg)
            engine.save_global(glob)
        except OSError as e:
            self.warn("저장하지 못했습니다\n%s" % e)
            return False
        self.global_cfg = glob
        ok = self.eapp.reload()
        self.eapp.reload_global()
        keep = self.profile_index
        self.fill_forms(copy.deepcopy(self.eapp.cfg) if ok else cfg)
        if 0 < keep < len(self.cfg["profiles"]):
            self.reset_profile_combo(keep)
        self.json_edit.setPlainText(json.dumps(self.cfg, ensure_ascii=False, indent=2))
        self.status.setText("저장하고 적용했습니다." if ok else "저장했지만 적용하지 못했습니다.")
        return ok

    def build_profile_filter(self):
        w = QWidget()
        f = QFormLayout(w)
        self.pf_use = QCheckBox("이 프로필에만 다른 필터 사용 (끄면 전역 필터를 따름)")
        self.pf_preset = QComboBox()
        self.pf_preset.addItems(list(engine.PRESETS))
        self.pf_bg = ColorField(optional=True)
        self.pf_text = ColorField(optional=True)
        self.pf_adjust = {key: SliderField() for key in engine.ADJUST_KEYS}
        f.addRow(self.pf_use)
        f.addRow("preset", self.pf_preset)
        f.addRow("background", self.pf_bg)
        f.addRow("text", self.pf_text)
        for key, field in self.pf_adjust.items():
            f.addRow(key, field)
        self.pf_use.toggled.connect(self.on_profile_filter_toggled)
        self.pf_use.toggled.connect(self.schedule_preview)
        self.pf_preset.currentTextChanged.connect(self.schedule_preview)
        self.pf_bg.changed.connect(self.schedule_preview)
        self.pf_text.changed.connect(self.schedule_preview)
        for field in self.pf_adjust.values():
            field.changed.connect(self.schedule_preview)
        return w

    def on_profile_filter_toggled(self, on):
        for widget in [self.pf_preset, self.pf_bg, self.pf_text] + list(self.pf_adjust.values()):
            widget.setEnabled(bool(on))

    def schedule_preview(self, *_):
        if not self.loading:
            self.preview_timer.start(120)

    def do_preview(self):
        if self.tabs.currentIndex() == self.json_index:
            return
        try:
            cfg = self.form_to_cfg()
        except (ValueError, TypeError):
            return
        self.eapp.preview(cfg)

    def pick_window(self, *_):
        import window_color_change_tools as tools

        def done(info):
            self.show()
            self.raise_()
            self.activateWindow()
            if info:
                self.p_class.setText(info["class"])
                self.status.setText("선택한 창: %s" % (info["title"] or info["class"]))

        self.hide()
        self.picker = tools.WindowPicker(self.eapp, done)
        self.picker.start()

    def edit_areas(self, *_):
        import window_color_change_tools as tools
        if not self.apply():
            return
        pi = self.profile_index
        profiles = self.eapp.cfg.get("profiles") or []
        if not 0 <= pi < len(profiles):
            return
        targets = tools.find_targets_for(self.eapp, profiles[pi])
        if not targets:
            self.warn("이 프로필에 맞는 창이 지금 열려 있지 않습니다.\nmatch.class를 확인하거나 대상 창을 먼저 여세요.")
            return

        def done(saved):
            self.show()
            self.raise_()
            self.activateWindow()
            if saved:
                self.load_from_file()
                self.status.setText("영역을 저장하고 적용했습니다.")

        self.hide()
        try:
            tools.open_area_editor(self.eapp, targets[0], pi, done)
        except ValueError as e:
            done(False)
            self.warn(str(e))

    def closeEvent(self, event):
        self.preview_timer.stop()
        if getattr(self.eapp, "preview_cfg", None) is not None:
            self.eapp.preview(None)
        super().closeEvent(event)

    def save_and_close(self, *_):
        if self.apply():
            self.close()

    def close_dialog(self, *_):
        self.close()


CYCLE_COLUMNS = ["name", "preset", "background", "text"]
RULE_COLUMNS = ["name", "enabled", "time", "dark_mode", "window_class", "title_contains", "then", "else"]
RULE_WIDTHS = {"name": 110, "enabled": 60, "time": 100, "dark_mode": 80, "window_class": 150,
               "title_contains": 110, "then": 170, "else": 170}
RULES_HINT = ("time: 18:00-07:00 처럼 입력 · dark_mode: true/false (빈칸이면 조건 아님) · "
              "window_class/title_contains: 이런 창이 떠 있을 때\n"
              "then/else: 조건이 맞을 때/벗어날 때 할 일. filter=on, mask=off, see_through=on, hole=off, "
              "preset=invert, set=세트이름 처럼 쉼표로 구분")
ON_WORDS = ("on", "true", "1", "켬")
OFF_WORDS = ("off", "false", "0", "끔")


def parse_actions(text, where):
    acts = {}
    for part in [p.strip() for p in str(text).split(",") if p.strip()]:
        if "=" not in part:
            raise ValueError("%s: '%s'는 key=value 형식이어야 합니다" % (where, part))
        key, value = (x.strip() for x in part.split("=", 1))
        if key in engine.ACTION_KEYS:
            if value.lower() in ON_WORDS:
                acts[key] = True
            elif value.lower() in OFF_WORDS:
                acts[key] = False
            else:
                raise ValueError("%s: %s는 on/off여야 합니다" % (where, key))
        elif key in ("preset", "set"):
            acts[key] = value
        else:
            raise ValueError("%s: 알 수 없는 항목 '%s'" % (where, key))
    return acts


def format_actions(acts):
    parts = []
    for key, value in (acts or {}).items():
        parts.append("%s=%s" % (key, ("on" if value else "off") if isinstance(value, bool) else value))
    return ", ".join(parts)


def table_buttons(owner, table, add_slot):
    row = QHBoxLayout()

    def remove(*_):
        r = table.currentRow()
        if r >= 0:
            table.removeRow(r)

    def move(delta):
        r = table.currentRow()
        t = r + delta
        if r < 0 or t < 0 or t >= table.rowCount():
            return
        for c in range(table.columnCount()):
            a = table.takeItem(r, c)
            b = table.takeItem(t, c)
            table.setItem(r, c, b)
            table.setItem(t, c, a)
        table.selectRow(t)

    for text, slot in (("추가", add_slot), ("삭제", remove), ("위로", lambda *_: move(-1)),
                       ("아래로", lambda *_: move(1))):
        b = QPushButton(text)
        b.clicked.connect(slot)
        row.addWidget(b)
    row.addStretch(1)
    return row


def make_table(columns, widths):
    table = QTableWidget(0, len(columns))
    table.setHorizontalHeaderLabels(columns)
    table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
    table.horizontalHeader().setStretchLastSection(True)
    for c, key in enumerate(columns):
        table.setColumnWidth(c, widths.get(key, 100))
    table.verticalHeader().setVisible(False)
    table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
    table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
    return table


def check_cell(checked):
    cell = QTableWidgetItem()
    cell.setFlags(Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable)
    cell.setCheckState(Qt.CheckState.Checked if checked else Qt.CheckState.Unchecked)
    return cell


class SliderField(QWidget):
    changed = pyqtSignal()

    def __init__(self):
        super().__init__()
        self.slider = QSlider(Qt.Orientation.Horizontal)
        self.slider.setRange(-100, 100)
        self.spin = QSpinBox()
        self.spin.setRange(-100, 100)
        self.slider.valueChanged.connect(self.spin.setValue)
        self.spin.valueChanged.connect(self.slider.setValue)
        self.spin.valueChanged.connect(lambda v: self.changed.emit())
        reset = QPushButton("0")
        reset.setFixedWidth(36)
        reset.clicked.connect(lambda checked=False: self.set_value(0))
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(self.slider, 1)
        lay.addWidget(self.spin)
        lay.addWidget(reset)

    def value(self):
        return self.spin.value()

    def set_value(self, value):
        self.spin.setValue(int(round(float(value or 0))))


class CycleTable(QWidget):
    def __init__(self):
        super().__init__()
        self.table = make_table(CYCLE_COLUMNS, {"name": 120, "preset": 120, "background": 100, "text": 100})
        self.table.setMinimumHeight(110)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(self.table)
        lay.addLayout(table_buttons(self, self.table, self.add_empty))

    def add_empty(self, *_):
        self.append({"preset": "smart_invert"})

    def append(self, entry):
        if isinstance(entry, str):
            entry = {"preset": entry}
        r = self.table.rowCount()
        self.table.insertRow(r)
        for c, key in enumerate(CYCLE_COLUMNS):
            value = entry.get(key)
            self.table.setItem(r, c, QTableWidgetItem("" if value is None else str(value)))

    def set_entries(self, entries):
        self.table.setRowCount(0)
        for entry in entries:
            self.append(entry)

    def entries(self):
        out = []
        for r in range(self.table.rowCount()):
            values = {key: (self.table.item(r, c).text().strip() if self.table.item(r, c) else "")
                      for c, key in enumerate(CYCLE_COLUMNS)}
            preset = values["preset"] or "smart_invert"
            extra = {k: values[k] for k in ("name", "background", "text") if values[k]}
            if extra:
                entry = {"preset": preset}
                entry.update(extra)
                out.append(entry)
            else:
                out.append(preset)
        return out


class RulesTab(QWidget):
    def __init__(self):
        super().__init__()
        self.enabled = QCheckBox("자동 전환 사용 (auto.enabled)")
        self.table = make_table(RULE_COLUMNS, RULE_WIDTHS)
        hint = QLabel(RULES_HINT)
        hint.setWordWrap(True)
        lay = QVBoxLayout(self)
        lay.addWidget(self.enabled)
        lay.addWidget(self.table, 1)
        lay.addLayout(table_buttons(self, self.table, self.add_empty))
        lay.addWidget(hint)

    def add_empty(self, *_):
        self.append({"name": "새 규칙", "enabled": True, "when": {"time": "18:00-07:00"},
                     "then": {"filter": True}, "else": {"filter": False}})

    def append(self, rule):
        r = self.table.rowCount()
        self.table.insertRow(r)
        when = rule.get("when") or {}
        dark = when.get("dark_mode")
        values = {"name": rule.get("name") or "", "time": when.get("time") or "",
                  "dark_mode": "" if dark is None else ("true" if dark else "false"),
                  "window_class": when.get("window_class") or "", "title_contains": when.get("title_contains") or "",
                  "then": format_actions(rule.get("then")), "else": format_actions(rule.get("else"))}
        for c, key in enumerate(RULE_COLUMNS):
            cell = check_cell(rule.get("enabled", True)) if key == "enabled" else QTableWidgetItem(values[key])
            if c == 0:
                extras = {k: v for k, v in rule.items() if k not in ("name", "enabled", "when", "then", "else")}
                extras["_when"] = {k: v for k, v in when.items()
                                   if k not in ("time", "dark_mode", "window_class", "title_contains")}
                cell.setData(Qt.ItemDataRole.UserRole, extras)
            self.table.setItem(r, c, cell)

    def set_global(self, g):
        auto = g.get("auto") or {}
        self.enabled.setChecked(bool(auto.get("enabled", True)))
        self.table.setRowCount(0)
        for rule in auto.get("rules") or []:
            self.append(rule)

    def rules(self):
        out = []
        for r in range(self.table.rowCount()):
            text = {key: (self.table.item(r, c).text().strip() if self.table.item(r, c) else "")
                    for c, key in enumerate(RULE_COLUMNS) if key != "enabled"}
            extras = dict(self.table.item(r, 0).data(Qt.ItemDataRole.UserRole) or {}) if self.table.item(r, 0) else {}
            when = dict(extras.pop("_when", {}) or {})
            where = "규칙 %d행" % (r + 1)
            if text["time"]:
                when["time"] = text["time"]
            dark = text["dark_mode"].lower()
            if dark in ON_WORDS:
                when["dark_mode"] = True
            elif dark in OFF_WORDS:
                when["dark_mode"] = False
            elif dark:
                raise ValueError("%s dark_mode: true/false 또는 빈칸이어야 합니다" % where)
            for key in ("window_class", "title_contains"):
                if text[key]:
                    when[key] = text[key]
            rule = dict(extras)
            rule.update({"name": text["name"] or "규칙 %d" % (r + 1),
                         "enabled": self.table.item(r, 1).checkState() == Qt.CheckState.Checked,
                         "when": when, "then": parse_actions(text["then"], where + " then"),
                         "else": parse_actions(text["else"], where + " else")})
            out.append(engine.check_rule(rule))
        return out

    def to_global(self, base):
        g = copy.deepcopy(base or {})
        auto = g.setdefault("auto", {})
        auto["enabled"] = self.enabled.isChecked()
        auto["rules"] = self.rules()
        return g


class SetsTab(QWidget):
    def __init__(self, dialog):
        super().__init__()
        self.dialog = dialog
        self.label = QLabel()
        self.list = QListWidget()
        buttons = QHBoxLayout()
        for text, slot in (("이 세트로 전환", self.switch), ("현재 설정을 새 세트로 저장", self.save_as),
                           ("세트 삭제", self.delete)):
            b = QPushButton(text)
            b.clicked.connect(slot)
            buttons.addWidget(b)
        buttons.addStretch(1)
        hint = QLabel("세트마다 설정 파일이 따로 저장됩니다. 설정 창에서 고친 내용은 지금 쓰는 세트에 저장되고, "
                      "트레이 메뉴에서도 세트를 바로 바꿀 수 있습니다.")
        hint.setWordWrap(True)
        lay = QVBoxLayout(self)
        lay.addWidget(self.label)
        lay.addWidget(self.list, 1)
        lay.addLayout(buttons)
        lay.addWidget(hint)

    def refresh(self):
        current = engine.set_name_of(self.dialog.eapp.path)
        self.label.setText("지금 쓰는 세트: %s" % current)
        self.list.clear()
        for name in engine.list_sets():
            item = QListWidgetItem(name + ("  (사용 중)" if name == current else ""))
            item.setData(Qt.ItemDataRole.UserRole, name)
            self.list.addItem(item)

    def selected(self):
        item = self.list.currentItem()
        return item.data(Qt.ItemDataRole.UserRole) if item else None

    def switch(self, *_):
        name = self.selected()
        if name and self.dialog.eapp.switch_set(name):
            self.dialog.load_from_file()
            self.dialog.status.setText("'%s' 세트로 바꿨습니다." % name)

    def save_as(self, *_):
        name, ok = QInputDialog.getText(self, APP_TITLE, "새 세트 이름")
        name = (name or "").strip()
        if not ok or not name:
            return
        if name in engine.list_sets():
            answer = QMessageBox.question(self, APP_TITLE, "'%s' 세트가 이미 있습니다. 덮어쓸까요?" % name)
            if answer != QMessageBox.StandardButton.Yes:
                return
        if not self.dialog.apply():
            return
        try:
            self.dialog.eapp.save_set_as(name)
        except (ValueError, OSError) as e:
            self.dialog.warn(str(e))
            return
        self.refresh()
        self.dialog.status.setText("현재 설정을 '%s' 세트로 저장했습니다." % name)

    def delete(self, *_):
        name = self.selected()
        if not name:
            return
        if QMessageBox.question(self, APP_TITLE, "세트 '%s'을(를) 삭제할까요?" % name) != QMessageBox.StandardButton.Yes:
            return
        try:
            self.dialog.eapp.delete_set(name)
        except (ValueError, OSError) as e:
            self.dialog.warn(str(e))
            return
        self.refresh()
