import copy
import os
import sys

from PyQt6.QtCore import QPointF, QRectF, Qt, QTimer
from PyQt6.QtGui import QAction, QColor, QFont, QGuiApplication, QPainter, QPen
from PyQt6.QtWidgets import QHBoxLayout, QLabel, QMenu, QMessageBox, QPushButton, QWidget

import window_color_change as engine

APP_TITLE = "윈도우 컬러 체인지"
RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
RUN_NAME = "WindowColorChange"
KIND_ORDER = ("masks", "see_through_areas", "hole_areas", "filter_holes")
KIND_COLORS = {"masks": "#E5484D", "see_through_areas": "#30A46C", "hole_areas": "#F5A524",
               "filter_holes": "#8E8E93"}
KIND_LABELS = {"masks": "mask", "see_through_areas": "see_through", "hole_areas": "hole",
               "filter_holes": "filter_holes"}
EDGE_KEYS = ("left", "top", "right", "bottom")
HANDLE = 5
MIN_SIZE = 6
EDITOR_HINT = "드래그: 새 영역 · 클릭: 선택·이동 · 모서리: 크기 · 우클릭: 종류/삭제 · Del: 삭제 · Enter: 저장 · Esc: 취소"
LIVE = []


def startup_command(script):
    exe = sys.executable
    folder, name = os.path.split(exe)
    if name.lower() == "python.exe" and os.path.exists(os.path.join(folder, "pythonw.exe")):
        exe = os.path.join(folder, "pythonw.exe")
    return '"%s" "%s"' % (exe, os.path.abspath(script))


def startup_enabled(script):
    import winreg
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY) as key:
            value, _ = winreg.QueryValueEx(key, RUN_NAME)
    except OSError:
        return False
    return str(value).strip().lower() == startup_command(script).lower()


def set_startup(script, enabled):
    import winreg
    with winreg.CreateKeyEx(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_SET_VALUE) as key:
        if enabled:
            winreg.SetValueEx(key, RUN_NAME, 0, winreg.REG_SZ, startup_command(script))
        else:
            try:
                winreg.DeleteValue(key, RUN_NAME)
            except FileNotFoundError:
                pass


def find_targets_for(eapp, profile):
    return engine.find_targets(profile, eapp.own)


class PickerShield(QWidget):
    def __init__(self, picker, screen, show_hint):
        super().__init__(None, Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint
                         | Qt.WindowType.Tool)
        self.picker = picker
        self.show_hint = show_hint
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setCursor(Qt.CursorShape.CrossCursor)
        self.setGeometry(screen.geometry())

    def paintEvent(self, event):
        p = QPainter(self)
        p.fillRect(self.rect(), QColor(0, 0, 0, 45))
        if self.show_hint:
            font = QFont()
            font.setPointSize(13)
            p.setFont(font)
            box = QRectF(self.width() / 2 - 260, 40, 520, 44)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(32, 33, 36, 230))
            p.drawRoundedRect(box, 8, 8)
            p.setPen(QColor("#FFFFFF"))
            p.drawText(box, Qt.AlignmentFlag.AlignCenter, "대상 창을 클릭하세요 · Esc 또는 우클릭: 취소")

    def mousePressEvent(self, event):
        self.picker.finish(event.button() == Qt.MouseButton.LeftButton)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key.Key_Escape:
            self.picker.finish(False)


class WindowPicker:
    def __init__(self, eapp, callback):
        self.eapp = eapp
        self.callback = callback
        self.shields = []
        self.done = False

    def start(self):
        for i, screen in enumerate(QGuiApplication.screens()):
            shield = PickerShield(self, screen, i == 0)
            shield.show()
            self.shields.append(shield)
        if self.shields:
            self.shields[0].activateWindow()
            self.shields[0].setFocus()
        LIVE.append(self)

    def finish(self, pick):
        if self.done:
            return
        self.done = True
        info = None
        if pick:
            x, y = engine.cursor_pos()
            exclude = set(self.eapp.own) | {int(s.winId()) for s in self.shields}
            hwnd = engine.top_window_at(x, y, exclude)
            if hwnd:
                info = {"hwnd": hwnd, "class": engine.get_class(hwnd), "title": engine.get_title(hwnd)}
        for shield in self.shields:
            shield.close()
            shield.deleteLater()
        self.shields = []
        if self in LIVE:
            LIVE.remove(self)
        QTimer.singleShot(0, lambda: self.callback(info))


class AreaEditor(QWidget):
    def __init__(self, eapp, hwnd, pi, callback):
        super().__init__(None, Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint
                         | Qt.WindowType.Tool)
        self.eapp, self.hwnd, self.pi, self.callback = eapp, hwnd, pi, callback
        self.profile = copy.deepcopy(eapp.cfg["profiles"][pi])
        geo = engine.base_geometry(hwnd, self.profile.get("base") or "frame", eapp.dpi_scale)
        if not geo or geo[2] < 20 or geo[3] < 20:
            raise ValueError("대상 창 위치를 읽지 못했습니다.")
        self.L, self.T, self.W, self.H, self.s = geo
        self.items = []
        self.kept = {kind: [] for kind in KIND_ORDER}
        for kind in KIND_ORDER:
            for spec in self.profile.get(kind) or []:
                rect = engine.resolve_rect(spec, self.W, self.H, self.s)
                if rect:
                    self.items.append({"kind": kind, "spec": dict(spec), "rect": list(rect), "dirty": False})
                else:
                    self.kept[kind].append(spec)
        self.selected = None
        self.drag = None
        self.drawing = None
        self.saved = False
        self.closed = False
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.bar = QWidget(self)
        self.bar.setAttribute(Qt.WidgetAttribute.WA_StyledBackground)
        self.bar.setStyleSheet("QWidget{background:#202124;color:#FFFFFF;border-radius:6px;}"
                               "QPushButton{background:#3C4043;padding:4px 12px;}")
        row = QHBoxLayout(self.bar)
        row.setContentsMargins(10, 6, 10, 6)
        hint = QLabel(EDITOR_HINT)
        hint.setWordWrap(True)
        row.addWidget(hint, 1)
        for text, slot in (("저장", self.save), ("취소", self.cancel)):
            b = QPushButton(text)
            b.clicked.connect(slot)
            row.addWidget(b)

    def dpr(self):
        return self.devicePixelRatioF() or 1.0

    def place(self):
        engine.SetWindowPos(int(self.winId()), engine.HWND_TOPMOST, self.L, self.T, self.W, self.H,
                            engine.SWP_SHOWWINDOW)
        self.bar.setFixedWidth(max(240, min(self.width() - 20, 720)))
        self.bar.adjustSize()
        self.bar.move(max(10, (self.width() - self.bar.width()) // 2), 10)

    def showEvent(self, event):
        super().showEvent(event)
        self.place()
        QTimer.singleShot(60, self.place)
        self.activateWindow()
        self.setFocus()

    def to_view(self, rect):
        d = self.dpr()
        return QRectF(rect[0] / d, rect[1] / d, (rect[2] - rect[0]) / d, (rect[3] - rect[1]) / d)

    def to_phys(self, pos):
        d = self.dpr()
        return (max(0, min(self.W, round(pos.x() * d))), max(0, min(self.H, round(pos.y() * d))))

    def item_at(self, x, y):
        for idx in range(len(self.items) - 1, -1, -1):
            left, top, right, bottom = self.items[idx]["rect"]
            if left <= x <= right and top <= y <= bottom:
                return idx
        return None

    def handle_at(self, x, y):
        if self.selected is None:
            return None
        left, top, right, bottom = self.items[self.selected]["rect"]
        tol = HANDLE * self.dpr()
        if not (left - tol <= x <= right + tol and top - tol <= y <= bottom + tol):
            return None
        edges = ""
        if abs(y - top) <= tol:
            edges += "t"
        elif abs(y - bottom) <= tol:
            edges += "b"
        if abs(x - left) <= tol:
            edges += "l"
        elif abs(x - right) <= tol:
            edges += "r"
        return edges or None

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.fillRect(self.rect(), QColor(0, 0, 0, 70))
        font = QFont()
        font.setPointSize(9)
        p.setFont(font)
        for idx, item in enumerate(self.items):
            color = QColor(KIND_COLORS[item["kind"]])
            view = self.to_view(item["rect"])
            fill = QColor(color)
            fill.setAlpha(80)
            p.fillRect(view, fill)
            p.setPen(QPen(color, 3 if idx == self.selected else 2))
            p.drawRect(view)
            p.setPen(QColor("#FFFFFF"))
            label = "%s · %s" % (KIND_LABELS[item["kind"]], item["spec"].get("name") or "")
            p.drawText(view.adjusted(4, 2, -4, -2), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop, label)
            if idx == self.selected:
                p.setBrush(QColor("#FFFFFF"))
                p.setPen(QPen(color, 1))
                for hx in (view.left(), view.center().x(), view.right()):
                    for hy in (view.top(), view.center().y(), view.bottom()):
                        if hx != view.center().x() or hy != view.center().y():
                            p.drawRect(QRectF(hx - HANDLE, hy - HANDLE, HANDLE * 2, HANDLE * 2))
                p.setBrush(Qt.BrushStyle.NoBrush)
        if self.drawing:
            pen = QPen(QColor("#FFFFFF"), 2, Qt.PenStyle.DashLine)
            p.setPen(pen)
            p.drawRect(self.to_view(self.normalized(self.drawing)))

    @staticmethod
    def normalized(points):
        x0, y0, x1, y1 = points
        return [min(x0, x1), min(y0, y1), max(x0, x1), max(y0, y1)]

    def mousePressEvent(self, event):
        x, y = self.to_phys(event.position())
        if event.button() == Qt.MouseButton.RightButton:
            idx = self.item_at(x, y)
            if idx is not None:
                self.selected = idx
                self.update()
                self.item_menu(idx, event.globalPosition().toPoint())
            return
        if event.button() != Qt.MouseButton.LeftButton:
            return
        edges = self.handle_at(x, y)
        if edges:
            self.drag = {"mode": edges, "start": (x, y), "rect": list(self.items[self.selected]["rect"])}
            return
        idx = self.item_at(x, y)
        if idx is not None:
            self.selected = idx
            self.drag = {"mode": "move", "start": (x, y), "rect": list(self.items[idx]["rect"])}
        else:
            self.selected = None
            self.drawing = [x, y, x, y]
        self.update()

    def mouseMoveEvent(self, event):
        x, y = self.to_phys(event.position())
        if self.drawing:
            self.drawing[2], self.drawing[3] = x, y
            self.update()
            return
        if self.drag and self.selected is not None:
            self.apply_drag(x, y)
            self.update()
            return
        edges = self.handle_at(x, y)
        shapes = {"t": Qt.CursorShape.SizeVerCursor, "b": Qt.CursorShape.SizeVerCursor,
                  "l": Qt.CursorShape.SizeHorCursor, "r": Qt.CursorShape.SizeHorCursor,
                  "tl": Qt.CursorShape.SizeFDiagCursor, "br": Qt.CursorShape.SizeFDiagCursor,
                  "tr": Qt.CursorShape.SizeBDiagCursor, "bl": Qt.CursorShape.SizeBDiagCursor}
        if edges:
            self.setCursor(shapes[edges])
        elif self.item_at(x, y) is not None:
            self.setCursor(Qt.CursorShape.SizeAllCursor)
        else:
            self.setCursor(Qt.CursorShape.CrossCursor)

    def apply_drag(self, x, y):
        sx, sy = self.drag["start"]
        dx, dy = x - sx, y - sy
        left, top, right, bottom = self.drag["rect"]
        mode = self.drag["mode"]
        if mode == "move":
            dx = max(-left, min(self.W - right, dx))
            dy = max(-top, min(self.H - bottom, dy))
            rect = [left + dx, top + dy, right + dx, bottom + dy]
        else:
            if "l" in mode:
                left = min(left + dx, right - MIN_SIZE)
            if "r" in mode:
                right = max(right + dx, left + MIN_SIZE)
            if "t" in mode:
                top = min(top + dy, bottom - MIN_SIZE)
            if "b" in mode:
                bottom = max(bottom + dy, top + MIN_SIZE)
            rect = [max(0, left), max(0, top), min(self.W, right), min(self.H, bottom)]
        item = self.items[self.selected]
        if rect != item["rect"]:
            item["rect"] = rect
            item["dirty"] = True

    def mouseReleaseEvent(self, event):
        if self.drawing:
            rect = self.normalized(self.drawing)
            self.drawing = None
            self.update()
            if rect[2] - rect[0] >= MIN_SIZE and rect[3] - rect[1] >= MIN_SIZE:
                kind = self.choose_kind(event.globalPosition().toPoint())
                if kind:
                    self.add_item(kind, rect)
            return
        self.drag = None

    def choose_kind(self, pos):
        menu = QMenu(self)
        actions = {}
        for kind in KIND_ORDER:
            act = QAction(KIND_LABELS[kind], menu)
            menu.addAction(act)
            actions[act] = kind
        chosen = menu.exec(pos)
        return actions.get(chosen)

    def add_item(self, kind, rect):
        count = sum(len(self.profile.get(k) or []) for k in KIND_ORDER) + len(self.items) + 1
        spec = {"name": "새 영역 %d" % count}
        if kind != "filter_holes":
            spec["enabled"] = True
        self.items.append({"kind": kind, "spec": spec, "rect": list(rect), "dirty": True})
        self.selected = len(self.items) - 1
        self.update()
        return self.selected

    def item_menu(self, idx, pos):
        menu = QMenu(self)
        kinds = {}
        sub = menu.addMenu("종류 바꾸기")
        for kind in KIND_ORDER:
            act = QAction(KIND_LABELS[kind], sub)
            act.setCheckable(True)
            act.setChecked(kind == self.items[idx]["kind"])
            sub.addAction(act)
            kinds[act] = kind
        remove = QAction("삭제", menu)
        menu.addAction(remove)
        chosen = menu.exec(pos)
        if chosen is remove:
            self.remove_selected()
        elif chosen in kinds:
            self.set_kind(idx, kinds[chosen])

    def set_kind(self, idx, kind):
        item = self.items[idx]
        if item["kind"] != kind:
            item["kind"] = kind
            if kind != "filter_holes":
                item["spec"].setdefault("enabled", True)
            item["dirty"] = True
            self.update()

    def remove_selected(self):
        if self.selected is not None:
            del self.items[self.selected]
            self.selected = None
            self.update()

    def keyPressEvent(self, event):
        key = event.key()
        if key == Qt.Key.Key_Escape:
            self.cancel()
        elif key in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
            self.save()
        elif key in (Qt.Key.Key_Delete, Qt.Key.Key_Backspace):
            self.remove_selected()
        elif self.selected is not None and key in (Qt.Key.Key_Left, Qt.Key.Key_Right, Qt.Key.Key_Up,
                                                   Qt.Key.Key_Down):
            step = 10 if event.modifiers() & Qt.KeyboardModifier.ShiftModifier else 1
            dx = {Qt.Key.Key_Left: -step, Qt.Key.Key_Right: step}.get(key, 0)
            dy = {Qt.Key.Key_Up: -step, Qt.Key.Key_Down: step}.get(key, 0)
            self.drag = {"mode": "move", "start": (0, 0), "rect": list(self.items[self.selected]["rect"])}
            self.apply_drag(dx, dy)
            self.drag = None
            self.update()

    def build_profile(self):
        lists = {kind: [] for kind in KIND_ORDER}
        for item in self.items:
            spec = dict(item["spec"])
            if item["dirty"]:
                spec.update(engine.rect_spec(item["rect"], self.W, self.H, self.s))
            lists[item["kind"]].append(spec)
        for kind in KIND_ORDER:
            lists[kind] += self.kept[kind]
        return lists

    def save(self, *_):
        cfg = copy.deepcopy(self.eapp.cfg)
        cfg["profiles"][self.pi].update(self.build_profile())
        try:
            cfg = engine.check_config(cfg)
            engine.save_config(self.eapp.path, cfg)
        except (ValueError, OSError) as e:
            QMessageBox.warning(self, APP_TITLE, "저장하지 못했습니다.\n%s" % e)
            return
        self.saved = True
        self.finish()
        self.eapp.reload()

    def cancel(self, *_):
        self.finish()

    def finish(self):
        if self.closed:
            return
        self.closed = True
        self.close()
        self.deleteLater()
        if self in LIVE:
            LIVE.remove(self)
        self.eapp.set_suspended(False)
        saved = self.saved
        QTimer.singleShot(0, lambda: self.callback(saved))

    def closeEvent(self, event):
        if not self.closed:
            self.closed = True
            if self in LIVE:
                LIVE.remove(self)
            self.eapp.set_suspended(False)
            saved = self.saved
            QTimer.singleShot(0, lambda: self.callback(saved))
        super().closeEvent(event)


def open_area_editor(eapp, hwnd, pi, callback):
    editor = AreaEditor(eapp, hwnd, pi, callback)
    LIVE.append(editor)
    eapp.set_suspended(True)
    editor.show()
    return editor
